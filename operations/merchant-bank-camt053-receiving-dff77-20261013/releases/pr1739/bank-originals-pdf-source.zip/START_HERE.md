# Bank originals and PDF source package

This ordinary ZIP contains the complete published receiver and all 79 selected product/runtime source bodies from PR1739, plus the complete 102-source grant declaration. The 91 original files retain their paths and exact bytes. The original receiver guide is `operations/merchant-bank-camt053-receiving-dff77-20261013/README.md`.

Receiver: [PR1739](https://github.com/woahwhattheheck/tjlabs-stellar-merchant-workspace/pull/1739), merged at `7e086f3f25b1bc9e66c644a7cf0f6b6091f94598`.
Installed product: `d2094e9e9ff6efb91e4d3f94ae31305fc4e25b2f`.
Original operation: `SCF-BANK-CAMT053-SOURCE-DFF77-20261013`.

## Open the complete source

Extract this ZIP into a new ordinary directory. Open START_HERE.md, AGENTS.md and the complete receiver README. SOURCE_MANIFEST.json identifies every original member. The archive uses standard uncompressed ZIP entries, UTF-8 names and ordinary file permissions.

The included source is the frozen published selection. The existing receiver retrieves the remaining full installation source at its pinned public Git commit and uses the original native runtime installer for its npm/native dependencies. Python 3, Node, network access for that installation and an existing Playwright/Chromium installation are needed for the full receiving course. The product files in this ZIP are directly readable source, while receive.py owns the full installation.

## Continue the existing receiving operation

Use the original retained account and installation when they already exist. The complete receiver README gives the direct `receive-pdf.mjs` continuation with the actual installed source, accounting directory, workspace ID and source hash. Keep the same operation and its complete previous case files.

If this operation has not created a native case, its original receiving owner can run from the extracted directory:

~~~sh
python3 operations/merchant-bank-camt053-receiving-dff77-20261013/receive.py \
  --artifacts /absolute/owned/bank-artifacts \
  --keep-runtime \
  --pdf /absolute/original/Carson_Bank_Original_Sample_Statement.pdf \
  --pdf-browser-module /absolute/existing/playwright/index.mjs
~~~

Select the receiver's existing Chromium with `--pdf-browser-executable` if needed. The full guide describes original extraction/preparation, actual browser operation, reviewed working-copy input, explicit balance discrepancy selection, financial receiving and cold account reopening. Use the full reviewed working copy for financial receiving.

The public original is [Carson Bank's sample statement](https://www.carsonbank.com/wp-content/uploads/2021/01/Sample-Statement.pdf), published through its [disclosures page](https://www.carsonbank.com/disclosure/). Acquire the complete original in the existing equipped runtime and retain its bytes and actual digest. The earlier acquisition reported 840,338 bytes. Open every original PDF page, preserve its separate accounts and review its printed balance discrepancies.

The receiver includes the original issuer XMLs, Bundesbank archives, source profiles/collections, configured-source operations, MCP/CLI account work and accountant exports. Full application receiving and direct PDF continuation both retain the complete original files, working copies, native/browser logs, downloads and case output.

## Inspect the actual operated product

Follow the complete owner instruction in AGENTS.md and the receiver README. The original author and receiving operator must open and use the exact rendered product, inspect the original pages and captured desktop/narrow views, and open the complete downloads and cold-reopened account. Return the complete operated archive and any concrete repair to the original [Bank receiving thread](https://tokenjunkielabs.slack.com/archives/C0BTB4SUCP9/p1791730220899469).

This package is the source for that same operation. Native installation, browser use and output inspection are recorded by its actual receiving run.
