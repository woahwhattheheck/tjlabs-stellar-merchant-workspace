/** MIT. Original quote workflow and complete native result consumption. */
import {BuyerConsoleClient} from './client.mjs';
import {normalizeCatalogConfiguration, normalizeCatalogDescription, sameCatalog} from './catalogs.mjs';
import {createHttpPathFields} from './path-form.mjs';
import {createNativeRequestDesk} from './native-request.mjs';

const client = new BuyerConsoleClient();
const $ = id => document.getElementById(id);
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const stringify = value => JSON.stringify(value, null, 2);
const short = value => String(value ?? '').slice(0, 8);
const time = value => Number.isFinite(value) ? new Date(value).toLocaleString() : String(value ?? '—');
const size = bytes => Number.isFinite(bytes) ? bytes.toLocaleString() + ' bytes' : '—';
const state = {connected:false, serial:0, view:'discover', resources:[], searchArgs:null, searchPages:[],
  searchContinuation:null, searchError:null, searching:0, searchBusy:false, searchSeen:new Set(),
  catalogs:new Map(), defaultCatalogId:null, catalogRead:0, catalogReady:false, searchCatalog:null,
  description:null, quote:null, history:[], historyCursor:null, results:[], resultCursor:null,
  result:null, reading:null, spending:null, spendingRead:0, selection:0, describing:0, executing:new Set(), uncertain:new Set(), urls:new Set()};

const nativeDesk = createNativeRequestDesk({client,
  ui:{node, table, facts, badge, detail, empty, pre, url, download, renderRecords, errorText, notice},
  onView:() => setView('native')});

function node(tag, {text, className, ...attrs} = {}, children = []) {
  const element = document.createElement(tag);
  if (text !== undefined) element.textContent = String(text);
  if (className) element.className = className;
  for (const [name, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    element.setAttribute(name, value === true ? '' : String(value));
  }
  element.append(...children.filter(value => value !== null && value !== undefined));
  return element;
}
function notice(message, error = false) { $('notice').textContent = message; $('notice').classList.toggle('error', error); }
function button(label, action, {primary = false, disabled = false, ...attrs} = {}) {
  const element = node('button', {text:label, type:'button', className:primary ? 'primary' : '', ...attrs});
  element.disabled = disabled;
  element.addEventListener('click', () => attempt(action, element)); return element;
}
async function attempt(action, element) {
  const serial = state.serial;
  if (element) element.disabled = true;
  try { await action(); }
  catch (error) { if (serial === state.serial) notice(errorText(error), true); }
  finally { if (element?.isConnected && serial === state.serial) element.disabled = false; }
}
function errorText(error) {
  const details = error.details ?? error.data?.details;
  const keys = Array.isArray(details?.keys) ? details.keys.filter(key => typeof key === 'string') :
    typeof details?.key === 'string' ? [details.key] : [];
  return (error.code ? error.code + ' · ' : '') + error.message +
    (keys.length ? ' Fields: ' + keys.join(', ') + '.' : '');
}
function pre(value) { return node('pre', {text:typeof value === 'string' ? value : stringify(value)}); }
function detail(label, value) { return node('details', {}, [node('summary', {text:label}), pre(value)]); }
function badge(value) { return node('span', {className:'badge', text:value ?? '—'}); }
function facts(values) {
  return node('dl', {className:'key-values'}, values.flatMap(([label, value]) => [
    node('dt', {text:label}), node('dd', {text:typeof value === 'object' ? stringify(value) : value ?? '—'}),
  ]));
}
function empty(message) { return node('div', {className:'empty', text:message}); }
function table(headers, rows, classes = '') {
  return node('div', {className:'table-wrap ' + classes}, [node('table', {}, [
    node('thead', {}, [node('tr', {}, headers.map(text => node('th', {scope:'col', text})))]),
    node('tbody', {}, rows.map(cells => node('tr', {}, cells.map(value => node('td', {}, [
      value instanceof Node ? value : node('span', {text:value ?? '—'}),
    ]))))),
  ])]);
}
function url(value, label) {
  try {
    const parsed = new URL(value);
    if (['https:', 'http:'].includes(parsed.protocol) && !parsed.username && !parsed.password)
      return node('a', {href:parsed.href, target:'_blank', rel:'noopener noreferrer', text:label ?? value});
  } catch { /* Other native resource identifiers remain readable text. */ }
  return node('span', {className:'mono', text:label ? label + ' · ' + value : value});
}
function revokeDownloads() { for (const value of state.urls) URL.revokeObjectURL(value); state.urls.clear(); }
function download(bytes, filename, type = 'application/json') {
  const href = URL.createObjectURL(new Blob([bytes], {type}));
  const anchor = node('a', {href, download:filename}); document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(href), 1000);
}
function setView(view) {
  state.view = view;
  for (const name of ['discover','history','results','native']) $('view-' + name).hidden = name !== view;
  for (const tab of document.querySelectorAll('[data-view]')) {
    if (tab.dataset.view === view) tab.setAttribute('aria-current', 'page'); else tab.removeAttribute('aria-current');
  }
}
function reset() {
  state.serial++; client.disconnect(); revokeDownloads(); nativeDesk.reset();
  state.selection++; state.describing++; state.searching++; state.catalogRead++;
  Object.assign(state, {connected:false, resources:[], description:null, quote:null, result:null, reading:null, spending:null,
    searchArgs:null, searchPages:[], searchContinuation:null, searchError:null, searchBusy:false,
    catalogs:new Map(), defaultCatalogId:null, catalogReady:false, searchCatalog:null,
    history:[], historyCursor:null, results:[], resultCursor:null});
  state.searchSeen.clear();
  state.executing.clear(); state.uncertain.clear();
  $('workspace').hidden = true; $('connection').hidden = false; $('disconnect').hidden = true;
  $('connection-label').textContent = 'Disconnected'; $('access-token').value = '';
  for (const id of ['resource-detail','quote-detail','result-detail']) { $(id).replaceChildren(); $(id).hidden = true; }
  for (const id of ['search-results','history-list','results-list']) $(id).replaceChildren();
  $('durability').textContent = '';
  $('search-catalog').replaceChildren(node('option',{value:'',text:'Connect to read catalogs'}));
  $('search-catalog').disabled = true; $('refresh-catalogs').disabled = true;
  $('catalog-note').textContent = '';
}

async function connect(event) {
  event.preventDefault();
  const token = $('access-token').value, submit = event.submitter; $('access-token').value = '';
  reset();
  await attempt(async () => {
    const init = await client.connect(token);
    state.connected = true; $('workspace').hidden = false; $('connection').hidden = true; $('disconnect').hidden = false;
    $('connection-label').textContent = 'Connected · ' + (init.serverInfo?.name ?? 'Workspace');
    nativeDesk.connected();
    setView('discover'); notice('Connected. Select a resource or reopen an original request.');
    await loadCatalogs();
    await loadHistory(false);
  }, submit);
}

async function loadCatalogs() {
  const serial = state.serial, request = ++state.catalogRead;
  const select = $('search-catalog'), refresh = $('refresh-catalogs');
  const previous = select.value;
  state.catalogReady = false; select.disabled = true; refresh.disabled = true;
  $('catalog-note').textContent = 'Reading the configured catalog sources…';
  try {
    if (!client.tools.has('bazaar_catalogs')) {
      state.catalogs.clear(); state.defaultCatalogId = null; state.catalogReady = true;
      select.replaceChildren(node('option',{value:'',text:'Configured catalog'}));
      $('catalog-note').textContent = 'This server uses its original single configured catalog.';
      return;
    }
    const reply = await client.call('bazaar_catalogs',{});
    if (serial !== state.serial || request !== state.catalogRead) return;
    const configuration = normalizeCatalogConfiguration({discoveryCatalogs:{
      schema:reply.schema, defaultCatalogId:reply.defaultCatalogId, catalogs:reply.catalogs,
    }});
    if (reply.total !== configuration.catalogs.length)
      throw new Error('The configured catalog response is incomplete.');
    state.catalogs = new Map(configuration.catalogs.map(catalog => [catalog.id,catalog]));
    state.defaultCatalogId = configuration.defaultCatalogId;
    select.replaceChildren(...configuration.catalogs.map(catalog =>
      node('option',{value:catalog.id,text:catalog.label})));
    select.value = state.catalogs.has(previous) ? previous : configuration.defaultCatalogId;
    state.catalogReady = true;
    $('catalog-note').textContent = state.catalogs.get(select.value).url;
  } catch (error) {
    if (serial === state.serial && request === state.catalogRead) {
      $('catalog-note').textContent = errorText(error) + ' Read the configured catalogs again to explore.';
      throw error;
    }
  } finally {
    if (serial === state.serial && request === state.catalogRead) {
      select.disabled = !state.catalogReady || state.catalogs.size < 2;
      refresh.disabled = !client.tools.has('bazaar_catalogs');
      updateDiscoveryDraft();
    }
  }
}

const discoveryFields = [
  ['catalogId','search-catalog'],
  ['type','search-type'], ['payTo','search-recipient'], ['network','search-network'],
  ['extensions','search-extension'], ['scheme','search-scheme'], ['asset','search-asset'],
  ['maxAmount','search-amount'],
];
function discoveryFormSelection() {
  const query = $('search-query').value, mode = query.trim() ? 'search' : 'resources';
  const args = {limit:Number($('search-limit').value)};
  if (mode === 'search') args.query = query; else args.offset = 0;
  for (const [key, id] of discoveryFields) if ($(id).value) args[key] = $(id).value;
  return {mode, arguments:args};
}
function discoverySelectionKey(selection) {
  return JSON.stringify([selection.mode, selection.arguments.query ?? '', selection.arguments.limit,
    ...discoveryFields.map(([key]) => selection.arguments[key] ?? '')]);
}
function discoveryRequestKey(tool, args) {
  return JSON.stringify([tool, Object.keys(args).sort().map(key => [key, args[key]])]);
}
function discoveryDraftChanged() {
  return state.searchArgs !== null &&
    discoverySelectionKey(discoveryFormSelection()) !== discoverySelectionKey(state.searchArgs);
}
function restoreDiscoverySelection() {
  if (!state.searchArgs) return;
  const args = state.searchArgs.arguments;
  if (args.catalogId !== undefined && !state.catalogs.has(args.catalogId))
    throw new Error('The displayed catalog is no longer in the configured list. Read catalogs and start a new source selection.');
  $('search-query').value = args.query ?? '';
  $('search-limit').value = String(args.limit);
  for (const [key, id] of discoveryFields) $(id).value = args[key] ?? '';
  const catalog = state.catalogs.get(args.catalogId);
  if (catalog) $('catalog-note').textContent = catalog.url;
  updateDiscoveryDraft();
}
function updateDiscoveryDraft() {
  const target = $('discovery-draft');
  if (!target) return;
  const changed = discoveryDraftChanged();
  target.replaceChildren(...(changed ? [
    node('p', {className:'field-note', text:'The form has changed. Explore to apply it, or restore the displayed filters to continue these pages.'}),
    button('Restore displayed filters', restoreDiscoverySelection),
  ] : []));
  for (const element of $('search-results').querySelectorAll('[data-discovery-next]'))
    element.disabled = changed || state.searchBusy;
}
function renderDiscovery() {
  const target = $('search-results');
  if (!state.searchArgs) {
    target.replaceChildren(state.searchBusy ? empty('Loading the requested catalog page…') : empty('Explore the catalog to load resources.'));
    return;
  }
  const latest = state.searchPages.at(-1);
  const caption = node('div', {className:'panel'}, [
    node('h3', {text:state.searchArgs.mode === 'search' ? 'Search: ' + state.searchArgs.arguments.query : 'Catalog browse'}),
    node('p', {className:'field-note', text:'Displayed resources use these applied filters and the original provider pages.'}),
    ...(state.searchCatalog ? [facts([['Catalog',state.searchCatalog.label],['Catalog URL',state.searchCatalog.url]])] : []),
    facts(discoveryFields.filter(([key]) => state.searchArgs.arguments[key] !== undefined)
      .map(([key]) => [key, state.searchArgs.arguments[key]])), node('div', {id:'discovery-draft'}),
  ]);
  if (state.searchBusy) caption.append(node('p', {className:'field-note', text:'Loading the requested catalog page…'}));
  const rows = state.resources.map(resource => [
    node('div', {}, [button(resource.resource?.description || resource.toolName || resource.resource?.url || 'Inspect resource',
      () => describe(resource.handle), {class:'linklike'}), node('div', {className:'mono muted', text:resource.resource?.url})]),
    (resource.resourceType ?? '') + ' · ' + (resource.toolName ?? resource.method ?? ''),
    resource.accepts.map(option => option.amount + ' ' + option.asset + ' · ' + option.network).join('\n'),
    badge(resource.allowedOrigin ? 'CONFIGURED ORIGIN' : 'HOST SETUP REQUIRED'),
    button('Inspect', () => describe(resource.handle)),
  ]);
  const counts = state.searchPages.reduce((sum, result) => ({
    received:sum.received + result.page.received, filtered:sum.filtered + result.page.filtered,
    invalid:sum.invalid + result.page.invalid, partial:sum.partial + Number(result.partialResults === true),
  }), {received:0, filtered:0, invalid:0, partial:0});
  const paging = node('div', {className:'pager'}, [
    node('span', {text:state.resources.length + ' resources loaded · ' + state.searchPages.length +
      ' provider pages · ' + counts.received + ' rows received · ' + counts.filtered + ' excluded by filters · ' + counts.invalid + ' unusable rows'}),
  ]);
  if (state.searchContinuation) paging.append(button('Load next provider page', () => search(null, true),
    {disabled:state.searchBusy, 'data-discovery-next':true}));
  else if (!state.searchError) paging.append(node('span', {text:'The provider reported no further page for this request.'}));
  if (counts.partial) paging.append(node('span', {text:'The provider flagged ' + counts.partial + ' loaded page' + (counts.partial === 1 ? '' : 's') + ' as partial.'}));
  target.replaceChildren(caption, rows.length ? table(['Resource','Invocation','Payment choices','Access',''], rows)
    : empty('No resource matched the applied filters on the loaded pages.'), paging);
  if (state.searchError) target.append(node('p', {className:'notice error', text:errorText(state.searchError)}));
  target.append(detail('Provider pages and applied requests', state.searchPages.map(result => ({
    source:result.source, page:result.page, partialResults:result.partialResults,
    pagination:result.pagination, continuation:result.continuation,
  }))));
  if (latest) target.append(node('p', {className:'caption', text:'Latest page observed: ' + latest.source.observedAt}));
  updateDiscoveryDraft();
}
async function search(event, more = false) {
  event?.preventDefault();
  if (more && (state.searchBusy || !state.searchContinuation)) return;
  if (more && discoveryDraftChanged()) throw new Error('Restore the displayed filters before continuing these provider pages.');
  if (!more && !state.catalogReady) throw new Error('Read the configured catalogs before exploring a source.');
  const selection = more ? state.searchArgs : discoveryFormSelection();
  const call = more ? state.searchContinuation : {tool:'bazaar_' + selection.mode, arguments:selection.arguments};
  const args = structuredClone(call.arguments), requestKey = discoveryRequestKey(call.tool, args);
  const serial = state.serial, request = ++state.searching;
  state.searchBusy = true; renderDiscovery();
  try {
    const result = await client.call(call.tool, args);
    if (serial !== state.serial || request !== state.searching) return;
    if (!Array.isArray(result.resources) || !plain(result.source) || !plain(result.source.request) ||
        !plain(result.page) || result.source.mode !== selection.mode ||
        discoveryRequestKey(call.tool, result.source.request) !== requestKey)
      throw new Error('The catalog response does not match the requested discovery page.');
    const catalog = result.source.catalog === undefined ? null : normalizeCatalogDescription(result.source.catalog);
    const configured = state.catalogs.get(args.catalogId ?? state.defaultCatalogId);
    if (args.catalogId !== undefined && (!catalog || catalog.id !== args.catalogId) ||
        catalog && configured && !sameCatalog(catalog,configured) ||
        more && state.searchCatalog && !sameCatalog(state.searchCatalog,catalog) ||
        result.resources.some(resource => resource.catalogId !== undefined && resource.catalogId !== catalog?.id))
      throw new Error('The returned page belongs to another catalog. Start a new explicit source selection.');
    if (result.continuation) {
      const next = result.continuation;
      if (next.tool !== call.tool || !plain(next.arguments)) throw new Error('Invalid original catalog continuation.');
      const position = selection.mode === 'search' ? 'cursor' : 'offset';
      const before = {...args}, after = {...next.arguments};
      delete before[position]; delete after[position];
      if (before.catalogId === undefined && catalog && after.catalogId === catalog.id) before.catalogId = catalog.id;
      if (discoveryRequestKey(call.tool,before) !== discoveryRequestKey(call.tool,after))
        throw new Error('The continuation changed the original catalog or applied filters.');
    }
    if (!more) {
      state.searchCatalog = catalog;
      state.searchArgs = {mode:selection.mode, arguments:structuredClone(result.source.request)};
      state.resources = []; state.searchPages = []; state.searchSeen.clear();
    }
    state.searchSeen.add(requestKey);
    state.resources.push(...result.resources); state.searchPages.push(result);
    state.searchContinuation = result.continuation;
    state.searchError = result.page.continuationError;
    if (state.searchContinuation && state.searchSeen.has(discoveryRequestKey(state.searchContinuation.tool, state.searchContinuation.arguments))) {
      state.searchContinuation = null;
      state.searchError = {code:'DISCOVERY_CURSOR_REPEATED', message:'The provider returned a page request already loaded in this view.'};
    }
    notice('Catalog page received. Inspect a resource to prepare its exact request.');
  } catch (error) {
    if (serial === state.serial && request === state.searching) throw error;
  } finally {
    if (serial === state.serial && request === state.searching) {
      state.searchBusy = false; renderDiscovery();
    }
  }
}

function schemaShape(schema, depth = 0) {
  if (depth >= 8) return 'See full schema';
  if (schema === false) return 'Disallowed';
  if (!plain(schema)) return 'See full schema';
  const type = Array.isArray(schema.type) ? schema.type.join(' | ') : schema.type;
  if (type === 'array') return 'array of ' + (plain(schema.items) ? schemaShape(schema.items, depth + 1) : 'declared items');
  return typeof type === 'string' ? type : 'See full schema';
}
function invocationFields(value) {
  const input = value.preview.input;
  if (input.container === 'query') {
    const parameters = input.parameters ?? [];
    if (!parameters.length) return empty('The seller has not declared query parameter keys for this resource.');
    let fixed;
    try { fixed = new Set(new URL(value.resource.url).searchParams.keys()); } catch { fixed = new Set(); }
    return table(['Query key','Declared shape','Required','Encoding and description'], parameters.map(parameter => [
      node('span', {className:'mono', text:parameter.name}),
      parameter.type === 'array' ? 'array of ' + (Array.isArray(parameter.itemType) ? parameter.itemType.join(' | ') : parameter.itemType ?? 'declared items')
        : Array.isArray(parameter.type) ? parameter.type.join(' | ') : parameter.type ?? 'Unspecified',
      parameter.required ? (fixed.has(parameter.name) ? 'Yes · present in URL' : 'Yes') : 'Optional',
      node('div', {}, [
        node('span', {text:parameter.encoding === 'form-comma' ? 'Comma-separated form value'
          : parameter.encoding === 'form-repeated' ? 'Repeated form values' : 'Literal string or repeated values'}),
        ...(parameter.title ? [node('div', {text:parameter.title})] : []),
        ...(parameter.description ? [node('p', {text:parameter.description})] : []),
      ]),
    ]));
  }
  const schema = value.bazaar.info?.input?.inputSchema;
  const properties = plain(schema?.properties) ? schema.properties : {};
  const required = new Set(Array.isArray(schema?.required) ? schema.required.filter(key => typeof key === 'string') : []);
  const names = [...new Set([...Object.keys(properties), ...required])];
  if (!names.length) return empty('Use the complete declared tool schema to prepare this argument object.');
  const shown = names.slice(0, 256);
  return node('div', {}, [
    table(['Argument','Declared shape','Required','Description'], shown.map(name => [
      node('span', {className:'mono', text:name}), schemaShape(properties[name]), required.has(name) ? 'Yes' : 'Optional',
      typeof properties[name]?.description === 'string' ? properties[name].description.slice(0, 2048) : 'See full schema',
    ])),
    ...(names.length > shown.length ? [node('p', {className:'field-note', text:'Showing the first ' + shown.length + ' top-level declarations. The complete schema is available below.'})] : []),
  ]);
}
async function describe(handle) {
  const serial = state.serial, request = ++state.describing;
  const target = $('resource-detail');
  state.description = null; target.hidden = false; target.setAttribute('aria-busy', 'true');
  target.replaceChildren(empty('Loading the selected resource declaration…'));
  let value;
  try { value = await client.call('bazaar_describe', {handle}); }
  catch (error) {
    if (serial === state.serial && request === state.describing) {
      target.removeAttribute('aria-busy');
      target.replaceChildren(node('h3', {text:'Resource inspection failed'}),
        node('p', {className:'notice error', text:errorText(error)}),
        button('Retry inspection', () => describe(handle)));
      throw error;
    }
    return;
  }
  if (serial !== state.serial || request !== state.describing) return;
  target.removeAttribute('aria-busy');
  state.description = value;
  const preview = value.preview, container = preview.input.container;
  const declarationErrors = [preview.input.pathInputError, preview.input.inputError, preview.input.requiredKeysError, preview.remoteMcpError]
    .filter((error, index, errors) => error && errors.findIndex(other => other?.code === error.code && other?.message === error.message) === index);
  const canPreview = preview.allowedOrigin && preview.methodSupported && declarationErrors.length === 0;
  let inputRevision = 0;
  const pathFields = container === 'query' ? createHttpPathFields(value, {node, empty}) : null;
  pathFields?.onChange(() => { inputRevision++; });
  const options = node('select', {id:'payment-option', 'aria-label':'Payment option'}, value.accepts.map((option, index) =>
    node('option', {value:index, text:(index + 1) + ' · ' + option.amount + ' ' + option.asset + ' · ' + option.network})));
  const choice = node('div');
  const showChoice = () => choice.replaceChildren(facts(Object.entries(value.accepts[Number(options.value)])));
  options.addEventListener('change', () => { inputRevision++; showChoice(); }); showChoice();
  const input = node('textarea', {id:'invocation-input', spellcheck:'false', 'aria-label':container === 'arguments' ? 'Tool arguments JSON' : 'Query values JSON'});
  input.value = '{}'; input.addEventListener('input', () => { inputRevision++; });
  const form = node('form', {}, [...(pathFields ? [pathFields.element] : []), node('label', {text:container === 'arguments' ? 'Tool arguments (JSON object)' : 'Query values (JSON object)'}, [input]),
    node('p', {className:'field-note', text:container === 'query'
      ? 'Enter explicit strings or nonempty arrays of strings. ' +
        (preview.input.querySerialization ? 'The seller’s declared form encoding applies to each field. ' : 'Strings stay literal; arrays repeat their key. ') +
        'Required keys: ' + (preview.input.requiredKeys?.join(', ') || 'none declared') + '. Values already in the resource URL remain unless you replace that key.'
      : 'Enter the actual arguments for this tool. The live server validates the advertised input schema.'})]);
  const create = node('button', {type:'submit', className:'primary', text:'Review exact quote'});
  create.disabled = !canPreview;
  form.append(create);
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!canPreview) return;
    if (serial !== state.serial || request !== state.describing || state.description !== value) {
      notice('Inspect this resource again before preparing its request.', true);
      return;
    }
    attempt(async () => {
      let parsed;
      try {
        parsed = JSON.parse(input.value, (_key, value) => {
          if (typeof value === 'number' && (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))))
            throw new RangeError('This JSON number cannot be retained exactly. Use the tool’s declared string form for large IDs or exact amounts.');
          return value;
        });
      } catch (error) { throw error instanceof RangeError ? error : new Error('Enter valid JSON for the invocation.'); }
      if (!plain(parsed)) throw new Error('The invocation input must be a JSON object.');
      const revision = inputRevision, selection = ++state.selection;
      let quote;
      try {
        const invocationInput = {[container]:parsed, ...(pathFields ? {path:pathFields.read()} : {})};
        quote = await client.call('bazaar_preview', {handle:value.handle, acceptIndex:Number(options.value), input:invocationInput});
      } catch (error) {
        if (serial === state.serial && request === state.describing && state.description === value && selection === state.selection && revision === inputRevision) throw error;
        return;
      }
      if (serial !== state.serial || request !== state.describing || state.description !== value || selection !== state.selection) return;
      if (revision !== inputRevision) {
        notice('Quote ' + quote.quoteId + ' was saved with the earlier input. Open it in Quote history to inspect that request.');
        return;
      }
      if (value.source?.catalog && !sameCatalog(value.source.catalog,quote.source?.catalog))
        throw new Error('The saved quote does not retain the selected catalog source. Inspect the original quote before continuing.');
      selectQuote(quote); renderQuote(); $('quote-detail').scrollIntoView({behavior:'smooth', block:'start'});
      notice('Quote created. Review the exact invocation and terms before requesting host approval.');
    }, create);
  });
  target.replaceChildren(node('div', {className:'detail-heading'}, [node('div', {}, [
    node('h3', {text:value.resource.description || value.resource.url}), node('p', {className:'mono', text:value.resource.url}),
  ]), badge(preview.resourceType.toUpperCase())]),
  node('div', {className:'detail-grid'}, [
    node('div', {}, [node('h4', {text:'Invocation'}), facts([
      ['Catalog', value.source?.catalog?.label], ['Catalog URL', value.source?.catalog?.url],
      ['Method', preview.method], ['Tool', preview.remoteMcp?.toolName], ['Endpoint', preview.remoteMcp?.endpoint ?? value.resource.url],
    ]), node('h4', {text:container === 'query' ? 'Declared query fields' : 'Top-level argument declarations'}), invocationFields(value),
    ...declarationErrors.map(error => node('p', {className:'notice error', text:errorText(error)})),
    form, detail('Declared input and schema', {input:value.bazaar.info?.input, schema:value.bazaar.schema}),
    detail('Request preparation details', preview.input)]),
    node('div', {}, [node('h4', {text:'Payment choice'}), node('label', {text:'Original option'}, [options]), choice,
      node('p', {className:'field-note', text:'Amounts use the asset’s original base units. A quote does not make a payment.'}),
      detail('Full original declaration', value.bazaar), detail('Discovery source', value.source)]),
  ]));
  if (preview.resourceType === 'http') target.append(nativeDesk.offer(value,
    () => serial === state.serial && request === state.describing && state.description === value));
  target.scrollIntoView({behavior:'smooth', block:'start'});
}

async function loadHistory(more = false) {
  const serial = state.serial, status = $('history-status').value;
  const result = await client.call('bazaar_history', {limit:25, ...(status ? {status} : {}), ...(more ? {cursor:state.historyCursor} : {})});
  if (serial !== state.serial) return;
  state.history = more ? [...state.history, ...result.quotes] : result.quotes; state.historyCursor = result.nextCursor;
  $('durability').textContent = result.durable ? 'Durable quote workspace' : 'In-memory quotes · Configure MCP_STATE_DIR for restart retention';
  const rows = state.history.map(quote => [
    button(short(quote.quoteId), () => openQuote(quote.quoteId), {class:'linklike', title:quote.quoteId}),
    quote.source?.catalog?.label ?? '—', quote.invocation?.toolName ?? quote.method, node('span', {className:'mono', text:quote.resource}),
    badge(quote.status), quote.selected?.amount + ' ' + quote.selected?.asset, time(quote.createdAt),
    button('Open quote', () => openQuote(quote.quoteId)),
  ]);
  $('history-list').replaceChildren(rows.length ? table(['Quote','Catalog','Invocation','Resource','Status','Amount','Created',''], rows) : empty('No quotes match this view.'));
  const paging = node('div', {className:'pager'}, [node('span', {text:state.history.length + ' of ' + result.total + ' quotes loaded'})]);
  if (state.historyCursor) paging.append(button('Load more quotes', () => loadHistory(true)));
  $('history-list').append(paging);
}
async function loadResults(more = false) {
  const serial = state.serial;
  const result = await client.call('bazaar_results', {limit:25, ...(more ? {cursor:state.resultCursor} : {})});
  if (serial !== state.serial) return;
  state.results = more ? [...state.results, ...result.results] : result.results; state.resultCursor = result.nextCursor;
  const rows = state.results.map(quote => [
    button(quote.toolName || short(quote.quoteId), () => openResult(quote.quoteId), {class:'linklike'}),
    node('span', {className:'mono', text:short(quote.quoteId)}), badge(quote.status), size(quote.responseFile.bytes),
    time(quote.createdAt), button('Open saved result', () => openResult(quote.quoteId)),
  ]);
  $('results-list').replaceChildren(rows.length ? table(['Tool','Quote','Original status','Complete file','Created',''], rows) : empty('No complete native MCP result has been saved in this workspace yet. Quote history includes failed or interrupted captures.'));
  const paging = node('div', {className:'pager'}, [node('span', {text:state.results.length + ' of ' + result.total + ' saved results loaded'})]);
  if (state.resultCursor) paging.append(button('Load more results', () => loadResults(true)));
  $('results-list').append(paging);
}
async function openQuote(quoteId, scroll = true) {
  const serial = state.serial, selection = ++state.selection, quote = await client.call('bazaar_status', {quoteId});
  if (serial !== state.serial || selection !== state.selection) return false;
  selectQuote(quote); state.spending = null; state.spendingRead++; state.uncertain.delete(quoteId); renderQuote();
  if (scroll) $('quote-detail').scrollIntoView({behavior:'smooth', block:'start'});
  return true;
}
function selectQuote(quote) {
  if (state.quote?.quoteId !== quote.quoteId) {
    state.spending = null; state.spendingRead++;
    revokeDownloads(); state.result = null; $('result-detail').replaceChildren(); $('result-detail').hidden = true;
  }
  state.quote = quote;
}
async function executeQuote(quoteId) {
  const serial = state.serial; state.spending = null; state.spendingRead++; state.executing.add(quoteId); renderQuote();
  notice('Host approval requested for ' + quoteId + '. Refresh status or cancel this original quote while the host responds.');
  try {
    const quote = await client.call('bazaar_execute_approved', {quoteId});
    if (serial !== state.serial) return;
    if (state.quote?.quoteId === quoteId) { state.quote = quote; state.spending = null; state.spendingRead++; }
    state.uncertain.delete(quoteId);
    notice('Original quote ' + quoteId + ' returned ' + quote.status + '.');
  } catch (error) {
    if (serial === state.serial) {
      state.uncertain.add(quoteId);
      notice((error.code ? error.code + ' · ' : '') + error.message + ' Refresh this original quote before any further action.', true);
    }
  } finally {
    state.executing.delete(quoteId);
    if (serial === state.serial) renderQuote();
  }
}
async function quoteAction(name, quoteId, additional = {}) {
  const serial = state.serial, quote = await client.call(name, {...additional,quoteId});
  if (serial !== state.serial) return;
  if (state.quote?.quoteId === quoteId) { state.quote = quote; state.spending = null; state.spendingRead++; renderQuote(); }
  notice(name === 'bazaar_reconcile_payment'
    ? 'Transaction observation: ' + (quote.transactionObservation ?? quote.result.reconciliation).outcome +
      (quote.transactionObservation ? '. Observation was not saved; inspect and download its details. Original quote remains ' : '. Original quote: ') + quote.status + '.'
    : 'Original quote ' + quoteId + ' is ' + quote.status + '.', Boolean(quote.transactionObservation));
}
function paymentInspection(q, active) {
  const receipt = q.result?.paymentResponse, report = q.transactionObservation ?? q.result?.reconciliation;
  const panel = node('section', {className:'content-block', id:'payment-inspection'}, [
    node('h4', {text:'Payment transaction'}),
  ]);
  if (receipt) panel.append(facts([
    ['Server settlement', receipt.success ? 'Reported success' : 'Reported failure'],
    ['Transaction', receipt.transaction], ['Network', receipt.network], ['Payer', receipt.payer],
    ['Server failure code', receipt.errorReason], ['Server failure detail', receipt.errorMessage],
  ]), detail('Original server receipt fields', receipt));
  if (report) panel.append(node('h4', {text:'Stellar transaction observation'}), facts([
    ['Outcome', report.outcome], ['Checked', report.checkedAt], ['Transaction', report.transaction],
    ['Observation storage', report.saved === false ? 'Not saved; available in this response' : 'Retained in this workspace'],
    ['Reference source', report.transactionSource === 'ORIGINAL_RECEIPT' ? 'Original server receipt' : 'Operator transaction reference'],
    ['Ledger', report.ledger], ['Network', report.network], ['RPC endpoint', report.rpcEndpoint],
    ['Reviewed payer', report.payer], ['Quoted recipient', report.recipient],
    [report.outcome === 'TRANSFER_MATCHED' ? 'Transferred atomic amount' : 'Quoted atomic amount', report.atomicAmount],
  ]), detail('Complete transaction observation', report),
    button('Download transaction observation', () => download(new TextEncoder().encode(stringify(report)), q.quoteId + '-transaction.json')));
  if(q.result?.supersededReconciliation)panel.append(detail('Earlier observation for a different transaction reference', q.result.supersededReconciliation));
  if (q.signedRequestDispatched && !active) {
    const hasHash = typeof receipt?.transaction === 'string' && /^[0-9a-f]{64}$/i.test(receipt.transaction);
    let reference;
    if (!hasHash) {
      reference = node('input', {id:'original-transaction-reference', type:'text', spellcheck:'false',
        autocomplete:'off', maxlength:64, pattern:'[0-9a-fA-F]{64}',
        value:report?.transactionSource === 'OPERATOR_REFERENCE' ? report.transaction : '',
        placeholder:'64 hexadecimal characters'});
      panel.append(node('label', {for:'original-transaction-reference', text:'Original transaction hash'}, [reference]),
        node('p', {className:'caption', text:'This saved response has no transaction hash. Enter the original transaction reference to inspect it; the saved response remains unchanged.'}));
    }
    panel.append(button('Read transaction outcome', async () => {
      const additional = hasHash ? {} : {transaction:reference.value.trim()};
      if (!hasHash && !/^[0-9a-f]{64}$/i.test(additional.transaction)) throw new Error('Enter the original 64-character transaction hash.');
      await quoteAction('bazaar_reconcile_payment', q.quoteId, additional);
    }, {disabled:!client.tools.has('bazaar_reconcile_payment')}),
    node('p', {className:'caption', text:'Reads Stellar through the host’s configured observation adapter. Keeps the original quote and authorization; this action does not sign or submit a payment.'}));
  }
  return panel;
}
async function inspectSpending(quoteId) {
  const serial = state.serial, selection = state.selection, reading = ++state.spendingRead;
  const report = await client.call('bazaar_spending_status', {quoteId});
  if (serial !== state.serial || selection !== state.selection || reading !== state.spendingRead ||
      state.quote?.quoteId !== quoteId) return;
  state.spending = {quoteId,report,checkedAt:new Date().toISOString()};
  renderQuote(); notice('Spending ledger read for the selected quote.');
}
function spendingInspection(q) {
  const saved = state.spending?.quoteId === q.quoteId ? state.spending : null;
  const finalized = (q.transactionObservation ?? q.result?.reconciliation)?.spending;
  const report = saved?.report ?? finalized;
  const panel = node('section', {className:'content-block', id:'spending-inspection'}, [
    node('h4', {text:'Spending ledger'}),
    button('Read spending ledger', () => inspectSpending(q.quoteId),
      {disabled:!client.tools.has('bazaar_spending_status')}),
  ]);
  if (!report) {
    panel.append(node('p', {className:'caption',
      text:'Review the host’s aggregate budget and this quote’s retained reservation.'}));
    return panel;
  }
  const held = report.reservation;
  panel.append(facts([
    ['Status', report.outcome], ['Ledger state', held?.state],
    ['Reserved maximum (base units)', held?.amount ?? held?.max_amount],
    ['Finalized amount (base units)', held?.actual ?? report.actual],
    ['Network receipt', held?.receipt_ref ?? report.receipt_ref],
    ['Read at', saved?.checkedAt], ['Request digest', report.request_sha256],
  ]));
  if (report.estimate) {
    const labels = {max_single:'One payment',max_total:'Lifetime total',
      max_per_utc_day:'UTC day',max_per_actor_utc_day:'Actor / UTC day',
      max_per_service_utc_day:'Service / UTC day'};
    panel.append(node('h4', {text:'Capacity for this request'}),
      table(['Budget','Available base units'],Object.entries(report.estimate.limit_remaining ?? {})
        .map(([key,value])=>[labels[key] ?? key,value])),
      node('p', {className:'caption',text:report.estimate.approved
        ? 'The current estimate fits. Signing rechecks and reserves the exact amount atomically.'
        : 'This request exceeds: ' + (report.estimate.denied_by ?? []).map(key=>labels[key] ?? key).join(', ') + '.'}));
  }
  panel.append(detail('Complete spending record',report),
    button('Download spending record',()=>download(new TextEncoder().encode(stringify(report)),q.quoteId+'-spending.json')));
  return panel;
}
function renderQuote() {
  const q = state.quote, target = $('quote-detail'); if (!q) { target.hidden = true; return; }
  target.hidden = false;
  const active = ['PREVIEWED','APPROVAL_PENDING','EXECUTING','CANCEL_REQUESTED'].includes(q.status);
  const actions = node('div', {className:'actions'}, [
    button('Refresh quote status', () => openQuote(q.quoteId, false)),
    button(state.executing.has(q.quoteId) ? 'Host request in progress' : 'Request host approval', () => executeQuote(q.quoteId),
      {primary:true, disabled:q.status !== 'PREVIEWED' || state.executing.has(q.quoteId) || state.uncertain.has(q.quoteId)}),
    button('Cancel original quote', () => quoteAction('bazaar_cancel', q.quoteId), {disabled:!active}),
  ]);
  if (q.result?.responseFile?.status === 'SAVED') actions.append(button('Read complete saved result', () => openResult(q.quoteId)));
  if (q.invocation && q.attempts > 0 && !active)
    actions.append(button('Recover saved files', () => quoteAction('bazaar_recover_result', q.quoteId), {disabled:!client.tools.has('bazaar_recover_result')}));
  target.replaceChildren(node('div', {className:'detail-heading'}, [
    node('div', {}, [node('h2', {text:'Original quote'}), node('p', {className:'mono', text:q.quoteId})]), badge(q.status),
  ]), node('div', {className:'detail-grid'}, [
    node('div', {}, [node('h4', {text:'Exact invocation'}), facts([
      ['Catalog', q.source?.catalog?.label], ['Catalog URL', q.source?.catalog?.url],
      ['Resource', q.resource], ['Endpoint', q.requestUrl], ['Method', q.method],
      ['Tool', q.invocation?.toolName], ['Created', time(q.createdAt)], ['Updated', time(q.updatedAt)],
      ['Expires', time(q.expiresAt)], ['Attempts', q.attempts], ['Phase', q.phase],
    ]), ...(q.invocation ? [detail('Complete invocation and arguments', q.invocation)] : []),
      ...(q.source ? [detail('Original catalog page and row',q.source)] : [])]),
    node('div', {}, [node('h4', {text:'Selected payment terms'}), facts(Object.entries(q.acceptedTerms ?? q.selected ?? {})),
      ...(q.result?.paymentResponse || q.signedRequestDispatched ? [paymentInspection(q, active)] : []),
      ...(q.invocation ? [spendingInspection(q)] : []),
      ...(q.failure ? [node('p', {text:q.failure})] : []),
      ...(q.result?.responseFile ? [detail('Saved file', q.result.responseFile)] : []),
      ...(q.result?.content ? [detail(q.result.content.truncated ? 'Truncated status preview' : 'Status preview', q.result.content)] : []),
    ]),
  ]), actions, node('p', {className:'caption', text:state.uncertain.has(q.quoteId)
    ? 'The last request did not return a confirmed response to this tab. Refresh the same quote; no new quote or purchase is created.'
    : 'Execution uses the host’s existing approval and signer. The displayed payment state comes from the original quote.'}));
}

async function openResult(quoteId) {
  const serial = state.serial;
  if (state.reading) throw new Error('A complete result is already being read.');
  state.reading = quoteId;
  try {
    if (!await openQuote(quoteId, false)) return;
    const selection = state.selection;
    if (serial !== state.serial) return;
    const result = await client.completeResult(quoteId, (read, total) => {
      if (serial === state.serial) notice('Reading saved result · ' + read.toLocaleString() + ' / ' + total.toLocaleString() + ' bytes');
    });
    if (serial !== state.serial || selection !== state.selection) return;
    revokeDownloads(); state.result = {...result, quoteId}; renderResult();
    $('result-detail').scrollIntoView({behavior:'smooth', block:'start'});
    notice('Complete saved result opened · ' + size(result.bytes.length) + '.');
  } finally { if (state.reading === quoteId) state.reading = null; }
}
function arrays(value, path = [], found = [], depth = 0) {
  if (Array.isArray(value)) { found.push({path, rows:value}); return found; }
  if (plain(value) && depth < 8) for (const [key, child] of Object.entries(value)) {
    if (found.length >= 64) break;
    arrays(child, [...path, key], found, depth + 1);
  }
  return found;
}
function renderRecords(value) {
  const root = node('div'), candidates = arrays(value);
  if (!candidates.length) { root.append(pre(value)); return root; }
  const selector = node('select', {id:'record-source', 'aria-label':'Record collection'}, candidates.map((entry, index) =>
    node('option', {value:index, text:(entry.path.length ? entry.path.join('.') : 'Root') + ' · ' + entry.rows.length + ' records'})));
  const filter = node('input', {type:'search', id:'record-filter', placeholder:'Find values in this collection', 'aria-label':'Filter records'});
  const grid = node('div'), paging = node('div', {className:'pager'}), selected = node('div'); let page = 0;
  function render() {
    const rows = candidates[Number(selector.value)].rows;
    const term = filter.value.toLocaleLowerCase();
    const matches = rows.map((value, index) => ({value, index})).filter(row => !term || JSON.stringify(row.value).toLocaleLowerCase().includes(term));
    const allColumns = [...new Set(matches.flatMap(row => plain(row.value) ? Object.keys(row.value) : ['Value']))];
    const columns = allColumns.slice(0, 32), count = Math.max(1, Math.ceil(matches.length / 40)); page = Math.min(page, count - 1);
    const visible = matches.slice(page * 40, page * 40 + 40);
    const cells = visible.map(row => [String(row.index + 1), ...columns.map(column => {
      const value = plain(row.value) ? row.value[column] : column === 'Value' ? row.value : undefined;
      const text = value === undefined ? '—' : typeof value === 'string' ? value : JSON.stringify(value);
      return node('span', {className:'record-cell', text:text.length > 240 ? text.slice(0, 240) + '…' : text});
    }), button('Open record', () => { selected.replaceChildren(node('h4', {text:'Complete record ' + (row.index + 1)}), pre(row.value)); })]);
    grid.replaceChildren(cells.length ? table(['#', ...columns, ''], cells, 'data-grid') : empty('No records match this filter.'));
    paging.replaceChildren(node('span', {text:matches.length + ' of ' + rows.length + ' records · Page ' + (page + 1) + ' of ' + count}),
      button('Previous records', () => { page--; render(); }, {disabled:page === 0}),
      button('Next records', () => { page++; render(); }, {disabled:page + 1 >= count}));
    if (allColumns.length > columns.length) paging.append(node('span', {text:columns.length + ' of ' + allColumns.length + ' fields shown. Open a record for every field.'}));
  }
  selector.addEventListener('change', () => { page = 0; selected.replaceChildren(); render(); });
  filter.addEventListener('input', () => { page = 0; render(); });
  root.append(node('div', {className:'record-controls'}, [node('label', {text:'Collection'}, [selector]), node('label', {text:'Filter records'}, [filter])]),
    grid, paging, selected, detail('Complete structured content', value)); render(); return root;
}
function embeddedBytes(value) {
  try { return Uint8Array.from(atob(value), character => character.charCodeAt(0)); }
  catch { return null; }
}
function renderContent(items) {
  if (!Array.isArray(items) || !items.length) return empty('This result has no native content items.');
  return node('div', {}, items.map((item, index) => {
    const panel = node('section', {className:'content-block'}, [node('h4', {text:(index + 1) + ' · ' + (item.type ?? 'Content')})]);
    if (item.type === 'text') panel.append(pre(item.text ?? ''));
    else if (item.type === 'resource_link') panel.append(facts([['Name',item.name], ['Type',item.mimeType], ['Description',item.description]]), url(item.uri, item.title ?? item.uri));
    else if (item.type === 'resource' && item.resource) {
      const resource = item.resource;
      panel.append(facts([['Resource',resource.uri], ['Type',resource.mimeType]]));
      if (typeof resource.text === 'string') panel.append(pre(resource.text));
      if (typeof resource.blob === 'string') {
        const bytes = embeddedBytes(resource.blob);
        if (bytes) panel.append(node('p', {text:size(bytes.length)}), button('Download embedded resource', () => download(bytes, 'resource-' + (index + 1), resource.mimeType ?? 'application/octet-stream')));
      }
    } else if (['image','audio'].includes(item.type) && typeof item.data === 'string') {
      const bytes = embeddedBytes(item.data);
      if (bytes) {
        const mime = item.mimeType ?? 'application/octet-stream';
        const safeImage = /^image\/(png|jpeg|gif|webp)$/.test(mime), safeAudio = /^audio\/(mpeg|wav|ogg|mp4|webm)$/.test(mime);
        panel.append(node('p', {text:mime + ' · ' + size(bytes.length)}));
        if (safeImage || safeAudio) {
          const source = URL.createObjectURL(new Blob([bytes], {type:mime})); state.urls.add(source);
          panel.append(safeImage ? node('img', {src:source, alt:'Embedded image ' + (index + 1)}) : node('audio', {src:source, controls:true, preload:'none'}));
        }
        panel.append(button('Download embedded ' + item.type, () => download(bytes, item.type + '-' + (index + 1), mime)));
      }
    }
    panel.append(detail('Complete native item', item)); return panel;
  }));
}
function renderResult() {
  const result = state.result, target = $('result-detail'); if (!result) return;
  target.hidden = false;
  const body = node('div', {id:'result-body'}), tabs = node('div', {className:'subtabs', role:'tablist', 'aria-label':'Native result views'});
  const views = [['structured','Structured data'], ['content','Content'], ['raw','Complete JSON']];
  function show(name) {
    revokeDownloads();
    for (const tab of tabs.children) tab.setAttribute('aria-selected', String(tab.dataset.kind === name));
    if (name === 'structured') body.replaceChildren(result.native.structuredContent === undefined
      ? empty('No structuredContent field was returned. Content and Complete JSON retain the full native result.') : renderRecords(result.native.structuredContent));
    if (name === 'content') body.replaceChildren(renderContent(result.native.content));
    if (name === 'raw') body.replaceChildren(pre(new TextDecoder('utf-8', {fatal:true}).decode(result.bytes)));
  }
  for (const [name, label] of views) tabs.append(button(label, () => show(name), {role:'tab', 'data-kind':name, 'aria-selected':'false'}));
  target.replaceChildren(node('div', {className:'detail-heading'}, [
    node('div', {}, [node('h2', {text:'Complete saved result'}), node('p', {className:'mono', text:result.quoteId}),
      node('p', {text:size(result.bytes.length) + ' · Native CallToolResult JSON'}),
      ...(result.native.isError === true ? [node('p', {text:'The original tool reported an error.'})] : [])]),
    button('Download complete JSON', () => download(result.bytes, result.quoteId + '.json'), {primary:true}),
  ]), detail('Original file identity', {bytes:result.metadata.bytes, sha256:result.metadata.sha256, representation:result.metadata.representation}), tabs, body);
  show(result.native.structuredContent === undefined ? 'content' : 'structured');
}

$('connect-form').addEventListener('submit', connect);
$('disconnect').addEventListener('click', () => { reset(); notice('Disconnected. Original operations and saved results remain in the workspace.'); });
$('search-form').addEventListener('submit', event => { event.preventDefault(); attempt(() => search(event), event.submitter); });
$('search-form').addEventListener('input', updateDiscoveryDraft);
$('search-form').addEventListener('change', updateDiscoveryDraft);
$('refresh-catalogs').addEventListener('click',event => attempt(loadCatalogs,event.currentTarget));
$('search-catalog').addEventListener('change',() => {
  const selected = state.catalogs.get($('search-catalog').value);
  if (selected) $('catalog-note').textContent = selected.url;
});
$('refresh-history').addEventListener('click', event => attempt(() => loadHistory(false), event.currentTarget));
$('history-filter').addEventListener('submit', event => { event.preventDefault(); attempt(() => loadHistory(false), event.submitter); });
$('refresh-results').addEventListener('click', event => attempt(() => loadResults(false), event.currentTarget));
for (const tab of document.querySelectorAll('[data-view]')) tab.addEventListener('click', () => attempt(async () => {
  setView(tab.dataset.view);
  if (state.view === 'history') await loadHistory(false);
  if (state.view === 'results') await loadResults(false);
  if (state.view === 'native') await nativeDesk.open();
}));
window.addEventListener('pagehide', () => { nativeDesk.reset(); client.disconnect(); revokeDownloads(); });
