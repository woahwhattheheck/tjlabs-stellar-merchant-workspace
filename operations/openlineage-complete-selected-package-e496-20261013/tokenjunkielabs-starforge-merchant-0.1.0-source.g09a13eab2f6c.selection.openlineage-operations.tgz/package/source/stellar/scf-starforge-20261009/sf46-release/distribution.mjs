#!/usr/bin/env node
// MIT. Build a relocatable product from one Git commit, never from local state.
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, rm } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { RELEASE_SCHEMA, MANIFEST, MAX_BYTES, canonical, sha256, relativePath,
  putFile, verifyRelease } from './release-core.mjs';
import { compileCommandCatalog } from './command-catalog.mjs';

const exec = promisify(execFile);
const BASE = 'stellar/scf-starforge-20261009/';
const SCOPES = ['scf46-stellar-bazaar', 'stellar-forge', BASE.slice(0, -1), 'LICENSE'];
const CATALOG = BASE + 'distribution/distribution.json';
const DOCTOR = BASE + 'distribution/cli.mjs';
const USAGE = 'node distribution.mjs pack --source REPOSITORY --out NEW_DIRECTORY [--ref COMMIT] [--version 0.1.0]';

async function git(root, args) {
  return (await exec('git', ['-C', root, ...args], { encoding: 'buffer', maxBuffer: MAX_BYTES })).stdout;
}
async function objects(root, entries) {
  const child = spawn('git', ['-C', root, 'cat-file', '--batch'], { stdio: ['pipe', 'pipe', 'pipe'] });
  const chunks = []; let length = 0, stderr = '';
  const finished = new Promise((accept, reject) => {
    child.on('error', reject);
    child.stdout.on('data', chunk => {
      length += chunk.length;
      if (length > MAX_BYTES + entries.length * 100) { child.kill(); reject(new Error('Release exceeds size limit')); }
      else chunks.push(chunk);
    });
    child.stderr.on('data', chunk => { stderr += chunk.toString().slice(0, 2000); });
    child.on('close', code => code === 0 ? accept(Buffer.concat(chunks)) : reject(new Error('Git object read failed: ' + stderr)));
  });
  child.stdin.on('error', () => {});
  child.stdin.end(entries.map(entry => entry.oid + '\n').join(''));
  const bytes = await finished, result = new Map(); let offset = 0;
  for (const entry of entries) {
    const end = bytes.indexOf(10, offset);
    const [oid, type, sizeText] = bytes.subarray(offset, end).toString('ascii').split(' ');
    const size = Number(sizeText), start = end + 1;
    if (end < 0 || oid !== entry.oid || type !== 'blob' || !Number.isSafeInteger(size) || size < 0 ||
        start + size >= bytes.length || bytes[start + size] !== 10) throw new Error('Invalid Git object stream');
    result.set(entry.path, bytes.subarray(start, start + size)); offset = start + size + 1;
  }
  if (offset !== bytes.length) throw new Error('Unexpected Git object stream tail');
  return result;
}

export async function pack({ source, out, ref = 'HEAD', version = '0.1.0' }) {
  if (!source || !out || !/^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?$/.test(version) ||
      (ref !== 'HEAD' && !/^[0-9a-f]{40}$/.test(ref))) throw new Error(USAGE);
  source = resolve(source); out = resolve(out);
  if (out === source || out.startsWith(source + '/')) throw new Error('Build the release outside its source checkout');
  const commit = (await git(source, ['rev-parse', '--verify', ref + '^{commit}'])).toString().trim();
  const listing = (await git(source, ['ls-tree', '-r', '-z', commit, '--', ...SCOPES])).toString('utf8');
  const entries = listing.split('\0').filter(Boolean).map(line => {
    const match = /^(100644|100755) blob ([0-9a-f]{40})\t(.+)$/.exec(line);
    if (!match) throw new Error('Release sources must be ordinary tracked files');
    return { mode: match[1] === '100755' ? 0o755 : 0o644, oid: match[2], path: relativePath(match[3]) };
  }).filter(entry => !entry.path.split('/').some(part => ['test', 'tests', 'node_modules', '.git'].includes(part)) &&
    !/\.test\.[^.]+$/.test(entry.path)).sort((a, b) => a.path.localeCompare(b.path, 'en'));
  const sourceBytes = await objects(source, entries);
  const nativeSource = sourceBytes.get(BASE + 'sf30-seller-sdk/native-factory.mjs')?.toString('utf8') ?? '';
  const nativeVersion = /NATIVE_SDK_VERSION\s*=\s*'([0-9]+\.[0-9]+\.[0-9]+)'/.exec(nativeSource)?.[1];
  if (!nativeVersion) throw new Error('Native seller has no explicit SDK version');
  const catalogBytes = sourceBytes.get(CATALOG);
  if (!catalogBytes || !sourceBytes.has(DOCTOR)) throw new Error('Original command catalog and doctor are required');
  const { catalog, commands, commandCatalog } = compileCommandCatalog(catalogBytes,
    path => sourceBytes.has(path), { sourcePaths: [...sourceBytes.keys()], readSource: path => sourceBytes.get(path) });
  const launcher = sourceBytes.get(BASE + 'sf46-release/product.mjs');
  const core = sourceBytes.get(BASE + 'sf46-release/release-core.mjs');
  if (!launcher || !core) throw new Error('Commit the product release source before packaging');
  const nativePackages = Object.fromEntries(['@x402/core', '@x402/stellar', '@x402/extensions', '@x402/fetch'].map(name => [name, nativeVersion]));
  const adapterPackages = Object.create(null), adapterPackageSources = {}, adapterPackageHashes = {};
  const featurePeers = { ...catalog.featurePeers };
  for (const [group, declaredPath] of Object.entries(catalog.runtimePackageManifests ?? {})) {
    const path = relativePath(declaredPath), bytes = sourceBytes.get(path);
    if (!bytes) throw new Error('Original runtime dependency manifest missing: ' + path);
    const dependencies = JSON.parse(bytes).dependencies;
    if (!dependencies || typeof dependencies !== 'object' || Array.isArray(dependencies) || !Object.keys(dependencies).length)
      throw new Error('Original production dependencies missing: ' + path);
    const declaredPeers = featurePeers[group] ?? {};
    featurePeers[group] = {};
    for (const [name, version] of Object.entries(dependencies)) {
      if (!/^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/.test(name) ||
          !/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version) ||
          Object.hasOwn(adapterPackages, name) && adapterPackages[name] !== version)
        throw new Error('Conflicting or unpinned original runtime dependency: ' + path);
      adapterPackages[name] = version;
      featurePeers[group][name] = { version, probe: declaredPeers[name]?.probe ?? name };
    }
    adapterPackageSources[group] = path;
    adapterPackageHashes[group] = sha256(bytes);
  }
  const optionalDependencies = { ...nativePackages };
  for (const peers of [catalog.nativePeers ?? {}, ...Object.values(featurePeers)]) {
    for (const [name, value] of Object.entries(peers)) {
      if (!/^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/.test(name) ||
          typeof value?.version !== 'string' || !value.version ||
          Object.hasOwn(optionalDependencies, name) && optionalDependencies[name] !== value.version)
        throw new Error('Conflicting original optional dependency: ' + name);
      optionalDependencies[name] = value.version;
    }
  }
  const additions = new Map([
    ['forge.mjs', launcher], ['release-core.mjs', core],
    ['package.json', Buffer.from(JSON.stringify({ name: 'stellar-forge-portable', version, private: true,
      type: 'module', license: 'MIT', engines: { node: '>=22.16.0' },
      optionalDependencies }, null, 2) + '\n')],
    ['START_HERE.md', Buffer.from(`# Stellar Forge ${version}\n\nSource commit: ${commit}\n\nRun \`node forge.mjs help\` for the product commands.\n\nA cold start, installation, upgrade and rollback guide is included at\n\`${BASE}sf46-release/DISTRIBUTION.md\`.\n\nConfiguration and merchant data belong outside the release. All native command\narguments retain their original meanings and are resolved from your working directory.\nChallenge-only seller, compiler, review and local operations need Node 22.16+ only.\nOptional native payments use the original configured facilitator and signer.\nCommands and optional feature dependencies follow the original maintained catalog at this commit.\nTo install its optional native SDK and adapter dependencies explicitly, run \`npm install --ignore-scripts --omit=dev\`\nin this release directory, then \`node forge.mjs doctor\`. Select specific feature requirements with\n\`node forge.mjs doctor --feature NAME\` or native packages with \`--native\`. Dependency installation\ndoes not configure a facilitator, supply a signer or authorize a payment.\n\nOriginal source and licenses are included. No tests or hosted CI entrypoints are run by this launcher.\n`)],
  ]);
  const files = [...entries.map(entry => ({ path: entry.path, mode: entry.mode, gitBlob: entry.oid,
    bytes: sourceBytes.get(entry.path).length, sha256: sha256(sourceBytes.get(entry.path)) })),
    ...[...additions].map(([path, bytes]) => ({ path, mode: path === 'forge.mjs' ? 0o755 : 0o644, bytes: bytes.length, sha256: sha256(bytes) }))]
    .sort((a, b) => a.path.localeCompare(b.path, 'en'));
  if (files.reduce((sum, item) => sum + item.bytes, 0) > MAX_BYTES) throw new Error('Release exceeds size limit');
  const body = { schema: RELEASE_SCHEMA, product: 'Stellar Forge', version,
    source: { repository: 'woahwhattheheck/public-commons-sprint-2026', commit },
    runtime: { minimumNodeMajor: 22, minimumNodeMinor: 16, nativePackages,
      nativePackageSource: BASE + 'sf30-seller-sdk/native-factory.mjs',
      nativePeers: catalog.nativePeers ?? {}, optionalDependencies, featurePeers,
      adapterPackages, adapterPackageSources, adapterPackageHashes, doctorPath: DOCTOR },
    commandCatalog, commands, files };
  const manifest = { ...body, digest: sha256(canonical(body)) };
  await mkdir(out, { mode: 0o755 });
  try {
    for (const file of files) await putFile(join(out, file.path), additions.get(file.path) ?? sourceBytes.get(file.path), file.mode);
    await putFile(join(out, MANIFEST), JSON.stringify(manifest, null, 2) + '\n');
    const verified = await verifyRelease(out, manifest.digest);
    return { release: out, id: verified.id, digest: manifest.digest, commit,
      files: files.length, bytes: verified.totalBytes, commands: Object.keys(commands) };
  } catch (error) { await rm(out, { recursive: true, force: true }); throw error; }
}

export async function main(args = process.argv.slice(2)) {
  if (args.length === 1 && ['--help', 'help'].includes(args[0])) { console.log(USAGE); return; }
  if (args[0] !== 'pack') throw new Error(USAGE);
  const values = {};
  for (let index = 1; index < args.length; index += 2) {
    const key = args[index];
    if (!['--source', '--out', '--ref', '--version'].includes(key) || values[key] || !args[index + 1]) throw new Error(USAGE);
    values[key] = args[index + 1];
  }
  console.log(JSON.stringify(await pack({ source: values['--source'], out: values['--out'], ref: values['--ref'], version: values['--version'] }), null, 2));
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  main().catch(error => { console.error(error.message); process.exitCode = 1; });
