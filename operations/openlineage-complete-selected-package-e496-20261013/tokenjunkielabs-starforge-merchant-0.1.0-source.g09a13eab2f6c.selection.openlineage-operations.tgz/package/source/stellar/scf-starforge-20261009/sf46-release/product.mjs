#!/usr/bin/env node
// MIT. Install, select and run existing Stellar Forge source releases.
import { spawn } from 'node:child_process';
import { mkdir, readdir, lstat, rm, rename, mkdtemp, unlink } from 'node:fs/promises';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { constants as osConstants } from 'node:os';
import { HOME_SCHEMA, MANIFEST, UPDATE_CLAIMS, sha256, verifyRelease, plainDirectory, boundedFile, putFile, copyVerifiedFile,
  atomicFile, atomicJson, jsonFile, validateId, withHomeLock } from './release-core.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const HELP = `Stellar Forge | portable product

  node forge.mjs install BUNDLE --home DIRECTORY [--expect DIGEST] [--activate]
  node forge.mjs status [--home DIRECTORY]
  node forge.mjs activate RELEASE_ID [--home DIRECTORY]
  node forge.mjs rollback [--home DIRECTORY]
  node forge.mjs verify [BUNDLE] [--expect DIGEST]
  node forge.mjs doctor [--home DIRECTORY] [--native] [--feature NAME]...
  node forge.mjs run COMMAND [--home DIRECTORY] -- ORIGINAL_ARGUMENTS

The first install becomes active. Later installs are staged unless --activate
is supplied. Activation selects code for NEW launches; existing processes keep
their original code. Configuration and merchant state live in home/config and
home/state, outside releases. Native command arguments are passed unchanged.
Use status for command names and paths. No shell, network install, service
restart, payment approval or test runner is added by this launcher.
`;

async function exists(path) {
  try { await lstat(path); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; }
}
function flags(args, allowed) {
  const result = { positional: [] };
  for (let index = 0; index < args.length; index++) {
    const arg = args[index];
    if (!arg.startsWith('--')) { result.positional.push(arg); continue; }
    if (!allowed.includes(arg) || result[arg] !== undefined && arg !== '--feature') throw new Error(HELP);
    if (arg === '--activate' || arg === '--native') result[arg] = true;
    else {
      if (!args[index + 1] || args[index + 1].startsWith('--')) throw new Error(HELP);
      const value = args[++index];
      if (arg === '--feature') {
        result[arg] ??= [];
        if (result[arg].includes(value)) throw new Error(HELP);
        result[arg].push(value);
      } else result[arg] = value;
    }
  }
  return result;
}
async function homeInfo(input) {
  const home = await plainDirectory(input);
  const metadata = await jsonFile(join(home, 'installation.json'));
  if (metadata.schema !== HOME_SCHEMA) throw new Error('Not a Stellar Forge installation: ' + home);
  for (const name of ['config', 'state', 'releases']) {
    if (await plainDirectory(join(home, name)) !== join(home, name)) throw new Error('Installation directory was redirected: ' + name);
  }
  return home;
}
async function activeInfo(home) {
  if (!await exists(join(home, 'active.json'))) return null;
  const state = await jsonFile(join(home, 'active.json'));
  if (state.schema !== 'stellar-forge.active-release.v1') throw new Error('Invalid active release');
  validateId(state.releaseId);
  if (state.previousReleaseId !== null) validateId(state.previousReleaseId);
  if (!/^[0-9a-f]{64}$/.test(state.digest ?? '')) throw new Error('Invalid active release digest');
  return state;
}
async function initialize(home, bundle) {
  await mkdir(home, { recursive: true, mode: 0o700 });
  const path = await plainDirectory(home);
  if (!await exists(join(path, 'installation.json'))) {
    const pendingPath = join(path, 'initializing.json');
    const bootstrap = Object.fromEntries(await Promise.all(['forge.mjs', 'release-core.mjs']
      .map(async name => {
        const file = bundle.files.find(entry => entry.path === name);
        const bytes = await boundedFile(bundle.root, name, file.bytes);
        if (bytes.length !== file.bytes || sha256(bytes) !== file.sha256)
          throw new Error('Release content differs: ' + name);
        return [name, bytes];
      })));
    const tempName = /^(forge\.mjs|release-core\.mjs|initializing\.json|installation\.json)\.new-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
    let pending;
    if (await exists(pendingPath)) {
      pending = await jsonFile(pendingPath);
      if (pending.schema !== HOME_SCHEMA || pending.sourceDigest !== bundle.manifest.digest)
        throw new Error('Resume this interrupted first install with the same release bundle');
    } else {
      const entries = (await readdir(path)).filter(name => name !== UPDATE_CLAIMS &&
        !(name.startsWith('initializing.json.new-') && tempName.test(name)));
      if (entries.length) throw new Error('Install into a new or empty directory');
      pending = { schema: HOME_SCHEMA, createdAt: new Date().toISOString(), sourceDigest: bundle.manifest.digest };
      await atomicJson(pendingPath, pending);
    }
    for (const name of ['releases', 'config', 'state']) {
      await mkdir(join(path, name), { recursive: true, mode: 0o700 });
      if (await plainDirectory(join(path, name)) !== join(path, name)) throw new Error('Invalid installation directory');
    }
    // Only an unfinished installation with this verified source digest reaches
    // here. Repair partial bootstrap bytes from an interrupted older writer, and
    // publish new files only after their complete bytes have been synced.
    for (const [name, bytes] of Object.entries(bootstrap))
      await atomicFile(join(path, name), bytes, name === 'forge.mjs' ? 0o755 : 0o644);
    for (const name of await readdir(path)) if (tempName.test(name)) await unlink(join(path, name));
    await atomicJson(join(path, 'installation.json'), pending);
    await unlink(pendingPath);
  }
  return homeInfo(path);
}
async function selectUnlocked(home, id) {
  validateId(id);
  const release = await verifyRelease(join(home, 'releases', id));
  if (release.id !== id) throw new Error('Release directory identity differs from manifest');
  const before = await activeInfo(home);
  if (before?.releaseId === id) {
    if (before.digest !== release.manifest.digest) throw new Error('Active release digest changed');
    return { ...before, changed: false };
  }
  const state = { schema: 'stellar-forge.active-release.v1', releaseId: id,
    digest: release.manifest.digest, previousReleaseId: before?.releaseId ?? null,
    activatedAt: new Date().toISOString() };
  await atomicJson(join(home, 'active.json'), state);
  return { ...state, changed: true };
}
export async function install(bundleInput, homeInput, { expected, activate = false, prepareInstalledRelease,
  consumePrepared = false } = {}) {
  if (prepareInstalledRelease !== undefined && typeof prepareInstalledRelease !== 'function')
    throw new TypeError('prepareInstalledRelease must be a function');
  if (typeof consumePrepared !== 'boolean') throw new TypeError('consumePrepared must be a boolean');
  const bundle = await verifyRelease(bundleInput, expected), home = resolve(homeInput);
  if (consumePrepared && (!Object.hasOwn(bundle.manifest.origin ?? {}, 'runtimeInstallation') || !prepareInstalledRelease))
    throw new Error('Consuming an owned prepared release requires its runtime attachment');
  if (Object.hasOwn(bundle.manifest.origin ?? {}, 'runtimeInstallation') && !prepareInstalledRelease)
    throw new Error('Use starforge installation adopt-runtime to attach this release to its retained runtime');
  if (home === bundle.root || home.startsWith(bundle.root + '/')) throw new Error('Installation must be outside its release bundle');
  await mkdir(home, { recursive: true, mode: 0o700 });
  return withHomeLock(home, async lockedHome => {
    await initialize(lockedHome, bundle);
    const target = join(lockedHome, 'releases', bundle.id);
    let state = 'ALREADY_INSTALLED';
    if (await exists(target)) {
      await verifyRelease(target, bundle.manifest.digest);
    } else {
      const stage = await mkdtemp(join(lockedHome, 'releases', '.install-'));
      try {
        let preparedStage = stage, consumed = false;
        if (consumePrepared) {
          // The runtime adopter explicitly hands over its own private prepared
          // directory. The child does not already exist on any supported host.
          const ownedStage = join(stage, 'release');
          try { await rename(bundle.root, ownedStage); preparedStage = ownedStage; consumed = true; }
          catch (error) { if (error.code !== 'EXDEV') throw error; }
        }
        if (!consumed) {
          for (const file of bundle.files)
            await copyVerifiedFile(bundle.root, file.path, join(stage, file.path), file);
          await putFile(join(stage, MANIFEST), bundle.manifestBytes);
        }
        // A changed input cannot be promoted after the initial source read.
        await verifyRelease(preparedStage, bundle.manifest.digest);
        await rename(preparedStage, target);
        state = 'INSTALLED';
      } finally { await rm(stage, { recursive: true, force: true }); }
    }
    // A runtime-aware caller prepares the installed dependency attachment under
    // this same lock. Selection only follows successful preparation, including
    // on the first install. Reusing an installed release repeats this idempotent
    // preparation so an interrupted attachment can finish before activation.
    if (prepareInstalledRelease) {
      await prepareInstalledRelease({ home: lockedHome, releaseDirectory: target,
        releaseId: bundle.id, digest: bundle.manifest.digest });
      await verifyRelease(target, bundle.manifest.digest);
    }
    const previous = await activeInfo(lockedHome);
    const selection = activate || !previous ? await selectUnlocked(lockedHome, bundle.id) : previous;
    return { state, home: lockedHome, releaseId: bundle.id, digest: bundle.manifest.digest,
      activeReleaseId: selection.releaseId, staged: selection.releaseId !== bundle.id,
      config: join(lockedHome, 'config'), merchantState: join(lockedHome, 'state') };
  });
}
// Optional selection guards are checked under the same lock used by install/select.
// Reopening a completed target is idempotent; a newer different selection stays intact.
function sameSelection(left, right) {
  return JSON.stringify(left ? [left.releaseId, left.digest, left.previousReleaseId, left.activatedAt] : null) ===
    JSON.stringify(right ? [right.releaseId, right.digest, right.previousReleaseId, right.activatedAt] : null);
}
function selectionChanged() {
  throw Object.assign(new Error('The active release changed; refresh the managed home before selecting another release'),
    { code: 'PRODUCT_SELECTION_CHANGED', status: 409 });
}
export async function activate(homeInput, id, { expectedActive } = {}) {
  const home = await homeInfo(homeInput);
  return withHomeLock(home, async () => {
    const current = await activeInfo(home);
    if (expectedActive !== undefined && !sameSelection(current, expectedActive) && current?.releaseId !== id)
      selectionChanged();
    return selectUnlocked(home, id);
  });
}
export async function rollback(homeInput, { expectedActive } = {}) {
  const home = await homeInfo(homeInput);
  return withHomeLock(home, async () => {
    const state = await activeInfo(home);
    if (expectedActive !== undefined && !sameSelection(state, expectedActive)) {
      if (expectedActive?.previousReleaseId && state?.releaseId === expectedActive.previousReleaseId)
        return selectUnlocked(home, expectedActive.previousReleaseId);
      selectionChanged();
    }
    if (!state?.previousReleaseId) throw new Error('There is no previous release');
    return selectUnlocked(home, state.previousReleaseId);
  });
}
async function selected(input = HERE) {
  const root = await plainDirectory(input);
  if (await exists(join(root, 'installation.json'))) {
    const home = await homeInfo(root), active = await activeInfo(home);
    if (!active) throw new Error('Install or activate a release first');
    const release = await verifyRelease(join(home, 'releases', active.releaseId), active.digest);
    if (release.id !== active.releaseId) throw new Error('Active release identity mismatch');
    return { ...release, home, active };
  }
  return verifyRelease(root);
}
export async function status(input = HERE) {
  const release = await selected(input);
  const releases = [];
  if (release.home) for (const entry of await readdir(join(release.home, 'releases'), { withFileTypes: true })) {
    if (entry.name.startsWith('.install-')) continue;
    if (!entry.isDirectory() || entry.isSymbolicLink()) throw new Error('Unexpected installed release entry');
    validateId(entry.name);
    const manifest = await jsonFile(join(release.home, 'releases', entry.name, MANIFEST));
    releases.push({ id: entry.name, version: manifest.version, sourceCommit: manifest.source?.commit,
      active: entry.name === release.id });
  }
  return { product: 'Stellar Forge', activeReleaseId: release.id, releaseDirectory: release.root,
    digest: release.manifest.digest, sourceCommit: release.manifest.source.commit,
    files: release.files.length, bytes: release.totalBytes, commands: release.manifest.commands,
    ...(release.manifest.commandCatalog ? { commandCatalog: release.manifest.commandCatalog } : {}),
    ...(release.home ? { home: release.home, config: join(release.home, 'config'), state: join(release.home, 'state'),
      previousReleaseId: release.active.previousReleaseId, releases } : {}) };
}
function nodeReady(runtime) {
  const [major, minor] = process.versions.node.split('.').map(Number);
  const requiredMajor = runtime.minimumNodeMajor ?? 22, requiredMinor = runtime.minimumNodeMinor ?? 0;
  return major > requiredMajor || major === requiredMajor && minor >= requiredMinor;
}
export async function doctor(input = HERE, { requireNative = false, requiredFeatures = [] } = {}) {
  const release = await selected(input);
  let maintained = null, exitCode = 0;
  const doctorPath = release.manifest.runtime.doctorPath;
  if (doctorPath) {
    if (!release.files.some(file => file.path === doctorPath) || !doctorPath.endsWith('.mjs'))
      throw new Error('The original dependency doctor is not in the verified release');
    const original = await import(pathToFileURL(join(release.root, doctorPath)).href);
    if (typeof original.doctor !== 'function') throw new Error('Original dependency doctor export missing');
    const previousExitCode = process.exitCode;
    try {
      maintained = await original.doctor({ requireNative, requiredFeatures });
      exitCode = process.exitCode || 0;
    } finally { process.exitCode = previousExitCode; }
  } else if (requiredFeatures.length) {
    throw new Error('This older release has no maintained optional-feature doctor; select a current release');
  }
  async function inspectPackages(declarations) {
    const result = [];
    for (const [name, expected] of Object.entries(declarations ?? {})) {
      let installed = null;
      try { installed = (await jsonFile(join(release.root, 'node_modules', name, 'package.json'))).version; }
      catch (error) { if (error.code !== 'ENOENT') throw error; }
      result.push({ name, requested: expected, installed,
        state: installed === expected ? 'MATCH' : installed ? 'VERSION_DIFFERS' : 'NOT_INSTALLED' });
    }
    return result;
  }
  const packages = await inspectPackages(release.manifest.runtime.nativePackages);
  const adapterPackages = await inspectPackages(release.manifest.runtime.adapterPackages);
  const nativeSdkInstalled = packages.every(pkg => pkg.state === 'MATCH');
  const postgresNames = Object.keys(release.manifest.runtime.featurePeers?.postgres ??
    release.manifest.runtime.adapterPackages ?? {});
  if (!maintained && (!nodeReady(release.manifest.runtime) || requireNative && !nativeSdkInstalled)) exitCode = 1;
  return { node: process.version, nodeReady: maintained?.localSellerReady ?? nodeReady(release.manifest.runtime),
    releaseId: release.id, sourceVerified: true, standardLibraryCommands: 'AVAILABLE', nativePackages: packages,
    nativeSdkInstalled, adapterPackages,
    postgresDriversInstalled: postgresNames.length > 0 && postgresNames.every(name =>
      adapterPackages.some(pkg => pkg.name === name && pkg.state === 'MATCH')),
    ...(maintained ? { dependencyDoctor: { path: doctorPath, sourceCommit: release.manifest.source.commit },
      nativeDependenciesPresent: maintained.nativeDependenciesPresent,
      nativeDependencies: maintained.nativeDependencies, optionalFeatures: maintained.optionalFeatures,
      operatorPython: maintained.operatorPython, operatorPlatform: maintained.operatorPlatform,
      nativeRuntimeConfigured: maintained.nativeRuntimeConfigured } : {}),
    exitCode,
    note: 'SDK presence does not configure or authorize facilitator, signer, network or merchant operations.' };
}
export async function runNative(name, args, input = HERE) {
  const release = await selected(input), command = release.manifest.commands[name];
  if (!nodeReady(release.manifest.runtime)) throw new Error('Selected release requires Node ' +
    release.manifest.runtime.minimumNodeMajor + '.' + (release.manifest.runtime.minimumNodeMinor ?? 0) + ' or newer');
  if (!command) throw new Error('Unknown native command: ' + name + '. Use status to list commands.');
  return new Promise((accept, reject) => {
    const child = spawn(process.execPath, [join(release.root, command.path), ...args], { stdio: 'inherit', shell: false });
    const signals = ['SIGINT', 'SIGTERM'];
    const handlers = signals.map(signal => () => { child.kill(signal); });
    signals.forEach((signal, index) => process.on(signal, handlers[index]));
    const clean = () => signals.forEach((signal, index) => process.removeListener(signal, handlers[index]));
    child.on('error', error => { clean(); reject(error); });
    child.on('close', (code, signal) => { clean(); accept(code ?? (128 + (osConstants.signals[signal] ?? 1))); });
  });
}
export async function main(args = process.argv.slice(2)) {
  const [command, ...rest] = args;
  if (!command || ['help', '--help'].includes(command)) { console.log(HELP); return 0; }
  if (command === 'run') {
    const separator = rest.indexOf('--');
    if (separator < 0) throw new Error(HELP);
    const options = flags(rest.slice(0, separator), ['--home']);
    if (options.positional.length !== 1) throw new Error(HELP);
    return runNative(options.positional[0], rest.slice(separator + 1), options['--home'] ?? HERE);
  }
  const allowed = { install: ['--home', '--expect', '--activate'], activate: ['--home'],
    rollback: ['--home'], status: ['--home'], doctor: ['--home', '--native', '--feature'], verify: ['--expect'] };
  if (!allowed[command]) throw new Error(HELP);
  const options = flags(rest, allowed[command]);
  const home = options['--home'] ?? HERE;
  let result;
  if (command === 'install' && options.positional.length === 1 && options['--home'])
    result = await install(options.positional[0], home, { expected: options['--expect'], activate: options['--activate'] });
  else if (command === 'activate' && options.positional.length === 1) result = await activate(home, options.positional[0]);
  else if (command === 'rollback' && !options.positional.length) result = await rollback(home);
  else if (command === 'status' && !options.positional.length) result = await status(home);
  else if (command === 'doctor' && !options.positional.length) result = await doctor(home,
    { requireNative: options['--native'] ?? false, requiredFeatures: options['--feature'] ?? [] });
  else if (command === 'verify' && options.positional.length <= 1) {
    const release = await verifyRelease(options.positional[0] ?? HERE, options['--expect']);
    result = { id: release.id, digest: release.manifest.digest, files: release.files.length, bytes: release.totalBytes };
  } else throw new Error(HELP);
  console.log(JSON.stringify(result, null, 2));
  return command === 'doctor' ? result.exitCode : 0;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  main().then(code => { process.exitCode = code; }).catch(error => { console.error(error.message); process.exitCode = 1; });
