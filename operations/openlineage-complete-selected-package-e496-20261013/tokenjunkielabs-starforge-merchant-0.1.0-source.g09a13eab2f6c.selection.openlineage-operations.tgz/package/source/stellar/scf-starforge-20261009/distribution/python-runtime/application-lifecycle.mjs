// MIT. Python applications in the original managed runtime lifecycle.
import { constants } from 'node:fs';
import { open, lstat } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { spawn } from 'node:child_process';
import { StringDecoder } from 'node:string_decoder';
import { absolute, canonical, digest, json, need, plain, saveJSON, now } from '../runtime-workspace/storage.mjs';
import { bindPythonApplicationCommand, preparePythonApplicationCommand } from './command-binding.mjs';
import { pythonRuntimeBinding } from './workspace.mjs';

const field=(name,label,type='path',required=false,description='')=>({name,label,type,required,description});
const installation=field('installationId','Installed Python environment','text',true,
  'Select the retained installation from the Python workspace.');
const environment=field('environmentFile','Private environment JSON','path');
const original='stellar/scf-starforge-20261009/sf88-operator-buyer-cli/python/stellar_forge_buyer/';
const key=value=>digest(json(canonical(value)));
export const PYTHON_APPLICATION_CATALOG=Object.freeze([
  {id:'python-dbnomics',python:true,command:'stellar-forge-dbnomics-analysis',terminal:false,
    requiredSource:original+'dbnomics.py',title:'DBnomics analysis and workbook receiving',
    description:'Prepare the complete economic source, produce briefings and workbooks, review returned records and reopen the original editable workspace.',
    fields:[installation,field('argumentsJSON','Original economic-analysis arguments','json',true,
      'JSON array beginning with --operation and its original directory, followed by prepare, receive, finish, return-workbook, return-review, accept-return, adopt-notes, reopen or inspect.'),
      field('nodeExecutable','Original Node executable','path',false,'Defaults to this managed runtime worker’s Node executable.'),environment]},
  {id:'python-vgi',python:true,command:'vgi',terminal:false,
    requiredSource:original+'vgi_service/cli.py',title:'Purchased-result VGI workspace',
    description:'Review complete native query exports, publish retained result tables, manage current access and operate the original VGI listener.',
    fields:[installation,field('workspaceDirectory','Original DuckDB workspace directory','path',true),
      field('port','Private operator port','port',false,'Use 0 to select an available loopback port. The VGI listener is selected inside its original operator.'),
      field('exportRoot','Query export directory','path',false,'Optional private parent for new original query exports.'),
      field('handoffRoot','Warehouse handoff directory','path',false,'Optional private parent for original complete warehouse backups.'),
      environment]},

  {id:'python-postgres',python:true,command:'postgres',terminal:false,
    requiredSource:original+'postgres_http.py',title:'PostgreSQL receiving workspace',
    description:'Review source mappings, import complete dataset editions, compare changes and manage the customer application SQL view.',
    fields:[installation,field('workspaceDirectory','Receiving operator directory','path',true),
      field('connectionEnvironment','Connection environment variable','text',false,'Defaults to SF_BUYER_POSTGRES_DSN. Supply its value through the private environment JSON.'),
      field('databaseSchema','Receiving database schema','text',false,'Defaults to sf_received. First launch creates an empty dedicated receiving schema.'),
      field('port','Local port','port',false,'Use 0 to select an available loopback port.'),environment]},
  {id:'python-duckdb',python:true,command:'duckdb',terminal:false,
    requiredSource:original+'duckdb_cli.py',title:'DuckDB dataset workspace',
    description:'Review acquired datasets, retain source editions, run SQL, compare changes and prepare Parquet exports or a portable workspace.',
    fields:[installation,field('workspaceDirectory','DuckDB workspace directory','path',true),
      field('port','Local port','port',false,'Use 0 to select an available loopback port.'),
      field('exportRoot','Query export directory','path',false,'Optional private sibling parent for new query exports.'),
      field('handoffRoot','Workspace handoff directory','path',false,'Optional private sibling parent for portable handoffs.'),environment]},
  {id:'python-analysis-project',python:true,command:'stellar-forge-analysis-project',terminal:false,
    requiredSource:original+'analysis_projects.py',title:'Open Analysis project',
    description:'Verify a complete project ZIP or directory, receive its editable workspace and open the original Analysis application.',
    fields:[installation,field('projectPath','Complete project ZIP or directory','path',true),
      field('databaseDirectory','Private customer database directory','path',true),
      field('projectCache','Retained project directory','path',false,'For ZIP input; defaults to a private sibling selected by the project manifest.'),
      field('projectSha256','Project ZIP SHA256','text',false,'Optional digest supplied with the complete delivery.'),
      field('operationId','Original receiving operation','text',false,'Optional UUID32. Keep the same operation for a receiving continuation.'),
      field('nodeExecutable','Original Node executable','path',false,'Defaults to this managed runtime worker’s Node executable.'),
      field('port','Local port','port',false,'Use 0 for an available loopback port.'),environment]},
  {id:'python-analysis-project-export',python:true,command:'stellar-forge-analysis-project',terminal:false,
    requiredSource:original+'analysis_projects.py',title:'Export complete Analysis project',
    description:'Save the current customer database, reports, workbooks and retained source in a complete editable project with its offline reader.',
    fields:[installation,field('projectPath','Original complete project ZIP or directory','path',true),
      field('databaseDirectory','Current private customer database','path',true),
      field('outputDirectory','Complete following-delivery directory','path',true),
      field('projectCache','Retained project directory','path',false),
      field('projectSha256','Project ZIP SHA256','text',false),
      field('operationId','Original archive operation','text',false,'Leave empty to bind the archive to this source, database and output directory; an existing UUID32 resumes that exact export.'),
      field('title','Project title','text',false),
      field('nodeExecutable','Original Node executable','path',false),environment]},
  {id:'python-analysis',python:true,command:'analysis',terminal:false,
    requiredSource:original+'analysis_workspace.py',title:'Analysis and workbook workspace',
    description:'Open the original analysis database, workbook sources, refresh review, reports and deliveries with its installed Python environment.',
    fields:[installation,field('databaseDirectory','Analysis database directory','path',true),
      field('lineageConnectionsFile','Lineage collector connections','path',false,'Private named collector configuration; selects original startup files and producer-token references.'),
      field('nodeExecutable','Original Node executable','path',false,'Defaults to this managed runtime worker’s Node executable.'),
      field('port','Local port','port',false,'Use 0 to select an available loopback port.'),environment]},
  {id:'python-workbooks',python:true,command:'workbooks',terminal:false,
    requiredSource:original+'analysis_workbooks.py',title:'Workbook build and receiving',
    description:'Run the original workbook build, receive, inspect or copy command and retain its exact output and operating result.',
    fields:[installation,field('argumentsJSON','Original command arguments','json',true,
      'JSON array; for example ["inspect","--delivery","/private/delivery","--manifest-sha256","EXACT_SHA"].'),environment]},
  {id:'python-workbook-delivery',python:true,command:'workbookDelivery',terminal:false,
    requiredSource:original+'workbook_client.py',title:'Workbook delivery and refresh',
    description:'Run the original recipe or reviewed refresh against the selected analysis database and retained delivery operation.',
    fields:[installation,field('argumentsJSON','Original delivery arguments','json',true,
      'JSON array using --database, --recipe or --refresh-recipe, and --operation.'),environment]},
]);
function argumentsFrom(settings) {
  let args;
  try{args=JSON.parse(settings.argumentsJSON);}catch{need(false,'PYTHON_APPLICATION_ARGUMENTS_INVALID','Use a JSON array of original command arguments.');}
  need(Array.isArray(args) && args.every(item=>typeof item==='string'),'PYTHON_APPLICATION_ARGUMENTS_INVALID');
  return args;
}
function option(args,name) {
  const values=[];
  for(let index=0;index<args.length;index++){
    if(args[index]===name){need(index+1<args.length,'PYTHON_APPLICATION_ARGUMENTS_INVALID');values.push(args[index+1]);}
    else if(args[index].startsWith(name+'='))values.push(args[index].slice(name.length+1));
  }
  need(values.length<=1,'PYTHON_APPLICATION_ARGUMENTS_INVALID','Select '+name+' once.');
  return values[0];
}
async function dbnomicsRetainedReturn(args,directory,inputPath) {
  const id=option(args,'--id'),sha256=option(args,'--sha256');
  need(typeof id==='string' && /^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/.test(id) &&
    typeof sha256==='string' && /^[a-f0-9]{64}$/.test(sha256),'PYTHON_DBNOMICS_RETURN_BINDING_REQUIRED');
  const operationFile=join(directory,'returns',id,'operation.json'),inputs=[];
  let operation;
  try{operation=await privateControl(operationFile);}
  catch(error){if(error.code==='ENOENT')return {args,inputs};throw error;}
  const workflowFile=join(directory,'operation.json'),workflow=await privateControl(workflowFile);
  need(workflow.schema==='stellar-forge.dbnomics-economic-workflow.v1' &&
    operation.schema==='stellar-forge.dbnomics-workbook-return.v1' &&
    operation.id===id && operation.workflow_id===workflow.id &&
    operation.source_document_id===workflow.source?.document_id &&
    operation.returned_file?.sha256===sha256,'PYTHON_DBNOMICS_RETURN_CHANGED');
  inputs.push(await inputPath(operationFile,'file',false,true),
    await inputPath(workflowFile,'file',false,true));
  const retained=join(directory,'returns',id,'returned.xlsx');
  let handle;
  try{handle=await open(retained,constants.O_RDONLY|constants.O_NOFOLLOW);}
  catch(error){if(error.code==='ENOENT')return {args,inputs};throw error;}
  await handle.close();
  // The same returned bytes are already retained by the original workflow.
  // Bind that file instead of requiring an external input that may have moved.
  const selected=[...args];
  const index=selected.findIndex(value=>value==='--file'||value.startsWith('--file='));
  need(index>=0 && option(selected,'--file')!==undefined,'PYTHON_DBNOMICS_RETURN_FILE_REQUIRED');
  if(selected[index]==='--file')selected[index+1]=retained;
  else selected[index]='--file='+retained;
  return {args:selected,inputs};
}
export function pythonApplicationResource(type,settings) {
  if(['duckdb','vgi'].includes(type.command))return key({family:'python-duckdb',directory:settings.workspaceDirectory});
  if(type.command==='postgres')return key({family:'python-postgres',directory:settings.workspaceDirectory});
  if(['analysis','stellar-forge-analysis-project'].includes(type.command))return key({family:'python-analysis',directory:settings.databaseDirectory});
  const args=argumentsFrom(settings);
  if(type.command==='stellar-forge-dbnomics-analysis')return key({family:'python-dbnomics',
    directory:option(args,'--operation')});
  return key({family:'python-workbook',directory:option(args,'--operation')??option(args,'--destination')??
    option(args,'--delivery')??option(args,'--database')??null,args});
}
async function inspectAnalysisProject(root,options) {
  const descriptor=await bindPythonApplicationCommand(root,options);
  const child=spawn(descriptor.python,descriptor.argv,{cwd:descriptor.cwd,shell:false,
    env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'},stdio:['ignore','pipe','pipe']});
  let bytes=Buffer.alloc(0),errorText='',oversized=false;
  child.stdout.on('data',value=>{if(bytes.length+value.length>262144){oversized=true;child.kill('SIGTERM');}else bytes=Buffer.concat([bytes,value]);});
  child.stderr.on('data',value=>{if(errorText.length<4096)errorText+=value.toString('utf8');});
  const timer=setTimeout(()=>child.kill('SIGTERM'),120000);
  try{
    const result=await new Promise((accept,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>accept({code,signal}));});
    need(result.code===0 && !oversized,'PYTHON_ANALYSIS_PROJECT_VERIFICATION_FAILED',
      'The complete original project could not be verified.'+(errorText?' '+errorText.slice(0,1600):''));
    let inspected;
    try{inspected=JSON.parse(bytes.toString('utf8'));}catch{need(false,'PYTHON_ANALYSIS_PROJECT_INSPECTION_INVALID');}
    need(inspected.schema==='stellar-forge.analysis-project-command.v1' && inspected.state==='VERIFIED' &&
      ['zip','directory'].includes(inspected.kind) && /^[a-f0-9]{64}$/.test(inspected.manifest_sha256??'') &&
      /^[a-f0-9]{32}$/.test(inspected.workspace_id??'') &&
      (inspected.kind!=='zip' || /^[a-f0-9]{64}$/.test(inspected.archive?.sha256??'')),
      'PYTHON_ANALYSIS_PROJECT_INSPECTION_INVALID');
    return inspected;
  }finally{clearTimeout(timer);}
}
export async function pythonApplicationCommand(root,type,settings,{
  runtimeId,runtimeDirectory,inputPath,selectedExecutable,applicationEnvironment,
}={}) {
  need(type.python===true && PYTHON_APPLICATION_CATALOG.some(item=>item.id===type.id && item.command===type.command),
    'PYTHON_APPLICATION_KIND_INVALID');
  const binding=await pythonRuntimeBinding(runtimeDirectory,runtimeId),inputs=[];
  let args;
  if(type.command==='postgres'){
    inputs.push(await inputPath(settings.workspaceDirectory,'directory',true,true));
    const connectionEnvironment=settings.connectionEnvironment||'SF_BUYER_POSTGRES_DSN';
    const databaseSchema=settings.databaseSchema||'sf_received';
    need(/^[A-Za-z_][A-Za-z0-9_]*$/.test(connectionEnvironment),'PYTHON_POSTGRES_CONNECTION_ENV_INVALID');
    need(typeof databaseSchema==='string' && Buffer.byteLength(databaseSchema)<=63 &&
      !/[\x00-\x1f\x7f]/.test(databaseSchema),'PYTHON_POSTGRES_SCHEMA_INVALID');
    args=['--connection-env',connectionEnvironment,'--schema',databaseSchema,
      'serve','--workspace',settings.workspaceDirectory,'--port',String(settings.port??0)];
  }else if(['duckdb','vgi'].includes(type.command)){
    inputs.push(await inputPath(settings.workspaceDirectory,'directory',true,true));
    args=['--workspace',settings.workspaceDirectory,type.command==='vgi'?'workspace':'serve','--port',String(settings.port??0)];
    for(const [name,flag] of [['exportRoot','--export-root'],['handoffRoot','--handoff-root']]){
      if(settings[name]){
        inputs.push(await inputPath(settings[name],'directory',true,true));
        args.push(flag,settings[name]);
      }
    }
  }else if(type.command==='analysis'){
    inputs.push(await inputPath(settings.databaseDirectory,'directory',true,true));
    const node=await selectedExecutable(settings.nodeExecutable??process.execPath);
    inputs.push(...node.inputs);
    const lineageConnections=settings.lineageConnectionsFile?absolute(settings.lineageConnectionsFile):null;
    if(lineageConnections)inputs.push(await inputPath(lineageConnections,'file',false,true));
    args=['--database',settings.databaseDirectory,'--checkout',binding.sourceRoot,'--node',node.executable,
      ...(lineageConnections?['--lineage-connections',lineageConnections]:[]),
      'serve','--port',String(settings.port??0)];
  }else if(type.command==='stellar-forge-analysis-project'){
    const project=absolute(settings.projectPath),info=await lstat(project);
    need(info.isFile() || info.isDirectory(),'PYTHON_ANALYSIS_PROJECT_REQUIRED');
    inputs.push(await inputPath(project,info.isDirectory()?'directory':'file',false,false));
    const inspectArgs=['--checkout',binding.sourceRoot,'--project',project];
    if(settings.projectSha256){
      need(/^[a-f0-9]{64}$/.test(settings.projectSha256),'PYTHON_ANALYSIS_PROJECT_DIGEST_INVALID');
      inspectArgs.push('--project-sha256',settings.projectSha256);
    }
    inspectArgs.push('inspect');
    const inspection=await inspectAnalysisProject(root,{
      runtimeId,runtimeDirectory,installationId:settings.installationId,
      command:type.command,args:inspectArgs,
    });
    const exporting=type.id==='python-analysis-project-export';
    inputs.push(await inputPath(settings.databaseDirectory,'directory',!exporting,true));
    const node=await selectedExecutable(settings.nodeExecutable??process.execPath);
    inputs.push(...node.inputs);
    args=['--checkout',binding.sourceRoot,'--project',project,'--database',settings.databaseDirectory,
      '--manifest-sha256',inspection.manifest_sha256,'--workspace-id',inspection.workspace_id,
      '--node',node.executable];
    if(inspection.archive)args.push('--project-sha256',inspection.archive.sha256);
    if(inspection.kind==='zip'){
      const cache=settings.projectCache||join(dirname(settings.databaseDirectory),'analysis-project-'+inspection.manifest_sha256);
      inputs.push(await inputPath(cache,'directory',true,true));
      args.push('--project-cache',cache);
    }
    const operation=settings.operationId||(exporting?key({
      schema:'stellar-forge.analysis-project-archive-selection.v1',
      workspaceId:inspection.workspace_id,manifestSha256:inspection.manifest_sha256,
      databaseDirectory:absolute(settings.databaseDirectory),outputDirectory:absolute(settings.outputDirectory),
    }).slice(0,32):null);
    if(operation!==null)need(/^[a-f0-9]{32}$/.test(operation),'PYTHON_ANALYSIS_PROJECT_OPERATION_INVALID');
    if(exporting){
      inputs.push(await inputPath(settings.outputDirectory,'directory',true,true));
      const title=settings.title||'Analysis project';
      need(typeof title==='string' && title.trim().length>0 && title.length<=240,'PYTHON_ANALYSIS_PROJECT_TITLE_INVALID');
      args.push('export','--operation',operation,'--output',settings.outputDirectory,'--title',title);
    }else{
      args.push('serve','--port',String(settings.port??0));
      if(operation)args.push('--operation',operation);
    }
  }else if(type.command==='stellar-forge-dbnomics-analysis'){
    args=argumentsFrom(settings);
    need(option(args,'--checkout')===undefined && option(args,'--node')===undefined,
      'PYTHON_DBNOMICS_RUNTIME_SELECTED','The installed application supplies its original source and Node executable.');
    let subcommand=null;
    for(let index=0;index<args.length;index++){
      if(['--operation','--wait-seconds'].includes(args[index])){index++;continue;}
      if(args[index].startsWith('--operation=')||args[index].startsWith('--wait-seconds='))continue;
      subcommand=args[index];break;
    }
    need(subcommand!=='serve','PYTHON_DBNOMICS_USE_ANALYSIS_APPLICATION',
      'Open this operation’s analysis directory with the original Analysis and workbook workspace application.');
    const directory=option(args,'--operation');
    need(typeof directory==='string','PYTHON_DBNOMICS_OPERATION_REQUIRED');
    inputs.push(await inputPath(absolute(directory),'directory',true,true));
    if(subcommand==='return-workbook'){
      const resumed=await dbnomicsRetainedReturn(args,absolute(directory),inputPath);
      args=resumed.args;inputs.push(...resumed.inputs);
    }
    for(const [flag,kind,missing] of [
      ['--source','directory',false],['--bundle','file',false],['--selection','file',false],
      ['--project','directory',false],['--file','file',false],['--target','directory',true],
      ['--source-project','directory',true],['--source-receiving-project','directory',true],
    ]){
      const selected=option(args,flag);
      if(selected!==undefined)inputs.push(await inputPath(absolute(selected),kind,missing,true));
    }
    const node=await selectedExecutable(settings.nodeExecutable??process.execPath);
    inputs.push(...node.inputs);
    args=['--checkout',binding.sourceRoot,'--node',node.executable,...args];
  }else{
    args=argumentsFrom(settings);
    for(const [flag,kind,missing,privateOnly] of [
      ['--database','directory',false,true],['--recipe','file',false,false],
      ['--refresh-recipe','file',false,false],['--archive','file',false,false],
      ['--delivery','directory',false,true],['--operation','directory',true,true],
      ['--destination','directory',true,true],
    ]){
      const path=option(args,flag);
      if(path!==undefined)inputs.push(await inputPath(absolute(path),kind,missing,privateOnly));
    }
  }
  const pythonCommand=await bindPythonApplicationCommand(root,{
    runtimeId,runtimeDirectory,installationId:settings.installationId,command:type.command,args,
  });
  if(settings.environmentFile)inputs.push(await inputPath(settings.environmentFile,'file'));
  const env=await applicationEnvironment(settings.environmentFile);
  return {command:type.command,args,inputs,createDirectories:[],terminal:false,pythonCommand,
    ...(settings.environmentFile?{environmentFile:settings.environmentFile,environmentSha256:env.sha256}:{})};
}
export async function validatePythonManagedCommand(root,request,selected) {
  const descriptor=request.pythonCommand;
  need(plain(descriptor) && request.applicationId && request.terminal!==true &&
    PYTHON_APPLICATION_CATALOG.some(item=>item.command===descriptor.command),
    'PYTHON_MANAGED_APPLICATION_REQUIRED');
  need(request.command===descriptor.command && key(request.args)===key(descriptor.args),
    'PYTHON_MANAGED_COMMAND_CHANGED');
  const runtime=selected.runtime;
  need(runtime && ['directory','installationId','profileId','profileSha256','sourceCommit','sourceManifestSha256']
    .every(name=>runtime[name]===descriptor.runtime?.[name]),'PYTHON_MANAGED_RELEASE_CHANGED');
  return preparePythonApplicationCommand(root,descriptor);
}
function launchBody(request) {
  const descriptor=request.pythonCommand;
  return {schema:'stellar-forge.python-command-launch.v1',requestHash:request.requestHash,
    releaseId:request.releaseId,digest:request.releaseDigest,command:request.command,
    executable:descriptor.executable,args:descriptor.argv,cwd:descriptor.cwd,
    binding:descriptor};
}
export async function pythonManagedLaunch(root,request,{leaseFd}={}) {
  await preparePythonApplicationCommand(root,request.pythonCommand,{leaseFd});
  return {...launchBody(request),createdAt:now()};
}
export function assertPythonManagedLaunch(request,launch) {
  const {createdAt,...body}=launch;
  need(typeof createdAt==='string' && key(body)===key(launchBody(request)),
    'PYTHON_MANAGED_LAUNCH_CHANGED');
}
export const pythonManagedStopSignal=request=>['analysis','stellar-forge-analysis-project','duckdb','postgres','vgi'].includes(request.pythonCommand?.command)?'SIGINT':'SIGTERM';
export async function preparePythonManagedChild(root,request,environment,{leaseFd=3}={}) {
  const command=await preparePythonApplicationCommand(root,request.pythonCommand,{leaseFd});
  return {executable:command.executable,args:command.args,
    options:{cwd:command.cwd,shell:false,env:environment,stdio:['ignore','pipe','pipe',leaseFd]}};
}
function privateURL(value) {
  try{
    const url=new URL(value);
    return url.protocol==='http:' && ['127.0.0.1','localhost','[::1]'].includes(url.hostname) &&
      Number(url.port||80)>=1 && Number(url.port||80)<=65535 &&
      url.hash && !url.username && !url.password && value.length<=4096?url:null;
  }catch{return null;}
}
async function privateControl(path) {
  const handle=await open(absolute(path),constants.O_RDONLY|constants.O_NOFOLLOW);
  try{
    const before=await handle.stat();
    need(before.isFile() && before.nlink===1 && !(before.mode&0o077) && before.size<=65536 &&
      (process.getuid===undefined || before.uid===process.getuid()),'PYTHON_APPLICATION_PRIVATE_LAUNCH_REQUIRED');
    const bytes=await handle.readFile(),after=await handle.stat();
    need(bytes.length===before.size && before.size===after.size && before.mtimeMs===after.mtimeMs &&
      before.ctimeMs===after.ctimeMs,'PYTHON_APPLICATION_PRIVATE_LAUNCH_CHANGED');
    let value;
    try{value=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}
    catch{need(false,'PYTHON_APPLICATION_PRIVATE_LAUNCH_INVALID');}
    return value;
  }finally{await handle.close();}
}
const READ_ANALYSIS_IDENTITY="import json,sys\nfrom stellar_forge_buyer.analysis_workspace import AnalysisWorkspace\ns=AnalysisWorkspace.read_state(sys.argv[1])\nprint(json.dumps({'schema':s['schema'],'workspace_id':s['workspace_id'],'database':s['database']}))";
async function originalAnalysisIdentity(descriptor) {
  const database=descriptor.args[descriptor.args.indexOf('--database')+1];
  const child=spawn(descriptor.python,['-I','-c',READ_ANALYSIS_IDENTITY,database],
    {cwd:descriptor.cwd,shell:false,stdio:['ignore','pipe','pipe',3]});
  let bytes=Buffer.alloc(0),errorText='',oversized=false;
  child.stdout.on('data',value=>{if(bytes.length+value.length>65536){oversized=true;child.kill('SIGTERM');}else bytes=Buffer.concat([bytes,value]);});
  child.stderr.on('data',value=>{if(errorText.length<4096)errorText+=value.toString('utf8');});
  const timer=setTimeout(()=>child.kill('SIGTERM'),15000);
  try{
    const exit=await new Promise((accept,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>accept({code,signal}));});
    need(exit.code===0 && !oversized,'PYTHON_APPLICATION_IDENTITY_UNAVAILABLE',
      'The original Analysis database identity could not be reopened.'+(errorText?' '+errorText.slice(0,1000):''));
    return JSON.parse(bytes.toString('utf8'));
  }finally{clearTimeout(timer);}
}
export function observePythonApplicationOutput(request,directory,{pid}={}) {
  const descriptor=request.pythonCommand,ready=descriptor.ready;
  let buffer='',seen=false,closed=false,saving=Promise.resolve(),savedError=null;
  const decoder=new StringDecoder('utf8');
  async function line(text) {
    if(seen || !ready || !['analysis-private-launch','duckdb-private-launch','postgres-private-launch'].includes(ready.kind))return;
    let announcement;
    try{announcement=JSON.parse(text);}catch{return;}
    if(announcement.status!=='LISTENING')return;
    need(announcement.private_launch===ready.file && Number.isInteger(pid) && pid>0,
      'PYTHON_APPLICATION_PRIVATE_LAUNCH_CHANGED');
    const control=await privateControl(ready.file),url=privateURL(control.url);
    need(control.schema===ready.schema && control.pid===pid && url &&
      url.href.split('#')[0]===new URL(announcement.address).href,'PYTHON_APPLICATION_PRIVATE_LAUNCH_CHANGED');
    let source,identityFields;
    if(ready.kind==='postgres-private-launch'){
      const identity=await privateControl(join(ready.directory,'postgres-workspace.json'));
      need(control.directory===ready.directory && url.hostname==='127.0.0.1' &&
        identity.schema==='stellar-forge.postgres-operator.v1' &&
        control.warehouse_schema===ready.databaseSchema &&
        identity.warehouse_schema===control.warehouse_schema &&
        identity.warehouse_id===control.warehouse_id && identity.operator_id===control.operator_id &&
        /^[a-f0-9]{32}$/.test(control.operator_id??'') &&
        /^[a-f0-9-]{36}$/.test(control.warehouse_id??''),'PYTHON_APPLICATION_WORKSPACE_CHANGED');
      source='original-postgres-private-launch';
      identityFields={workspaceDirectory:control.directory,warehouseId:control.warehouse_id,
        databaseSchema:control.warehouse_schema,operatorId:control.operator_id};
    }else if(ready.kind==='duckdb-private-launch'){
      need(control.directory===ready.directory && url.hostname==='127.0.0.1',
        'PYTHON_APPLICATION_WORKSPACE_CHANGED');
      source='original-duckdb-private-launch';
      identityFields={workspaceDirectory:control.directory};
    }else{
      const identity=await originalAnalysisIdentity(descriptor);
      need(identity.schema===ready.schema && identity.workspace_id===control.workspace_id &&
        (ready.expectedWorkspaceId===undefined || ready.expectedWorkspaceId===control.workspace_id),
        'PYTHON_APPLICATION_DATABASE_CHANGED');
      source='original-analysis-private-launch';
      identityFields={workspaceId:control.workspace_id};
    }
    await saveJSON(join(directory,'application-url.json'),{
      schema:'stellar-forge.application-url.v1',applicationId:request.applicationId,
      operationId:directory.split('/').at(-1),command:request.command,
      source,observedAt:now(),url:url.href,...identityFields,
      privateLaunch:ready.file,originalPid:pid,
      pythonInstallation:descriptor.installationId,bindingFingerprint:descriptor.fingerprint,
    });
    seen=true;
  }
  function queue(text){
    saving=saving.then(()=>line(text)).catch(error=>{if(!savedError)savedError=error;});
  }
  return {
    write(bytes){
      if(closed || seen || !ready)return;
      buffer+=decoder.write(bytes);
      const lines=buffer.split(/\r?\n/);buffer=lines.pop();
      for(const text of lines)queue(text);
      if(buffer.length>16384)buffer=buffer.slice(-16384);
    },
    async close(){
      if(!closed){closed=true;buffer+=decoder.end();if(buffer)queue(buffer);}
      await saving;if(savedError)throw savedError;
    },
  };
}
