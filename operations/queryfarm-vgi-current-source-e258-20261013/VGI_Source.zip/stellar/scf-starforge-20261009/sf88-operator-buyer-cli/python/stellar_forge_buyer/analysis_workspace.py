"""A local customer workspace on the original dataset application and database.

Run ``python -m stellar_forge_buyer.analysis_workspace --help``. This module
does not call acquisition.run(), recovery, financial finalization or a signer.
"""
from __future__ import annotations

import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import csv
from datetime import datetime, timezone
import fcntl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import hashlib
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import threading
from urllib.parse import parse_qs, urlsplit
import uuid
import webbrowser

from . import _analysis_ui
from .datasets import DatasetAcquisition
from .dataset_changes import DatasetChanges
from .dataset_profiles import DatasetProfiles
from . import _analysis_profiles_ui
from .analysis_reports import AnalysisReports
from .analysis_report_reviews import ReportReviews
from . import report_reviews_http
from .analysis_exports import AnalysisExports
from .analysis_workbooks import AnalysisWorkbooks
from .workspace_archive import WorkspaceArchives
from ._analysis_export_http import send_export
from .response_tables import AnalysisResponses
from .research_intake import ResearchIntake
from .analysis_synthesis import AnalysisSynthesis
from . import synthesis_http
from .analysis_lineage import AnalysisLineage
from . import lineage_http
from .event_programmes import EventProgrammes
from . import event_programmes_http
from . import worldbank_programmes_http
from . import worldbank_intake_http
from .errors import BuyerError, StateError
from .sqlite_dataset import DatasetDatabase
from .query_stream import reviewed_view_selection
from .storage import digest, dump, parse, private_directory, read

_SCHEMA = "stellar-forge.customer-analysis.v1"
_NAME = re.compile(r"[a-zA-Z][a-zA-Z0-9_-]{0,63}")
_JOB = re.compile(r"[a-f0-9]{32}")
_MAX_BODY = 1024 * 1024
_MAX_DOWNLOAD = 256 * 1024 * 1024


def _json(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def _now():
    return datetime.now(timezone.utc).isoformat()


def _name(value):
    if not isinstance(value, str) or not _NAME.fullmatch(value):
        raise StateError("ANALYSIS_NAME_INVALID")
    return value


def _parameters(value):
    if not isinstance(value, str) or len(value.encode()) > 256 * 1024:
        raise StateError("ANALYSIS_PARAMETERS_INVALID")
    parsed = parse(value.encode())
    if not isinstance(parsed, (dict, list)):
        raise StateError("ANALYSIS_PARAMETERS_ARRAY_OR_OBJECT_REQUIRED")
    values = parsed.values() if isinstance(parsed, dict) else parsed
    if any(item is not None and (type(item) not in (str, int, float, bool)
            or type(item) is int and not -(2**63) <= item < 2**63
            or type(item) is float and not math.isfinite(item)) for item in values):
        raise StateError("ANALYSIS_SQL_SCALAR_PARAMETERS_REQUIRED")
    return parsed


def _query(value):
    if not isinstance(value, dict):
        raise StateError("ANALYSIS_QUERY_REQUIRED")
    sql = value.get("sql")
    if not isinstance(sql, str) or not sql.strip() or len(sql.encode()) > 128 * 1024:
        raise StateError("ANALYSIS_SQL_REQUIRED")
    text = value.get("parameters_text", "[]")
    _parameters(text)
    limit = value.get("max_rows", 1000)
    if type(limit) is not int or not 1 <= limit <= 100_000:
        raise StateError("ANALYSIS_ROW_LIMIT_INVALID")
    return {"sql": sql, "parameters_text": text, "max_rows": limit}


def _cell(value):
    # JavaScript must not round SQLite's exact signed 64-bit integers.
    if value is None:
        return {"type": "null", "text": ""}
    if isinstance(value, bytes):
        return {"type": "blob", "text": base64.b64encode(value).decode("ascii")}
    if type(value) is float and not math.isfinite(value):
        return {"type": "sqlite-real", "text": str(value)}
    return {"type": "integer" if type(value) is int else "number" if type(value) is float else "string", "text": str(value)}


def _value(cell):
    kind, text = cell["type"], cell["text"]
    if kind == "null":
        return None
    if kind == "integer":
        return int(text)
    if kind == "number":
        return float(text)
    if kind == "blob":
        return {"encoding": "base64", "value": text}
    if kind == "sqlite-real":
        return {"encoding": "sqlite-real", "value": text}
    return text


class AnalysisWorkspace:
    """Durable query recipes/results beside the original immutable row tables.

    One workspace process owns background jobs. Other DatasetDatabase clients
    remain supported; original SQLite transactions and view revisions arbitrate
    their imports and activations. Source registration is an operator action.
    """

    def __init__(self, directory, *, checkout=None, node="node", research_connections=None, lineage_connections=None, event_source_cli=None, worldbank_core=None):
        self.database = DatasetDatabase(directory)
        self.checkout = str(Path(checkout).expanduser().resolve()) if checkout else None
        self.node = node
        self._mutex = threading.Lock()
        self._closed = False
        self._owner = os.open(self.database.directory / "analysis.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            info = os.fstat(self._owner)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_mode & 0o077:
                raise StateError("ANALYSIS_PRIVATE_LOCK_REQUIRED")
            fcntl.flock(self._owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BaseException:
            os.close(self._owner)
            raise StateError("ANALYSIS_WORKSPACE_ALREADY_OPEN") from None
        try:
            with self.database._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                db.execute("CREATE TABLE IF NOT EXISTS sf_analysis_format(id INTEGER PRIMARY KEY CHECK(id=1),schema TEXT NOT NULL,workspace_id TEXT NOT NULL)")
                row = db.execute("SELECT * FROM sf_analysis_format WHERE id=1").fetchone()
                if row is None:
                    db.execute("INSERT INTO sf_analysis_format VALUES(1,?,?)", (_SCHEMA, uuid.uuid4().hex))
                elif row["schema"] != _SCHEMA:
                    raise StateError("ANALYSIS_FORMAT_MISMATCH")
                self.identity = db.execute("SELECT workspace_id FROM sf_analysis_format WHERE id=1").fetchone()[0]
                db.execute("CREATE TABLE IF NOT EXISTS sf_analysis_sources(name TEXT PRIMARY KEY,revision INTEGER NOT NULL,record TEXT NOT NULL)")
                db.execute("CREATE TABLE IF NOT EXISTS sf_analysis_queries(name TEXT PRIMARY KEY,revision INTEGER NOT NULL,record TEXT NOT NULL)")
                db.execute("CREATE TABLE IF NOT EXISTS sf_analysis_query_history(sequence INTEGER PRIMARY KEY,name TEXT NOT NULL,revision INTEGER NOT NULL,record TEXT NOT NULL,UNIQUE(name,revision))")
                db.execute("CREATE TABLE IF NOT EXISTS sf_analysis_jobs(sequence INTEGER PRIMARY KEY,id TEXT UNIQUE NOT NULL,kind TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,finished_at TEXT,request TEXT NOT NULL,result TEXT,error TEXT)")
                # No automatic replay. Original imports are idempotent when the
                # operator explicitly retries after an interrupted process.
                db.execute("UPDATE sf_analysis_jobs SET status='INTERRUPTED',finished_at=?,error='WORKSPACE_PROCESS_INTERRUPTED' WHERE status='RUNNING'", (_now(),))
                db.commit()
            self.changes = DatasetChanges(self.database)
            self.profiles = DatasetProfiles(self.database)
            self.reports = AnalysisReports(self.database, encode_cell=_cell, parse_parameters=_parameters, changes=self.changes)
            self.report_reviews = ReportReviews(self)
            self.responses = AnalysisResponses(self.database, checkout=self.checkout, node=self.node, encode_cell=_cell)
            self.research = ResearchIntake(self, connections=research_connections)
            self.synthesis = AnalysisSynthesis(self)
            self.exports = AnalysisExports(self.database, identity=self.identity, read_job=self._job, parse_parameters=_parameters)
            self.exports.recover_completed()
            self.workbooks = AnalysisWorkbooks(self.database, identity=self.identity, reports=self.reports)
            self.workbooks.recover_completed()
            self.archives = WorkspaceArchives(self.database, identity=self.identity, read_job=self._job)
            self.archives.recover_completed()
            self.lineage = AnalysisLineage(self, connections=lineage_connections)
            self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="dataset-analysis")
            self.event_programmes = EventProgrammes(self, source_cli=event_source_cli)
            # Lazy import preserves the original WorldBankAnalysis -> workspace join.
            from .worldbank_programmes import WorldBankProgrammes
            self.worldbank_programmes = WorldBankProgrammes(self, core=worldbank_core)
            from .worldbank_intake import WorldBankIntake
            self.worldbank_intake = WorldBankIntake(self, core=self.worldbank_programmes.core)
        except BaseException:
            try:
                if hasattr(self, "worldbank_intake"):
                    self.worldbank_intake.close()
                if hasattr(self, "worldbank_programmes"):
                    self.worldbank_programmes.close()
                if hasattr(self, "event_programmes"):
                    self.event_programmes.close()
                if hasattr(self, "_executor"):
                    self._executor.shutdown(wait=True)
            finally:
                os.close(self._owner)
            raise

    def close(self):
        # Both programme coordinators may still sequence Analysis jobs.
        # Drain them before marking this workspace closed, without its job mutex.
        self.worldbank_intake.close()
        self.worldbank_programmes.close()
        self.event_programmes.close()
        with self._mutex:
            if self._closed:
                return
            self._closed = True
        self.lineage.close()
        self.synthesis.close()
        self.research.close()
        self.exports.close()
        self.workbooks.close()
        self.archives.close()
        self.profiles.cancel_all()
        self._executor.shutdown(wait=True)
        os.close(self._owner)

    def _acquisition(self, source):
        if self.checkout is None:
            raise StateError("ANALYSIS_ORIGINAL_RUNTIME_CHECKOUT_REQUIRED")
        return DatasetAcquisition(checkout=self.checkout, session=source["session"], node=self.node)

    def register_source(self, name, session, *, room=None, expected_revision=0, expected_native=None):
        """Declare a native session locally; the browser never supplies paths."""
        name = _name(name)
        if type(expected_revision) is not int or expected_revision < 0:
            raise StateError("ANALYSIS_SOURCE_REVISION_REQUIRED")
        session = private_directory(Path(session), create=False)
        room = Path(room).expanduser().absolute() if room else self.database.directory / "analysis-rooms" / name
        room = Path(os.path.abspath(room))
        source = {"name": name, "session": str(session), "room": str(room)}
        report = self._acquisition(source).inspect()
        if not report.get("configurationSha256") or not report.get("sessionId"):
            raise StateError("ANALYSIS_ORIGINAL_SESSION_NOT_READY")
        source.update(session_sha256=digest(read(session / "session.json", 4 * 1024 * 1024)),
                      configuration_sha256=report["configurationSha256"], session_id=report["sessionId"],
                      native_status=report["status"], rows=report.get("acquiredRows"),
                      snapshot=report.get("snapshot"), registered_at=_now())
        if expected_native is not None:
            from .analysis_native import verify_dataset_source
            verify_dataset_source(self, source, report, expected_native)
        with self.database._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT * FROM sf_analysis_sources WHERE name=?", (name,)).fetchone()
            if existing:
                old = parse(existing["record"].encode())
                if all(old.get(key) == source[key] for key in ("session", "room", "session_sha256")):
                    db.commit()
                    if expected_native is not None:
                        return {**old, "native_delivery": source["native_delivery"]}
                    return old
            revision = existing["revision"] if existing else 0
            if revision != expected_revision:
                raise StateError("ANALYSIS_SOURCE_CHANGED")
            source["revision"] = revision + 1
            db.execute("INSERT INTO sf_analysis_sources VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET revision=excluded.revision,record=excluded.record", (name, source["revision"], _json(source)))
            db.commit()
        return source

    def state(self):
        return self._state(self.database, self.identity, self.checkout is not None)

    @staticmethod
    def read_state(directory):
        """Read saved state while its original workspace process is running."""
        database = DatasetDatabase(directory, create=False)
        with database._connection(readonly=True) as db:
            try:
                identity = db.execute("SELECT workspace_id FROM sf_analysis_format WHERE id=1 AND schema=?", (_SCHEMA,)).fetchone()
            except sqlite3.Error:
                raise StateError("ANALYSIS_WORKSPACE_NOT_INITIALIZED") from None
            if identity is None:
                raise StateError("ANALYSIS_FORMAT_MISMATCH")
        return AnalysisWorkspace._state(database, identity[0], False)

    @staticmethod
    def _state(database, identity, can_import):
        with database._connection(readonly=True) as db:
            db.execute("BEGIN")
            sources = [parse(row[0].encode()) for row in db.execute("SELECT record FROM sf_analysis_sources ORDER BY name")]
            queries = [dict(row) for row in db.execute("SELECT name,revision FROM sf_analysis_queries ORDER BY name")]
            jobs = [dict(row) for row in db.execute("SELECT sequence,id,kind,status,created_at,finished_at,error FROM sf_analysis_jobs ORDER BY sequence DESC LIMIT 30")]
            views = database._views(db)
            reports = AnalysisReports.state(db)
            workbooks = AnalysisWorkbooks.state(db)
        return {"schema": _SCHEMA, "workspace_id": identity, "database": str(database.path),
                "can_import": can_import, "sources": sources, "queries": queries, "views": views, "jobs": jobs, "reports": reports, "workbooks": workbooks}

    def save_query(self, name, value, *, expected_revision):
        name, spec = _name(name), _query(value)
        if type(expected_revision) is not int or expected_revision < 0:
            raise StateError("ANALYSIS_QUERY_REVISION_REQUIRED")
        with self.database._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT revision FROM sf_analysis_queries WHERE name=?", (name,)).fetchone()
            revision = row[0] if row else 0
            if revision != expected_revision:
                raise StateError("ANALYSIS_SAVED_QUERY_CHANGED")
            record = {**spec, "name": name, "revision": revision + 1, "saved_at": _now()}
            raw = _json(record)
            db.execute("INSERT INTO sf_analysis_queries VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET revision=excluded.revision,record=excluded.record", (name, revision + 1, raw))
            db.execute("INSERT INTO sf_analysis_query_history(name,revision,record) VALUES(?,?,?)", (name, revision + 1, raw))
            db.commit()
        return record

    def saved_query(self, name, *, revision=None):
        name = _name(name)
        with self.database._connection(readonly=True) as db:
            db.execute("BEGIN")
            if revision is None:
                row = db.execute("SELECT record FROM sf_analysis_queries WHERE name=?", (name,)).fetchone()
            else:
                row = db.execute("SELECT record FROM sf_analysis_query_history WHERE name=? AND revision=?", (name, revision)).fetchone()
            if row is None:
                raise StateError("ANALYSIS_QUERY_NOT_FOUND")
            record = parse(row[0].encode())
            record["head_revision"] = db.execute("SELECT revision FROM sf_analysis_queries WHERE name=?", (name,)).fetchone()[0]
            record["history"] = [dict(r) for r in db.execute("SELECT revision FROM sf_analysis_query_history WHERE name=? ORDER BY revision DESC LIMIT 100", (name,))]
            return record

    def start(self, kind, request):
        """Persist the exact request before dispatch; repeated IDs reuse it."""
        if kind not in {"import", "query", "query-export", "workbook", "backup", "workspace-export", "compare", "change-export", "report", "report-export", "response-preview", "response-import", "profile", "research-capture", "synthesis", "lineage-publish"} or not isinstance(request, dict):
            raise StateError("ANALYSIS_JOB_INVALID")
        job_id = request.get("id")
        if not isinstance(job_id, str) or not _JOB.fullmatch(job_id):
            raise StateError("ANALYSIS_REQUEST_ID_REQUIRED")
        spec = {"id": job_id}
        if kind == "lineage-publish":
            spec.update(self.lineage.prepare(request))
        elif kind == "synthesis":
            spec.update(self.synthesis.prepare(request))
        elif kind == "research-capture":
            spec.update(self.research.prepare(request))
        elif kind == "workspace-export":
            spec.update(self.archives.prepare(request))
        elif kind == "profile":
            spec.update(self.profiles.prepare(request))
        elif kind in {"response-preview", "response-import"}:
            spec.update(self.responses.prepare(kind, request))
        elif kind == "query":
            spec.update(_query(request))
            if not isinstance(request.get("expected_views"), (list, dict)):
                raise StateError("ANALYSIS_REVIEWED_VIEWS_REQUIRED")
            spec["expected_views"] = reviewed_view_selection(request["expected_views"])
        elif kind == "query-export":
            spec.update(self.exports.prepare(request))
        elif kind == "workbook":
            spec.update(self.workbooks.prepare(request))
        elif kind == "report":
            spec.update(self.reports.prepare(request))
        elif kind == "report-export":
            spec.update(self.reports.prepare_export(request))
        elif kind == "compare":
            spec.update(self.changes.prepare(request, check=False))
        elif kind == "change-export":
            spec.update(self.changes.prepare_export(request, check=False))
        elif kind == "import":
            name = _name(request.get("source"))
            mapping = parse(request.get("columns_text", "{}").encode())
            if not isinstance(mapping, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in mapping.items()):
                raise StateError("ANALYSIS_COLUMN_MAPPING_INVALID")
            with self.database._connection(readonly=True) as db:
                row = db.execute("SELECT record FROM sf_analysis_sources WHERE name=?", (name,)).fetchone()
            if row is None:
                raise StateError("ANALYSIS_SOURCE_NOT_FOUND")
            source = parse(row[0].encode())
            if source.get("kind") == "response":
                raise StateError("ANALYSIS_USE_RESPONSE_MAPPING_WORKFLOW")
            if request.get("source_revision") != source["revision"]:
                raise StateError("ANALYSIS_SOURCE_CHANGED")
            spec.update(source=source, columns=mapping)
        raw = _json(spec)
        with self._mutex:
            if self._closed:
                raise StateError("ANALYSIS_WORKSPACE_CLOSED")
            with self.database._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                old = db.execute("SELECT kind,request,status FROM sf_analysis_jobs WHERE id=?", (job_id,)).fetchone()
                if old:
                    if old["kind"] != kind or old["request"] != raw:
                        raise StateError("ANALYSIS_REQUEST_ID_REUSED")
                    resumable = (
                        kind in {"workspace-export", "research-capture", "synthesis", "lineage-publish"} and
                        old["status"] in {"INTERRUPTED", "FAILED", "CANCELLED"}) or (
                        kind in {"response-preview", "response-import"} and
                        old["status"] == "INTERRUPTED")
                    if resumable:
                        if db.execute("SELECT 1 FROM sf_analysis_jobs WHERE status='RUNNING' LIMIT 1").fetchone():
                            raise StateError("ANALYSIS_JOB_RUNNING")
                        if kind == "lineage-publish":
                            self.lineage.resume(db, spec)
                        elif kind == "synthesis":
                            self.synthesis.validate(db, spec)
                            self.synthesis.resume(job_id)
                        elif kind == "research-capture":
                            self.research.resume(job_id)
                        elif kind == "workspace-export":
                            self.archives.resume(job_id)
                        else:
                            # Continue only this already-admitted local request.
                            # Historical source/preview identities remain exact;
                            # a newer source alias does not change the request.
                            original = spec
                            if kind == "response-import":
                                original, _ = self.responses._preview(db, spec)
                            self.responses._source(
                                db, original["source"], original["source_revision"])
                            # execute() verifies the retained source and mapped
                            # bytes again. import_response() atomically reopens
                            # its manifest-derived version if it already committed.
                        db.execute("UPDATE sf_analysis_jobs SET status='RUNNING',error=NULL,finished_at=NULL WHERE id=?", (job_id,))
                        db.commit()
                        self._executor.submit(self._execute, job_id, kind, spec)
                    else:
                        db.commit()
                    return self.job(job_id)
                if db.execute("SELECT 1 FROM sf_analysis_jobs WHERE status='RUNNING' LIMIT 1").fetchone():
                    raise StateError("ANALYSIS_JOB_RUNNING")
                if kind == "lineage-publish":
                    self.lineage.validate(db, spec)
                elif kind == "synthesis":
                    self.synthesis.validate(db, spec)
                elif kind == "research-capture":
                    self.research.validate(db, spec)
                elif kind == "profile":
                    self.profiles.validate(db, spec)
                elif kind in {"response-preview", "response-import"}:
                    self.responses.validate(db, kind, spec)
                elif kind == "compare":
                    self.changes._inputs(db, spec)
                elif kind == "change-export":
                    self.changes._export_input(db, spec)
                elif kind == "report":
                    self.reports._input(db, spec)
                elif kind == "report-export":
                    self.reports._export_input(db, spec)
                elif kind == "workspace-export":
                    self.archives.prepare_intent(job_id, spec)
                db.execute("INSERT INTO sf_analysis_jobs(id,kind,status,created_at,request) VALUES(?,?,'RUNNING',?,?)", (job_id, kind, _now(), raw))
                db.commit()
            self._executor.submit(self._execute, job_id, kind, spec)
        return self.job(job_id)

    def _execute(self, job_id, kind, spec):
        try:
            if kind == "workbook":
                self.workbooks.run(job_id, spec)
                return
            if kind == "query-export":
                self.exports.run(job_id, spec)
                return
            if kind == "profile":
                self.profiles.run(job_id, spec)
                return
            elif kind == "lineage-publish":
                result = self.lineage.run(job_id, spec)
            elif kind == "synthesis":
                result = self.synthesis.run(job_id, spec)
            elif kind == "research-capture":
                result = self.research.run(job_id, spec)
            elif kind == "workspace-export":
                result = self.archives.run(job_id, spec)
            elif kind in {"response-preview", "response-import"}:
                result = self.responses.execute(kind, spec)
            elif kind == "import" and spec["source"].get("kind") == "finalized-dataset":
                from .analysis_native_delivery import import_finalized_source
                result = import_finalized_source(self, spec["source"], spec["columns"])
            elif kind == "import":
                source = spec["source"]
                path = Path(source["session"]) / "session.json"
                if digest(read(path, 4 * 1024 * 1024)) != source["session_sha256"]:
                    raise StateError("ANALYSIS_REGISTERED_SESSION_CHANGED")
                acquisition = self._acquisition(source)
                status = acquisition.inspect()
                if status.get("status") != "COMPLETE":
                    raise StateError("ANALYSIS_COMPLETED_ACQUISITION_REQUIRED")
                delivery = acquisition.deliver(source["room"])
                if digest(read(path, 4 * 1024 * 1024)) != source["session_sha256"]:
                    raise StateError("ANALYSIS_REGISTERED_SESSION_CHANGED")
                result = self.database.import_delivery(delivery, columns=spec["columns"])
                result = {"version": result, "source": source["name"], "source_revision": source["revision"],
                          "native_delivery": {"status": delivery.status, "appended_pages": delivery.native.get("appendedPages"), "payment_status": delivery.payment_status}}
            elif kind == "query":
                with self.database._connection(readonly=True) as db:
                    db.execute("BEGIN")
                    result = self.database._query(db, spec["sql"], _parameters(spec["parameters_text"]), max_rows=spec["max_rows"],
                        max_result_bytes=4 * 1024 * 1024, timeout=20, expected_views=spec["expected_views"])
                    sources = []
                    for table in result.read_tables:
                        if table.startswith("sf_dataset_rows_") and re.fullmatch(r"[a-f0-9]{64}", table[16:]):
                            version = self.database._version(db, table[16:])
                            sources.append({key: value for key, value in version.items()
                                            if key not in {"sourceDirectory", "sequence", "created_at"}})
                result = {"columns": list(result.columns), "rows": [[_cell(v) for v in row] for row in result.rows],
                          "truncated": result.truncated, "views": list(result.views), "read_tables": list(result.read_tables),
                          "source_versions": sources}
                if isinstance(spec["expected_views"], dict):
                    result["view_selection"] = spec["expected_views"]
                result["result_sha256"] = digest(_json(result).encode())
            elif kind == "compare":
                # Difference rows and the COMPLETE job become visible together.
                self.changes.run(job_id, spec)
                return
            elif kind == "change-export":
                result = self.changes.export({key: value for key, value in spec.items() if key != "id"})
            elif kind == "report":
                self.reports.run(job_id, {key: value for key, value in spec.items() if key != "id"})
                return
            elif kind == "report-export":
                result = self.reports.export({key: value for key, value in spec.items() if key != "id"})
            else:
                target = self.database.backup(self.database.directory / "analysis-backups" / job_id)
                with target.open("rb") as stream:
                    sha = hashlib.file_digest(stream, "sha256").hexdigest()
                result = {"path": str(target), "bytes": target.stat().st_size, "sha256": sha, "downloadable": target.stat().st_size <= _MAX_DOWNLOAD}
            raw = _json(result)
            with self.database._connection() as db:
                db.execute("UPDATE sf_analysis_jobs SET status='COMPLETE',result=?,finished_at=? WHERE id=? AND status='RUNNING'", (raw, _now(), job_id))
        except BaseException as exc:
            code = getattr(exc, "code", None) or str(exc) if isinstance(exc, BuyerError) else type(exc).__name__
            if isinstance(exc.__cause__, sqlite3.Error):
                code += ": " + str(exc.__cause__)
            with self.database._connection() as db:
                status = "CANCELLED" if ((kind == "workspace-export" and code == "WORKSPACE_ARCHIVE_CANCELLED") or
                    (kind == "research-capture" and code == "ANALYSIS_RESEARCH_CANCELLED") or
                    (kind == "synthesis" and code == "ANALYSIS_SYNTHESIS_CANCELLED") or
                    (kind == "lineage-publish" and code == "ANALYSIS_LINEAGE_CANCELLED")) else "FAILED"
                db.execute("UPDATE sf_analysis_jobs SET status=?,error=?,finished_at=? WHERE id=? AND status='RUNNING'", (status, str(code)[:256], _now(), job_id))

    def _job(self, job_id):
        if not isinstance(job_id, str) or not _JOB.fullmatch(job_id):
            raise StateError("ANALYSIS_JOB_ID_INVALID")
        with self.database._connection(readonly=True) as db:
            row = db.execute("SELECT * FROM sf_analysis_jobs WHERE id=?", (job_id,)).fetchone()
        if row is None:
            raise StateError("ANALYSIS_JOB_NOT_FOUND")
        job = dict(row)
        job["request"] = parse(job["request"].encode())
        job["result"] = parse(job["result"].encode()) if job["result"] is not None else None
        if job["kind"] == "query" and job["result"] is not None:
            result = job["result"]
            if result.get("result_sha256") != digest(_json({k: v for k, v in result.items() if k != "result_sha256"}).encode()):
                raise StateError("ANALYSIS_RETAINED_RESULT_CHANGED")
        elif job["kind"] == "profile" and job["result"] is not None:
            with self.database._connection(readonly=True) as db:
                job["result"] = self.profiles._report(db, job_id)
        elif job["kind"] == "compare" and job["result"] is not None:
            with self.database._connection(readonly=True) as db:
                job["result"] = self.changes._report(db, job_id)
        elif job["kind"] == "report" and job["result"] is not None:
            with self.database._connection(readonly=True) as db:
                job["result"] = self.reports._report(db, job_id)
        elif job["kind"] == "lineage-publish":
            job["progress"] = self.lineage.progress(job_id)
        elif job["kind"] == "synthesis":
            job["progress"] = self.synthesis.progress(job_id)
        elif job["kind"] == "research-capture":
            job["progress"] = self.research.progress(job_id)
        elif job["kind"] == "query-export":
            job["progress"] = self.exports.progress(job_id)
        elif job["kind"] == "workbook":
            job["progress"] = self.workbooks.progress(job_id)
        elif job["kind"] == "workspace-export":
            job["progress"] = self.archives.progress(job_id)
            job["archive_availability"] = self.archives.availability(job_id, job["status"])
        return job

    def job(self, job_id, *, offset=0, limit=100):
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 250:
            raise StateError("ANALYSIS_RESULT_PAGE_INVALID")
        job = self._job(job_id)
        if job["kind"] == "query" and job["result"] is not None:
            result = job["result"]
            rows = result["rows"]
            result.update(rows=rows[offset:offset + limit], total_rows=len(rows), offset=offset,
                          next_offset=offset + limit if offset + limit < len(rows) else None)
        return job

    def export_result(self, job_id, format):
        job = self._job(job_id)
        if job["kind"] != "query" or job["status"] != "COMPLETE":
            raise StateError("ANALYSIS_COMPLETE_QUERY_REQUIRED")
        result = job["result"]
        if format == "json":
            data = {"schema": _SCHEMA, "id": job_id, "executed_at": job["finished_at"], "request": job["request"],
                    "columns": result["columns"], "rows": [[_value(v) for v in row] for row in result["rows"]],
                    "truncated": result["truncated"], "views": result["views"], "read_tables": result["read_tables"],
                    "result_sha256": result["result_sha256"],
                    "source_versions": result.get("source_versions", [])}
            return (_json(data) + "\n").encode(), "application/json", "analysis-" + job_id + ".json"
        if format != "csv":
            raise StateError("ANALYSIS_EXPORT_FORMAT_INVALID")
        stream = io.StringIO(newline="")
        writer = csv.writer(stream)
        writer.writerow(result["columns"])
        for row in result["rows"]:
            writer.writerow([v["text"] if v["type"] != "null" else "" for v in row])
        return stream.getvalue().encode(), "text/csv;charset=utf-8", "analysis-" + job_id + ".csv"

    def backup_file(self, job_id):
        job = self._job(job_id)
        if job["kind"] != "backup" or job["status"] != "COMPLETE":
            raise StateError("ANALYSIS_COMPLETE_BACKUP_REQUIRED")
        return self.archives.local_output("analysis-backups/" + job_id + "/datasets.sqlite3")

    def change_export_file(self, job_id):
        job = self._job(job_id)
        if job["kind"] != "change-export" or job["status"] != "COMPLETE":
            raise StateError("ANALYSIS_COMPLETE_CHANGE_EXPORT_REQUIRED")
        result = job["result"]
        if not re.fullmatch(r"changes-[a-f0-9]{64}\.(json|csv)", result["filename"]):
            raise StateError("ANALYSIS_CHANGE_EXPORT_LOCATION_CHANGED")
        path = self.archives.local_output("analysis-exports/" + result["filename"])
        return path, result

    def report_export_file(self, job_id):
        job = self._job(job_id)
        if job["kind"] != "report-export" or job["status"] != "COMPLETE":
            raise StateError("ANALYSIS_COMPLETE_REPORT_EXPORT_REQUIRED")
        result = job["result"]
        if not re.fullmatch(r"report-[a-f0-9]{64}\.(html|json|zip)", result["filename"]):
            raise StateError("ANALYSIS_REPORT_EXPORT_LOCATION_CHANGED")
        path = self.archives.local_output("analysis-exports/" + result["filename"])
        return path, result


def serve(workspace, *, port=0):
    """Bind the private operator application only to numeric IPv4 loopback."""
    token = secrets.token_urlsafe(32)

    class Handler(BaseHTTPRequestHandler):
        server_version = "StellarForgeAnalysis"

        def setup(self):
            super().setup()
            self.connection.settimeout(15)

        def log_message(self, *args):
            pass

        def _reply(self, status, body, mime="application/json", name=None):
            if not isinstance(body, bytes):
                body = _json(body).encode()
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(body)))
            self._headers(name)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def _headers(self, name=None):
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' blob:; base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
            if name:
                self.send_header("Content-Disposition", 'attachment; filename="' + name + '"')

        def _file_reply(self, path, record):
            """Verify and stream the same retained file descriptor."""
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(fd, "rb") as stream:
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_mode & 0o077 or info.st_size != record["bytes"]:
                    raise StateError("ANALYSIS_RETAINED_DOWNLOAD_CHANGED")
                if hashlib.file_digest(stream, "sha256").hexdigest() != record["sha256"]:
                    raise StateError("ANALYSIS_RETAINED_DOWNLOAD_CHANGED")
                stream.seek(0)
                self.send_response(200)
                self.send_header("Content-Type", record["mime"])
                self.send_header("Content-Length", str(info.st_size))
                self.send_header("X-Content-SHA256", record["sha256"])
                self._headers(record["filename"])
                self.end_headers()
                if self.command != "HEAD":
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        self.wfile.write(block)

        def _dispatch(self):
            origin = f"http://127.0.0.1:{self.server.server_port}"
            if self.headers.get("Host") != origin[7:] or self.headers.get("Origin", origin) != origin or self.headers.get("Sec-Fetch-Site", "none") not in {"none", "same-origin"}:
                return self._reply(403, {"error": "ANALYSIS_LOCAL_ORIGIN_REQUIRED"})
            url = urlsplit(self.path)
            if url.scheme or url.netloc or url.fragment:
                return self._reply(400, {"error": "ANALYSIS_ROUTE_INVALID"})
            assets = {"/": (_analysis_ui.HTML, "text/html;charset=utf-8"), "/app.js": (_analysis_ui.JS, "text/javascript;charset=utf-8"), "/style.css": (_analysis_ui.CSS, "text/css;charset=utf-8")}
            assets.update(report_reviews_http.assets())
            assets.update(worldbank_intake_http.assets())
            assets.update(synthesis_http.assets())
            assets.update(lineage_http.assets())
            assets.update(event_programmes_http.assets())
            assets.update({"/profiles": (_analysis_profiles_ui.HTML, "text/html;charset=utf-8"),
                           "/profiles.js": (_analysis_profiles_ui.JS, "text/javascript;charset=utf-8"),
                           "/profiles.css": (_analysis_profiles_ui.CSS, "text/css;charset=utf-8")})
            if self.command in {"GET", "HEAD"} and url.path in assets and not url.query:
                body, mime = assets[url.path]
                return self._reply(200, body.encode(), mime)
            if not secrets.compare_digest(self.headers.get("X-Analysis-Capability", ""), token):
                return self._reply(403, {"error": "ANALYSIS_CAPABILITY_REQUIRED"})
            query = parse_qs(url.query, strict_parsing=True)
            if any(len(v) != 1 for v in query.values()):
                raise StateError("ANALYSIS_QUERY_PARAMETERS_INVALID")
            get = lambda key, default=None: query.get(key, [default])[0]
            parts = url.path.strip("/").split("/")
            if report_reviews_http.get(self, workspace, url, query, parts):
                return
            if synthesis_http.get(self, workspace, url, query, parts):
                return
            if lineage_http.get(self, workspace, url, query, parts):
                return
            if event_programmes_http.get(self, workspace, url, query, parts):
                return
            if worldbank_intake_http.get(self, workspace, url, query, parts):
                return
            if worldbank_programmes_http.get(self, workspace, url, query, parts):
                return
            if (self.command in {"GET", "HEAD"} and len(parts) == 4
                    and parts[:2] == ["api", "workbook-runs"] and parts[3] == "file"):
                if set(query) != {"name"}:
                    raise StateError("ANALYSIS_WORKBOOK_FILE_REQUIRED")
                with workspace.workbooks.download(parts[2], get("name")) as (stream, record):
                    send_export(self, stream, record)
                return
            if (self.command in {"GET", "HEAD"} and len(parts) == 4
                    and parts[:2] == ["api", "query-exports"] and parts[3] == "file"):
                if set(query) != {"name"}:
                    raise StateError("ANALYSIS_EXPORT_FILE_REQUIRED")
                with workspace.exports.download(parts[2], get("name")) as (stream, record):
                    send_export(self, stream, record)
                return
            if (self.command in {"GET", "HEAD"} and len(parts) == 5
                    and parts[:2] == ["api", "workspace-archives"] and parts[3] == "files"):
                if query:
                    raise StateError("WORKSPACE_ARCHIVE_DOWNLOAD_PARAMETERS_INVALID")
                with workspace.archives.download(parts[2], parts[4]) as (stream, record):
                    return send_export(self, stream, record)
            if self.command == "GET":
                if url.path == "/api/research-connections":
                    if query:
                        raise StateError("ANALYSIS_RESEARCH_QUERY_INVALID")
                    return self._reply(200, workspace.research.configuration())
                if url.path == "/api/research-captures":
                    if set(query) - {"before", "limit"}:
                        raise StateError("ANALYSIS_RESEARCH_QUERY_INVALID")
                    return self._reply(200, workspace.research.captures(
                        before=int(get("before")) if get("before") is not None else None,
                        limit=int(get("limit", "20"))))
                if url.path == "/api/workbook-sources":
                    if set(query) - {"kind", "before", "limit"}:
                        raise StateError("ANALYSIS_WORKBOOK_PAGE_INVALID")
                    return self._reply(200, workspace.workbooks.sources(kind=get("kind", "query-export"),
                        before=int(get("before")) if get("before") else None, limit=int(get("limit", "25"))))
                if url.path == "/api/workbook-runs":
                    if set(query) - {"before", "limit"}:
                        raise StateError("ANALYSIS_WORKBOOK_PAGE_INVALID")
                    return self._reply(200, workspace.workbooks.history(
                        before=int(get("before")) if get("before") else None, limit=int(get("limit", "25"))))
                if len(parts) == 3 and parts[:2] == ["api", "workbooks"]:
                    if set(query) - {"revision"}:
                        raise StateError("ANALYSIS_WORKBOOK_REVISION_REQUIRED")
                    return self._reply(200, workspace.workbooks.definition(parts[2],
                        revision=int(get("revision")) if get("revision") else None))
                if len(parts) == 4 and parts[:2] == ["api", "workbooks"] and parts[3] == "refresh":
                    if set(query) - {"revision", "sheet", "before", "limit"}:
                        raise StateError("ANALYSIS_WORKBOOK_PAGE_INVALID")
                    return self._reply(200, workspace.workbooks.refresh.candidates(parts[2],
                        revision=int(get("revision")) if get("revision") else None,
                        sheet=int(get("sheet", "0")), before=int(get("before")) if get("before") else None,
                        limit=int(get("limit", "25"))))
                if len(parts) == 4 and parts[:2] == ["api", "workbooks"] and parts[3] == "preview":
                    if set(query) - {"revision", "sheet", "limit"}:
                        raise StateError("ANALYSIS_WORKBOOK_PREVIEW_PAGE_INVALID")
                    return self._reply(200, workspace.workbooks.preview(parts[2],
                        revision=int(get("revision")) if get("revision") else None,
                        sheet=int(get("sheet", "0")), limit=int(get("limit", "20"))))
                if url.path == "/api/profiles":
                    return self._reply(200, workspace.profiles.history(before=int(get("before")) if get("before") else None))
                if url.path == "/api/profile-compare":
                    return self._reply(200, workspace.profiles.compare(get("before"), get("after")))
                if len(parts) == 3 and parts[:2] == ["api", "profiles"]:
                    return self._reply(200, workspace.profiles.document(parts[2]).record)
                if len(parts) == 4 and parts[:2] == ["api", "profiles"]:
                    if parts[3] == "progress":
                        return self._reply(200, {"progress": workspace.profiles.progress(parts[2])})
                    if parts[3] == "frequency":
                        return self._reply(200, workspace.profiles.frequency_query(parts[2], get("column")))
                    if parts[3] == "export":
                        document = workspace.profiles.document(parts[2])
                        if get("expected_sha256") != document.record["sha256"]:
                            raise StateError("DATA_PROFILE_REVIEW_CHANGED")
                        format = get("format", "json")
                        content = document.bytes(format)
                        return self._reply(200, content, "application/json" if format == "json" else "text/html;charset=utf-8", "data-profile-" + parts[2] + "." + format)
                if url.path == "/api/state":
                    return self._reply(200, workspace.state())
                if url.path == "/api/query-exports":
                    if set(query) - {"before", "limit"}:
                        raise StateError("ANALYSIS_EXPORT_PAGE_INVALID")
                    return self._reply(200, workspace.exports.history(
                        before=int(get("before")) if get("before") else None, limit=int(get("limit", "25"))))
                if len(parts) == 3 and parts[:2] == ["api", "response-source"]:
                    return self._reply(200, workspace.responses.describe(parts[2], int(get("revision", "0")),
                        collection=get("collection"), sse_data=get("sse_data", "text")))
                if url.path == "/api/workspace-archives":
                    return self._reply(200, workspace.archives.history(before=int(get("before")) if get("before") else None, limit=int(get("limit", "25"))))
                if url.path == "/api/workspace-archive-review":
                    include = get("include_previous_backups", "false")
                    if include not in {"true", "false"}:
                        raise StateError("WORKSPACE_ARCHIVE_BACKUP_SELECTION_INVALID")
                    return self._reply(200, workspace.archives.review(include_previous_backups=include == "true"))
                if url.path == "/api/versions":
                    return self._reply(200, workspace.database.versions(before=int(get("before")) if get("before") else None, limit=25))
                if len(parts) == 3 and parts[:2] == ["api", "reports"]:
                    return self._reply(200, workspace.reports.definition(parts[2], revision=int(get("revision")) if get("revision") else None))
                if url.path == "/api/report-runs":
                    return self._reply(200, workspace.reports.history(name=get("name"), before=int(get("before")) if get("before") else None))
                if len(parts) == 3 and parts[:2] == ["api", "report-runs"]:
                    return self._reply(200, workspace.reports.result(parts[2], section=int(get("section", "0")), offset=int(get("offset", "0"))))
                if url.path == "/api/report-publications":
                    return self._reply(200, workspace.reports.publications(name=get("name"), before=int(get("before")) if get("before") else None))
                if len(parts) == 3 and parts[:2] == ["api", "report-export"]:
                    path, record = workspace.report_export_file(parts[2])
                    return self._file_reply(path, record)
                if url.path == "/api/changes":
                    return self._reply(200, workspace.changes.history(before=int(get("before")) if get("before") else None))
                if len(parts) == 3 and parts[:2] == ["api", "changes"]:
                    return self._reply(200, workspace.changes.page(parts[2], kind=get("kind", "all"), after=int(get("after", "0"))))
                if len(parts) == 3 and parts[:2] == ["api", "change-export"]:
                    path, record = workspace.change_export_file(parts[2])
                    return self._file_reply(path, record)
                if url.path == "/api/semantic-compare":
                    if set(query) != {"before", "after"}:
                        raise StateError("DATASET_SEMANTIC_COMPARISON_VERSIONS_REQUIRED")
                    return self._reply(200, workspace.database.compare_semantics(get("before"), get("after")))
                if len(parts) == 3 and parts[:2] == ["api", "semantics"]:
                    if query:
                        raise StateError("DATASET_SEMANTIC_QUERY_INVALID")
                    return self._reply(200, workspace.database.semantics(parts[2]))
                if len(parts) == 3 and parts[:2] == ["api", "semantics-file"]:
                    if query:
                        raise StateError("DATASET_SEMANTIC_QUERY_INVALID")
                    raw = workspace.database.semantics_bytes(parts[2])
                    if raw is None:
                        raise StateError("DATASET_SEMANTIC_DICTIONARY_UNAVAILABLE")
                    return self._reply(200, raw, "application/json", "source-semantics.json")
                if len(parts) == 3 and parts[:2] == ["api", "version"]:
                    return self._reply(200, workspace.database.version(parts[2]))
                if len(parts) == 3 and parts[:2] == ["api", "manifest"]:
                    return self._reply(200, workspace.database.manifest_bytes(parts[2]), "application/json", "source-manifest.json")
                if len(parts) == 3 and parts[:2] == ["api", "queries"]:
                    return self._reply(200, workspace.saved_query(parts[2], revision=int(get("revision")) if get("revision") else None))
                if len(parts) == 3 and parts[:2] == ["api", "jobs"]:
                    return self._reply(200, workspace.job(parts[2], offset=int(get("offset", "0"))))
                if len(parts) == 3 and parts[:2] == ["api", "result"]:
                    body, mime, name = workspace.export_result(parts[2], get("format", "json"))
                    return self._reply(200, body, mime, name)
                if len(parts) == 3 and parts[:2] == ["api", "backup"]:
                    path = workspace.backup_file(parts[2])
                    raw = read(path, _MAX_DOWNLOAD)
                    if digest(raw) != workspace._job(parts[2])["result"]["sha256"]:
                        raise StateError("ANALYSIS_BACKUP_CHANGED")
                    return self._reply(200, raw, "application/vnd.sqlite3", "datasets.sqlite3")
            elif self.command == "POST" and not url.query:
                if self.headers.get("Transfer-Encoding") or self.headers.get_content_type() != "application/json":
                    return self._reply(415, {"error": "ANALYSIS_JSON_REQUIRED"})
                length = int(self.headers.get("Content-Length", "0"))
                body_limit = (128 * 1024 * 1024 if url.path == "/api/synthesis-publications" else
                              16 * 1024 * 1024 if url.path in {"/api/synthesis-protocols", "/api/report-review-returns"} else _MAX_BODY)
                if not 0 < length <= body_limit:
                    return self._reply(413, {"error": "ANALYSIS_REQUEST_SIZE_INVALID"})
                raw = self.rfile.read(length)
                if len(raw) != length:
                    raise StateError("ANALYSIS_REQUEST_INCOMPLETE")
                body = parse(raw)
                if not isinstance(body, dict):
                    raise StateError("ANALYSIS_REQUEST_OBJECT_REQUIRED")
                if report_reviews_http.post(self, workspace, url, parts, body):
                    return
                if synthesis_http.post(self, workspace, url, parts, body):
                    return
                if lineage_http.post(self, workspace, url, parts, body):
                    return
                if event_programmes_http.post(self, workspace, url, parts, body):
                    return
                if worldbank_intake_http.post(self, workspace, url, parts, body):
                    return
                if worldbank_programmes_http.post(self, workspace, url, parts, body):
                    return
                if url.path in {"/api/research-dossiers", "/api/research-sources", "/api/research-review", "/api/research-elements"}:
                    return self._reply(200, workspace.research.read(url.path.removeprefix("/api/research-"), body))
                if len(parts) == 4 and parts[:2] == ["api", "research-captures"] and parts[3] == "cancel":
                    if body:
                        raise StateError("ANALYSIS_RESEARCH_CANCEL_FIELDS_INVALID")
                    return self._reply(200, workspace.research.cancel(parts[2]))
                if url.path == "/api/native-finalized-dataset-source":
                    from .analysis_native_delivery import register_finalized_source
                    return self._reply(200, register_finalized_source(workspace, body))
                if url.path == "/api/native-dataset-source":
                    from .analysis_native import attach_dataset
                    return self._reply(200, attach_dataset(workspace, body))
                if len(parts) == 4 and parts[:2] == ["api", "workspace-archives"] and parts[3] == "cancel":
                    if body:
                        raise StateError("WORKSPACE_ARCHIVE_CANCEL_FIELDS_INVALID")
                    return self._reply(200, workspace.archives.cancel(parts[2]))
                if len(parts) == 4 and parts[:2] == ["api", "query-exports"] and parts[3] == "cancel":
                    if body:
                        raise StateError("ANALYSIS_EXPORT_CANCEL_FIELDS_INVALID")
                    return self._reply(200, workspace.exports.cancel(parts[2]))
                if url.path == "/api/native-response-source":
                    return self._reply(200, workspace.responses.register(body.get("name"), "native",
                        native_workspace=body.get("native_workspace"), native_kind=body.get("native_kind"),
                        native_id=body.get("native_id"), native_inbox=body.get("native_inbox"), expected_native=body.get("expected_native"),
                        format=body.get("format"), expected_revision=body.get("expected_revision")))
                if url.path == "/api/object-source":
                    return self._reply(200, workspace.responses.register(body.get("name"), "object",
                        session=body.get("session"), destination=body.get("destination"),
                        format=body.get("format", "json"), expected_revision=body.get("expected_revision", 0)))
                if len(parts) == 4 and parts[:2] == ["api", "workbooks"]:
                    if parts[3] == "refresh-review":
                        return self._reply(200, workspace.workbooks.refresh.review(parts[2], body))
                    if parts[3] == "refresh":
                        return self._reply(200, workspace.workbooks.refresh.save(parts[2], body))
                if len(parts) == 3 and parts[:2] == ["api", "workbooks"]:
                    return self._reply(200, workspace.workbooks.save(parts[2], body))
                if len(parts) == 4 and parts[:2] == ["api", "workbook-runs"] and parts[3] == "cancel":
                    return self._reply(200, workspace.workbooks.cancel(parts[2]))
                if len(parts) == 4 and parts[:2] == ["api", "profiles"]:
                    if parts[3] == "cancel":
                        return self._reply(200, workspace.profiles.cancel(parts[2]))
                    if parts[3] == "review":
                        return self._reply(200, workspace.profiles.save_review(parts[2], body))
                    if parts[3] == "frequency-query":
                        recipe = workspace.profiles.frequency_query(parts[2], body.get("column"))
                        return self._reply(200, workspace.save_query(body.get("name"), recipe, expected_revision=body.get("expected_revision")))
                if url.path == "/api/activate":
                    return self._reply(200, workspace.database.activate(body.get("name"), body.get("version_id"), expected_revision=body.get("expected_revision")))
                if len(parts) == 4 and parts[:2] == ["api", "changes"] and parts[3] == "select":
                    return self._reply(200, workspace.changes.select(parts[2], body))
                if len(parts) == 3 and parts[:2] == ["api", "reports"]:
                    return self._reply(200, workspace.reports.save(parts[2], body))
                if len(parts) == 4 and parts[:2] == ["api", "report-runs"] and parts[3] == "publish":
                    return self._reply(200, workspace.reports.publish(parts[2], body))
                if len(parts) == 3 and parts[:2] == ["api", "queries"]:
                    return self._reply(200, workspace.save_query(parts[2], body, expected_revision=body.get("expected_revision")))
                if len(parts) == 3 and parts[:2] == ["api", "start"]:
                    return self._reply(202, workspace.start(parts[2], body))
            self._reply(404, {"error": "ANALYSIS_NOT_FOUND"})

        def _handle(self):
            try:
                self._dispatch()
            except (BrokenPipeError, ConnectionResetError):
                pass
            except (BuyerError, ValueError, TypeError, OverflowError) as exc:
                code = getattr(exc, "code", None) or str(exc) if isinstance(exc, BuyerError) else "ANALYSIS_REQUEST_INVALID"
                self._reply(409 if "CHANGED" in str(code) or "RUNNING" in str(code) else 400, {"error": str(code)[:256]})
            except Exception:
                self._reply(500, {"error": "ANALYSIS_OPERATION_FAILED"})

        do_GET = do_POST = do_HEAD = _handle

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = False
    url = f"http://127.0.0.1:{server.server_port}/#" + token
    control = workspace.database.directory / "analysis-launch.json"
    dump(control, {"schema": _SCHEMA, "workspace_id": workspace.identity, "url": url, "pid": os.getpid()})
    return server, control, url


def main():
    parser = argparse.ArgumentParser(description="Use original acquired datasets in a durable local analysis workspace.")
    parser.add_argument("--database", required=True, help="Original private DatasetDatabase directory")
    parser.add_argument("--checkout", help="Matching full native Stellar Forge checkout/runtime, required for imports")
    parser.add_argument("--node", default="node")
    parser.add_argument("--event-source-cli", help="Trusted local original SF88 event-feed analysis-source-cli.mjs; browser inputs are data only")
    parser.add_argument("--worldbank-core", help="Original installed World Bank core.py; browser requests select retained sources only")
    parser.add_argument("--research-connections", help="Private named original Research connections; browser requests select aliases only")
    parser.add_argument("--lineage-connections", help="Named original OpenLineage startup/token files; browser requests select aliases only")
    commands = parser.add_subparsers(dest="command", required=True)
    launch = commands.add_parser("serve", help="Open the local browser application")
    launch.add_argument("--port", type=int, default=0)
    launch.add_argument("--open", action="store_true")
    source = commands.add_parser("source", help="Register an existing native acquisition; it never executes it")
    source.add_argument("--name", required=True)
    source.add_argument("--session", required=True)
    source.add_argument("--room", help="Existing SF100 room, or a new private destination")
    source.add_argument("--expected-revision", type=int, default=0)
    research_read = commands.add_parser("research-read", help="Read named Research connections, existing dossiers and retained document editions")
    research_read.add_argument("--action", required=True, choices=["connections", "dossiers", "sources", "review", "elements", "captures"])
    research_read.add_argument("--request", help="Private JSON request file with original selected identities")
    research_capture = commands.add_parser("research-capture", help="Capture one exact reviewed edition into the original source registration; repeat the same request to resume")
    research_capture.add_argument("--request", required=True)
    lineage_read = commands.add_parser("lineage-read", help="Read original completed jobs, reviewed sources, saved publications and receipts")
    lineage_read.add_argument("--action", required=True, choices=["configuration", "jobs", "review", "plans", "plan", "job"])
    lineage_read.add_argument("--request", help="JSON request with the original selected IDs")
    lineage_plan = commands.add_parser("lineage-plan", help="Freeze an exact reviewed lineage source with its original collector selection")
    lineage_plan.add_argument("--request", required=True)
    lineage_publish = commands.add_parser("lineage-publish", help="Publish or explicitly continue the same original plan/job/source key")
    lineage_publish.add_argument("--request", required=True)
    lineage_download = commands.add_parser("lineage-download", help="Save a verified original publication handover or member")
    lineage_download.add_argument("--plan-id", required=True)
    lineage_download.add_argument("--name", required=True, choices=["events.json", "plan.json", "native-bindings.json", "receipts.json", "report.html", "manifest.json", "handover.zip"])
    lineage_download.add_argument("--out", required=True)
    response = commands.add_parser("response", help="Register a retained native API response, original typed stream export, or source document")
    response.add_argument("--name", required=True)
    response.add_argument("--input-kind", required=True, choices=["buyer", "sf31", "stream", "mcp", "object", "document"])
    response.add_argument("--config", help="Original SF88 configuration or SF31 response-file writer options")
    response.add_argument("--result", help="Original SF88 result record or SF31 response-file receipt")
    response.add_argument("--stream-export", help="Original Python StreamDelivery directory")
    response.add_argument("--manifest", help="Original native MCP result .meta.json file or retained source-document source.json")
    response.add_argument("--object-session", help="Existing COMPLETE native ObjectSession directory")
    response.add_argument("--object-destination", help="Selected recorded object assembly; defaults to the latest recorded assembly")
    response.add_argument("--format", choices=["json", "csv"], default="json")
    response.add_argument("--expected-revision", type=int, default=0)
    export = commands.add_parser("workspace-export", help="Export a complete closed customer workspace through the original job")
    export.add_argument("--id", required=True, help="Stable 32-character lowercase hexadecimal operation ID; reuse it to resume")
    export.add_argument("--include-previous-backups", action="store_true")
    commands.add_parser("archive-review", help="Review complete portable workspace outputs and missing retained files")
    commands.add_parser("status", help="Read saved sources, queries, views and work")
    args = parser.parse_args()
    if args.command == "status":
        print(_json(AnalysisWorkspace.read_state(args.database)))
        return
    workspace = AnalysisWorkspace(args.database, checkout=args.checkout, node=args.node,
                                  research_connections=args.research_connections,
                                  lineage_connections=args.lineage_connections, event_source_cli=args.event_source_cli,
                                  worldbank_core=args.worldbank_core)
    try:
        if args.command == "research-read":
            request = parse(read(Path(args.request).expanduser().absolute(), _MAX_BODY)) if args.request else {}
            if args.action == "connections":
                if request:
                    raise StateError("ANALYSIS_RESEARCH_FIELDS_INVALID")
                result = workspace.research.configuration()
            elif args.action == "captures":
                if not isinstance(request, dict) or set(request) - {"before", "limit"}:
                    raise StateError("ANALYSIS_RESEARCH_FIELDS_INVALID")
                result = workspace.research.captures(**request)
            else:
                result = workspace.research.read(args.action, request)
            print(_json(result))
        elif args.command == "research-capture":
            import time
            request = parse(read(Path(args.request).expanduser().absolute(), _MAX_BODY))
            job = workspace.start("research-capture", request)
            while job["status"] == "RUNNING":
                time.sleep(0.1)
                job = workspace.job(job["id"])
            print(_json(job))
            if job["status"] != "COMPLETE":
                raise SystemExit(1)
        elif args.command == "lineage-read":
            request = parse(read(Path(args.request).expanduser().absolute(), _MAX_BODY)) if args.request else {}
            if not isinstance(request, dict):
                raise StateError("ANALYSIS_LINEAGE_FIELDS_INVALID")
            if args.action == "configuration":
                if request:
                    raise StateError("ANALYSIS_LINEAGE_FIELDS_INVALID")
                result = workspace.lineage.configuration()
            elif args.action in {"jobs", "plans"}:
                if set(request) - {"before", "limit"}:
                    raise StateError("ANALYSIS_LINEAGE_FIELDS_INVALID")
                result = getattr(workspace.lineage, args.action)(**request)
            elif args.action == "review":
                result = workspace.lineage.review(request)
            elif args.action == "plan":
                if set(request) != {"id"}:
                    raise StateError("ANALYSIS_LINEAGE_FIELDS_INVALID")
                result = workspace.lineage.plan(request["id"])
            else:
                if set(request) != {"id"}:
                    raise StateError("ANALYSIS_LINEAGE_FIELDS_INVALID")
                result = workspace.job(request["id"])
            print(_json(result))
        elif args.command == "lineage-plan":
            request = parse(read(Path(args.request).expanduser().absolute(), _MAX_BODY))
            print(_json(workspace.lineage.save_plan(request)))
        elif args.command == "lineage-publish":
            import time
            request = parse(read(Path(args.request).expanduser().absolute(), _MAX_BODY))
            job = workspace.start("lineage-publish", request)
            while job["status"] == "RUNNING":
                time.sleep(0.1)
                job = workspace.job(job["id"])
            print(_json(job))
            if job["status"] != "COMPLETE":
                raise SystemExit(1)
        elif args.command == "lineage-download":
            from .storage import write
            result = workspace.lineage.download(args.plan_id, args.name)
            destination = Path(args.out).expanduser().absolute()
            if destination.exists():
                if digest(read(destination, len(result["bytes"]) + 1)) != result["sha256"]:
                    raise StateError("ANALYSIS_LINEAGE_DOWNLOAD_DESTINATION_CHANGED")
            else:
                write(destination, result["bytes"], exclusive=True)
            print(_json({"path": str(destination), "bytes": len(result["bytes"]),
                         "sha256": result["sha256"], "filename": result["filename"], "mime": result["mime"]}))
        elif args.command == "archive-review":
            print(_json(workspace.archives.review()))
        elif args.command == "workspace-export":
            import time
            job = workspace.start("workspace-export", {"id": args.id, "include_previous_backups": args.include_previous_backups})
            while job["status"] == "RUNNING":
                time.sleep(0.1)
                job = workspace.job(args.id)
            print(_json(job))
            if job["status"] != "COMPLETE":
                raise SystemExit(1)
        elif args.command == "source":
            print(_json(workspace.register_source(args.name, args.session, room=args.room, expected_revision=args.expected_revision)))
        elif args.command == "response":
            print(_json(workspace.responses.register(args.name, args.input_kind, config=args.config, result=args.result,
                stream=args.stream_export, manifest=args.manifest, session=args.object_session, destination=args.object_destination,
                format=args.format, expected_revision=args.expected_revision)))
        else:
            server, control, url = serve(workspace, port=args.port)
            print(_json({"status": "LISTENING", "address": url.split("#", 1)[0], "private_launch": str(control)}), flush=True)
            if args.open:
                webbrowser.open(url)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                server.server_close()
    finally:
        workspace.close()


if __name__ == "__main__":
    main()

