"""Private local buyer CLI. Execution delegates to SF88's terminal approval."""
import argparse
import json
import os
import sys

from .client import Buyer
from .errors import BuyerError, DeliveryError
from .inbox import Inbox, InboxError


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkout", default=os.environ.get("STELLAR_FORGE_CHECKOUT"), required=not os.environ.get("STELLAR_FORGE_CHECKOUT"))
    parser.add_argument("--state", help="private application state; required for application-operation commands")
    parser.add_argument("--node", default="node")
    commands = parser.add_subparsers(dest="command", required=True)
    imported = commands.add_parser("import", help="snapshot an existing original SF88 config")
    imported.add_argument("config")
    workspace = commands.add_parser("import-workspace", help="use an existing native operator workspace")
    workspace.add_argument("directory")
    workspace.add_argument("--intent")
    paid_file = commands.add_parser("paid-file", help="prepare an original approved-file purchase")
    paid_file.add_argument("handoff")
    paid_file.add_argument("--workspace", required=True)
    paid_file.add_argument("--intent")
    retrieve = commands.add_parser("retrieve-file", help="download original entitlement; never pay")
    retrieve.add_argument("intent")
    retrieve.add_argument("--out")
    retrieve.add_argument("--claim-env", default="SF101_CLAIM_TOKEN")
    retrieve.add_argument("--timeout-ms", type=int, default=30000)
    retrieve.add_argument("--resume", action=argparse.BooleanOptionalAction, default=None,
                          help="resume the original saved transfer (default: enabled on Linux)")
    for name, help_text in (
            ("inspect-file-transfer", "inspect retained transfer bytes locally"),
            ("reset-file-transfer", "explicitly discard the retained partial; preserve final files")):
        transfer = commands.add_parser(name, help=help_text)
        transfer.add_argument("intent")
        transfer.add_argument("--out")
    recovered_file = commands.add_parser("recover-file", help="read retained product outcome locally")
    recovered_file.add_argument("intent")
    finalized = commands.add_parser("finalize", help="finish original workspace accounting; never purchase")
    finalized.add_argument("intent")
    finalized.add_argument("--outbox")
    finalized.add_argument("--merchant-route")
    recovered_accounting = commands.add_parser("recover-finalization", help="read original accounting views locally")
    recovered_accounting.add_argument("intent")
    history = commands.add_parser("history", help="read purchase, accounting and product history locally")
    history.add_argument("--out", help="write a new private JSON history file")
    prepared = commands.add_parser("prepare", help="select one original saved catalog offer")
    prepared.add_argument("discovery")
    prepared.add_argument("--row", type=int, required=True)
    prepared.add_argument("--accept", type=int, required=True)
    prepared.add_argument("--intent", required=True)
    prepared.add_argument("--url", required=True)
    prepared.add_argument("--method", default="GET")
    configured = commands.add_parser("configure")
    configured.add_argument("intent")
    configured.add_argument("profile")
    for name in ("review", "execute", "recover", "inspect"):
        command = commands.add_parser(name)
        command.add_argument("intent")
    commands.add_parser("list")
    inbox_list = commands.add_parser("inbox-list", help="read original Inbox jobs; no execution")
    inbox_list.add_argument("--inbox", required=True)
    inbox_show = commands.add_parser("inbox-show", help="read one original Inbox intent")
    inbox_show.add_argument("--inbox", required=True)
    inbox_show.add_argument("--intent", required=True)
    inbox_export = commands.add_parser("inbox-export-operations", help="save selected original jobs for Operations review")
    inbox_export.add_argument("--inbox", required=True)
    inbox_export.add_argument("--intent", dest="intent_ids", action="append", required=True)
    inbox_export.add_argument("--out", required=True)
    inbox_export.add_argument("--max-verify-bytes", type=int, default=268_435_456)
    inbox_inspect = commands.add_parser("inbox-inspect-operations", help="inspect the same saved private handoff")
    inbox_inspect.add_argument("--inbox", required=True,
                               help="original Inbox identity; need not remain online for saved-file inspection")
    inbox_inspect.add_argument("--file", required=True)
    args = parser.parse_args()
    if not args.command.startswith("inbox-") and not args.state:
        parser.error("--state is required for application-operation commands")
    try:
        if args.command.startswith("inbox-"):
            inbox = Inbox(checkout=args.checkout, directory=args.inbox, node=args.node)
            if args.command == "inbox-list":
                result = inbox.list()
            elif args.command == "inbox-show":
                result = inbox.show(args.intent)
            elif args.command == "inbox-export-operations":
                result = inbox.export_operations(args.out, intent_ids=args.intent_ids,
                                                 max_verify_bytes=args.max_verify_bytes)
            else:
                result = inbox.inspect_operations(args.file)
            print(json.dumps({"native": result.native, "process": result.process}, indent=2))
            return 0
        buyer = Buyer(checkout=args.checkout, state_dir=args.state, node=args.node)
        if args.command == "import":
            output = buyer.from_config(args.config).inspect()
        elif args.command == "import-workspace":
            output = buyer.from_workspace(args.directory, intent_id=args.intent).inspect()
        elif args.command == "paid-file":
            output = buyer.from_paid_file(args.handoff, workspace=args.workspace, intent_id=args.intent).inspect()
        elif args.command == "prepare":
            output = buyer.prepare(args.discovery, row=args.row, accept=args.accept,
                intent_id=args.intent, url=args.url, method=args.method).inspect()
        elif args.command == "list":
            output = [op.inspect() for op in buyer.list_operations()]
        elif args.command == "history":
            output = buyer.history(destination=args.out)
        else:
            op = buyer.operation(args.intent)
            if args.command == "configure":
                output = op.configure(args.profile).inspect()
            elif args.command == "review":
                reviewed = op.review()
                output = {"configSha256": reviewed.config_sha256, "native": reviewed.native,
                    "nativeWorkspace": reviewed.workspace_directory, "filePromise": reviewed.file_promise}
            elif args.command == "execute":
                reviewed = op.review()
                print(json.dumps({"review": reviewed.native, "filePromise": reviewed.file_promise,
                    "nativeWorkspace": reviewed.workspace_directory}, indent=2), file=sys.stderr)
                result = op.execute(review=reviewed)
                print(json.dumps(result.record, indent=2))
                return 0 if result.ok else 2
            elif args.command == "recover":
                result = op.recover()
                output = result.record if result else op.inspect()
            elif args.command == "retrieve-file":
                output = op.retrieve_file(destination=args.out, claim_env=args.claim_env,
                    timeout_ms=args.timeout_ms, resume=args.resume).record
            elif args.command == "inspect-file-transfer":
                output = op.inspect_file_transfer(destination=args.out).record
            elif args.command == "reset-file-transfer":
                output = op.reset_file_transfer(destination=args.out).record
            elif args.command == "recover-file":
                result = op.recover_file()
                output = result.record if result else op.inspect()
            elif args.command == "finalize":
                result = op.finalize(outbox=args.outbox, merchant_route=args.merchant_route)
                print(json.dumps(result.record, indent=2))
                return 0 if result.finalized else 2
            elif args.command == "recover-finalization":
                result = op.recover_finalization()
                output = result.record if result else op.inspect()
            else:
                output = op.inspect()
        print(json.dumps(output, indent=2))
        return 0
    except BuyerError as error:
        result = {"error": error.code, "operationDirectory":
            str(error.operation.directory) if error.operation else None}
        if isinstance(error, InboxError):
            result.update(inboxDirectory=error.inbox_directory, destination=error.destination)
            if error.result:
                result["process"] = error.result.process
        if isinstance(error, DeliveryError):
            result.update(retainedBytes=error.retained_bytes, resumable=error.resumable)
            if error.partial_path:
                result["partialPath"] = error.partial_path
            if error.transfer_state_path:
                result["transferState"] = error.transfer_state_path
        print(json.dumps(result), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
