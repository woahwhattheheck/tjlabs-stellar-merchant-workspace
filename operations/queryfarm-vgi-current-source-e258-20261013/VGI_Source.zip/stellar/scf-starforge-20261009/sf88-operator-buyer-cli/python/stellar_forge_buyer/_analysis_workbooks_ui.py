"""Workbook definitions, typed previews and retained customer downloads."""

from . import _analysis_workbook_refresh_ui

HTML = r'''
<section id="tab-workbooks" hidden>
<section class="panel">
  <div class="section-head"><div><h2>Customer workbooks</h2><p>Compose complete retained query exports and published report sections into an Excel workbook.</p></div><button id="workbook-new">New workbook</button></div>
  <div class="form-row"><label>Saved workbook<select id="workbook-saved"><option value="">Unsaved workbook</option></select></label><label>Definition revision<select id="workbook-revision"><option value="">—</option></select></label><label>Save as<input id="workbook-name" autocomplete="off" spellcheck="false" placeholder="customer_operations"></label></div>
  <p id="workbook-editor-state" class="muted"></p>
  <label>Workbook title<input id="workbook-title" maxlength="300" placeholder="Customer operations"></label>
  <label>Recipient notes<textarea id="workbook-notes" rows="3" maxlength="16000" placeholder="Scope, reporting period and how to use this workbook."></textarea></label>
  <div class="workbook-source-picker"><h3>Add a complete result</h3>
    <div class="form-row"><label>Source type<select id="workbook-source-kind"><option value="query-export">Complete query exports</option><option value="report">Published report sections</option></select></label><label>Retained result<select id="workbook-source"></select></label><button id="workbook-add">Add worksheet</button></div>
    <p id="workbook-source-info" class="muted"></p><div class="toolbar"><button id="workbook-source-refresh">Refresh sources</button><button id="workbook-source-prev">Newer sources</button><button id="workbook-source-next">Older sources</button></div>
  </div>
  <div class="section-head"><h3>Ordered worksheets and columns</h3></div>
  <p class="hint">Preserve keeps high precision numbers as text. Decimal text retains the original spelling and scale. Every string is literal text, including text beginning with =. Null labels and empty cells are explicit column choices.</p>
  <div id="workbook-sheets"></div>
  <div class="toolbar"><button id="workbook-edition-open">Review newer sources</button><button id="workbook-save">Save workbook definition</button><button id="workbook-preview">Preview saved cells</button><button id="workbook-build" class="primary">Build complete workbook and handoff</button></div>
  <p class="hint">Each saved sheet retains its exact source export or report publication. Results beyond Excel’s sheet row limit continue on numbered sheets.</p>
</section>
<section id="workbook-preview-panel" class="panel" hidden>
  <div class="section-head"><div><h2>Saved cell projection</h2><p id="workbook-preview-info"></p></div><label>Worksheet<select id="workbook-preview-sheet"></select></label></div>
  <div class="table-scroll"><table><thead id="workbook-preview-head"></thead><tbody id="workbook-preview-body"></tbody></table></div>
  <p class="hint">The preview shows up to 20 rows. Workbook delivery includes every source row.</p>
</section>
<section id="workbook-progress-panel" class="panel" hidden aria-live="polite">
  <div class="section-head"><div><h2>Workbook in progress</h2><p id="workbook-progress-info"></p></div><button id="workbook-cancel">Cancel workbook</button></div>
</section>
<section class="panel">
  <div class="section-head"><div><h2>Workbook delivery history</h2><p>Open a retained workbook to download the Excel file or its complete source handoff.</p></div><div class="toolbar"><button id="workbook-history-refresh">Refresh deliveries</button><button id="workbook-history-prev">Newer deliveries</button><button id="workbook-history-next">Older deliveries</button></div></div>
  <div class="table-scroll"><table><thead><tr><th>Started</th><th>Workbook</th><th>Revision</th><th>Status</th><th>Rows</th><th></th></tr></thead><tbody id="workbook-history"></tbody></table></div>
</section>
<section id="workbook-detail" class="panel" hidden>
  <div class="section-head"><div><h2 id="workbook-detail-title">Selected workbook</h2><p id="workbook-detail-info"></p></div><button id="workbook-detail-definition">Open its saved definition</button></div>
  <p id="workbook-detail-status" class="notice" role="status"></p>
  <div id="workbook-detail-complete" hidden>
    <div class="table-scroll"><table><thead><tr><th>Download</th><th>Bytes</th><th>SHA-256</th><th></th></tr></thead><tbody id="workbook-files"></tbody></table></div>
    <p class="hint">The handoff contains workbook.xlsx, the saved definition, every original source output and a manifest. Receive and reopen it offline with the workbook command.</p>
    <details><summary>Saved source bindings and cell conversions</summary><pre id="workbook-detail-bindings"></pre></details>
  </div>
</section>
</section>
'''

CSS = r'''
.workbook-source-picker{margin:20px 0;padding:16px;border:1px solid #bbb;background:#fafafa}
.workbook-sheet{padding:16px;margin:14px 0;border:1px solid #bbb;background:#fff}
.workbook-sheet .table-scroll{margin-top:12px}.workbook-sheet td{vertical-align:top;min-width:125px}
.workbook-sheet td:first-child{min-width:170px}.workbook-sheet td:last-child{min-width:115px}
.workbook-sheet input,.workbook-sheet select{margin:0;min-width:110px}
.workbook-sheet .source-binding{font-size:12px;overflow-wrap:anywhere;color:#555}
.workbook-sheet .column-actions{display:flex;gap:4px}.workbook-sheet .column-actions button{padding:5px 8px}
#workbook-files .code{max-width:450px;overflow-wrap:anywhere}#workbook-detail-bindings{max-height:500px;overflow:auto}
#workbook-preview-body td{white-space:pre-wrap;max-width:420px;overflow-wrap:anywhere}
#workbook-preview-body small{display:block;color:#666;font-size:11px}
#workbook-progress-info,#workbook-source-info{overflow-wrap:anywhere}
@media(max-width:760px){.workbook-sheet{padding:10px}.workbook-source-picker{padding:12px}.workbook-source-picker .form-row{display:block}}
'''

JS = r'''
window.customerWorkbooks=(() => {
  'use strict';
  const w={loaded:null,base:'',editor:{sheets:[]},ready:false,sources:null,sourceBefore:null,sourcePages:[],history:null,before:null,pages:[],selected:null,active:null,savePending:null,runPending:null,edition:null};
  const types=[['native','Native value'],['text','Text'],['integer','Integer'],['number','Number'],['decimal-text','Decimal text'],['boolean','Boolean'],['date','ISO date'],['datetime-utc','Timestamp → UTC'],['datetime-local','Local timestamp'],['binary-base64','Binary → Base64']];
  const clone=value=>JSON.parse(JSON.stringify(value));
  const key=()=>s.data?'sf-workbook-draft:'+s.data.workspace_id:null;
  function value(){return {name:$('workbook-name').value.trim(),title:$('workbook-title').value,notes:$('workbook-notes').value,sheets:clone(w.editor.sheets)};}
  const changed=()=>JSON.stringify(value())!==w.base;
  function remember(){if(key())try{localStorage.setItem(key(),JSON.stringify({editor:value(),loaded:w.loaded,base:w.base,savePending:w.savePending,runPending:w.runPending,edition:w.edition,selected:w.selected?.id}));}catch{}label();editionRender();}
  function label(){$('workbook-editor-state').textContent=(w.loaded?'Loaded revision '+w.loaded.definition.revision+'; next save compares with revision '+w.loaded.head_revision+'.':'New workbook definition.')+(changed()?' Unsaved changes.':'');}
  function choose(tag,values,current,onchange){const input=document.createElement(tag);for(const [val,text] of values){const option=node('option',text);option.value=val;input.append(option);}input.value=current;input.addEventListener('change',()=>{onchange(input.value);remember();controls();});return input;}
  function field(current,onchange){const input=document.createElement('input');input.value=current;input.addEventListener('input',()=>{onchange(input.value);remember();controls();});return input;}
  function setEditor(definition,loaded=null){w.edition=null;w.editor={sheets:clone(definition.sheets||[])};w.loaded=loaded;$('workbook-name').value=definition.name||'';$('workbook-title').value=definition.title||'';$('workbook-notes').value=definition.notes||'';$('workbook-preview-panel').hidden=true;$('workbook-preview-sheet').replaceChildren();w.base=JSON.stringify(value());renderSheets();renderSaved();remember();}
  function renderSaved(){const select=$('workbook-saved');select.replaceChildren();const blank=node('option','Unsaved workbook');blank.value='';select.append(blank);for(const item of s.data?.workbooks||[]){const option=node('option',item.title+' · revision '+item.revision);option.value=item.name;select.append(option);}select.value=w.loaded?.definition.name||'';const revisions=$('workbook-revision');revisions.replaceChildren();if(w.loaded){for(const item of w.loaded.history){const option=node('option','Revision '+item.revision);option.value=item.revision;revisions.append(option);}revisions.value=w.loaded.definition.revision;}else revisions.append(node('option','—'));}
  function sourceColumnPicker(sheet,column){
    if(sheet.source.kind!=='report')return choose('select',[['','Choose source column'],...sheet.source.columns.map(name=>[name,name])],column.source,val=>column.source=val);
    const names=sheet.source.columns,matches=names.map((name,index)=>name===column.source?index:-1).filter(index=>index>=0);
    const index=Number.isInteger(column.source_index)&&names[column.source_index]===column.source?column.source_index:column.source_index===undefined&&matches.length===1?matches[0]:null;
    return choose('select',[['','Choose source position'],...names.map((name,index)=>[String(index),'Column '+(index+1)+' · '+name])],index===null?'':String(index),val=>{if(val===''){column.source='';delete column.source_index;return;}column.source_index=Number(val);column.source=names[column.source_index];});
  }
  function newColumn(source,index,headers){
    const name=source.columns[index];let header=name,suffix=2;
    while(headers.has(header.toLowerCase()))header=name+' ('+(suffix++)+')';
    headers.add(header.toLowerCase());
    return {source:name,...(source.kind==='report'?{source_index:index}:{}),header,type:'native',null:'text',null_text:'NULL',precision:'preserve'};
  }
  function allColumns(source){const headers=new Set();return source.columns.map((name,index)=>newColumn(source,index,headers));}
  function renderSheets(){const parent=$('workbook-sheets');parent.replaceChildren();w.editor.sheets.forEach((sheet,index)=>{
    const box=node('section',undefined,'workbook-sheet'),heading=node('div',undefined,'section-head'),left=node('label','Worksheet name');left.append(field(sheet.name,val=>sheet.name=val));const buttons=node('div',undefined,'toolbar');
    for(const [text,delta] of [['Up',-1],['Down',1]]){const b=button(text,()=>{const target=index+delta;if(target<0||target>=w.editor.sheets.length)return;[w.editor.sheets[index],w.editor.sheets[target]]=[w.editor.sheets[target],w.editor.sheets[index]];renderSheets();remember();});b.disabled=index+delta<0||index+delta>=w.editor.sheets.length;buttons.append(b);}
    buttons.append(button('Remove worksheet',()=>{w.editor.sheets.splice(index,1);renderSheets();remember();}));heading.append(left,buttons);box.append(heading,node('p',sheet.source.label+' · '+sheet.source.row_count+' rows · '+sheet.source.kind+' '+sheet.source.id+' · SHA-256 '+sheet.source.sha256,'source-binding'));
    const scroll=node('div',undefined,'table-scroll'),table=node('table'),head=node('thead'),row=node('tr');for(const title of ['Source column','Excel heading','Cell type','Null display','Null label','Numeric precision','Order'])row.append(node('th',title));head.append(row);const body=node('tbody');
    sheet.columns.forEach((column,ci)=>{const tr=node('tr');cell(tr).append(sourceColumnPicker(sheet,column));cell(tr).append(field(column.header,val=>column.header=val));cell(tr).append(choose('select',types,column.type,val=>column.type=val));cell(tr).append(choose('select',[['text','Text label'],['blank','Empty cell']],column.null,val=>column.null=val));cell(tr).append(field(column.null_text,val=>column.null_text=val));cell(tr).append(choose('select',[['preserve','Preserve exact value'],['excel-number','Use Excel numeric precision']],column.precision,val=>column.precision=val));const actions=node('div',undefined,'column-actions');for(const [text,delta] of [['↑',-1],['↓',1]]){const b=button(text,()=>{const target=ci+delta;if(target<0||target>=sheet.columns.length)return;[sheet.columns[ci],sheet.columns[target]]=[sheet.columns[target],sheet.columns[ci]];renderSheets();remember();});b.setAttribute('aria-label',(delta<0?'Move up ':'Move down ')+column.header);b.disabled=ci+delta<0||ci+delta>=sheet.columns.length;actions.append(b);}const remove=button('×',()=>{sheet.columns.splice(ci,1);renderSheets();remember();});remove.setAttribute('aria-label','Remove '+column.header);actions.append(remove);cell(tr).append(actions);body.append(tr);});
    table.append(head,body);scroll.append(table);box.append(scroll,button('Add column',()=>{sheet.columns.push(newColumn(sheet.source,0,new Set(sheet.columns.map(column=>column.header.toLowerCase()))));renderSheets();remember();}));parent.append(box);
  });if(!w.editor.sheets.length)parent.append(node('p','Choose a completed source above to add the first worksheet.','muted'));}
  function sourceInfo(){const item=w.sources?.items[Number($('workbook-source').value)];$('workbook-source-info').textContent=item?(item.available===false?item.error:item.row_count+' complete rows · '+item.columns.length+' columns · '+item.id+' · SHA-256 '+item.sha256):'Complete query exports with typed JSONL or published report sections appear here.';}
  async function sources(before=null,pages=[]){const kind=$('workbook-source-kind').value;w.sources=await api('/api/workbook-sources?kind='+kind+(before?'&before='+before:''));w.sourceBefore=before;w.sourcePages=pages;const select=$('workbook-source');select.replaceChildren();w.sources.items.forEach((item,index)=>{const option=node('option',item.available===false?item.id+' · typed JSONL required':item.label+' · '+item.row_count+' rows');option.value=index;option.disabled=item.available===false;select.append(option);});const first=w.sources.items.findIndex(item=>item.available!==false);select.value=first<0?'':String(first);sourceInfo();controls();}
  function addSheet(){const source=w.sources?.items[Number($('workbook-source').value)];if(!source||source.available===false)throw Error('Choose an available complete source.');let name='Data '+(w.editor.sheets.length+1);while(w.editor.sheets.some(item=>item.name.toLowerCase()===name.toLowerCase()))name+='a';w.editor.sheets.push({name,source:clone(source),columns:allColumns(source)});renderSheets();remember();}
  async function load(name,revision){if(!name)return;if(changed()&&!confirm('Discard the unsaved workbook changes?'))return;const result=await api('/api/workbooks/'+encodeURIComponent(name)+(revision?'?revision='+revision:''));w.savePending=null;setEditor(result.definition,result);tab('workbooks');message('Opened '+name+' revision '+result.definition.revision+'.');}
  async function save(){if(w.edition)return saveEdition();const current=value(),expected=w.loaded?.definition.name===current.name?w.loaded.head_revision:0;const request={...current,expected_revision:expected},fingerprint=JSON.stringify(request);if(w.savePending?.key!==fingerprint)w.savePending={key:fingerprint,request:{id:id(),...request}};remember();const saved=await api('/api/workbooks/'+encodeURIComponent(current.name),w.savePending.request);const result=await api('/api/workbooks/'+encodeURIComponent(saved.name)+'?revision='+saved.revision);w.savePending=null;setEditor(result.definition,result);await refresh();message('Saved workbook '+saved.name+' revision '+saved.revision+'.');}
  async function preview(){if(!w.loaded||changed())throw Error('Save the workbook definition before previewing it.');const index=Number($('workbook-preview-sheet').value||0);const result=await api('/api/workbooks/'+encodeURIComponent(w.loaded.definition.name)+'/preview?revision='+w.loaded.definition.revision+'&sheet='+index);const select=$('workbook-preview-sheet');select.replaceChildren();w.loaded.definition.sheets.forEach((sheet,i)=>{const option=node('option',sheet.name);option.value=i;select.append(option);});select.value=index;$('workbook-preview-info').textContent=result.rows.length+' shown of '+result.row_count+' source rows · saved definition '+result.definition_sha256;const head=node('tr');for(const column of result.sheet.columns)head.append(node('th',column.header));$('workbook-preview-head').replaceChildren(head);$('workbook-preview-body').replaceChildren();for(const values of result.rows){const row=node('tr');for(const item of values){const td=cell(row,item.value===null?'[empty cell]':String(item.value));td.append(node('small',item.excel_type+(item.conversion?' · '+item.conversion:'')));}$('workbook-preview-body').append(row);}$('workbook-preview-panel').hidden=false;}
  async function build(){if(!w.loaded||changed())throw Error('Save the complete workbook definition before building.');const request={name:w.loaded.definition.name,revision:w.loaded.definition.revision,definition_sha256:w.loaded.definition_sha256},fingerprint=JSON.stringify(request);if(w.runPending?.key!==fingerprint)w.runPending={key:fingerprint,request:{id:id(),...request}};remember();const job=await api('/api/start/workbook',w.runPending.request);w.runPending=null;s.focusJob=job.id;s.active=job.status==='RUNNING'?job.id:null;w.active=job;remember();progress(job);if(job.status==='RUNNING')schedulePoll();else await open(job.id,job);message('Workbook delivery '+job.status.toLowerCase()+'.');controls();}
  function progress(job){if(job.kind!=='workbook')return;w.active=job.status==='RUNNING'?job:null;$('workbook-progress-panel').hidden=!w.active;const p=job.progress||{};$('workbook-progress-info').textContent=(p.sheet||job.request?.name||'Workbook')+' · '+(p.total_rows||0)+' complete rows written'+(p.cancel_requested?' · cancellation requested':'');controls();}
  function settled(job){if(job.kind!=='workbook')return;progress(job);}
  async function history(before=w.before,pages=w.pages){w.history=await api('/api/workbook-runs'+(before?'?before='+before:''));w.before=before;w.pages=pages;const body=$('workbook-history');body.replaceChildren();for(const item of w.history.items){const row=node('tr');cell(row,stamp(item.created_at));cell(row,item.title||item.name);cell(row,item.revision);cell(row,item.status+(item.error?' · '+item.error:''));cell(row,item.row_count??'—');cell(row).append(button('Open',()=>open(item.id)));body.append(row);}if(!w.history.items.length)empty(body,6,'Build a saved workbook to create the first customer delivery.');controls();}
  async function downloadFile(job,record){let handle=null;if(window.showSaveFilePicker){try{handle=await window.showSaveFilePicker({suggestedName:record.name});}catch(error){if(error.name==='AbortError')return;throw error;}}const response=await fetch('/api/workbook-runs/'+job.id+'/file?name='+encodeURIComponent(record.name),{headers:{'X-Analysis-Capability':capability},cache:'no-store'});if(!response.ok){const failure=await response.json();throw Error(failure.error||'Download failed.');}if(response.headers.get('X-Content-SHA256')!==record.sha256||Number(response.headers.get('Content-Length'))!==record.bytes)throw Error('The retained download metadata changed. Refresh this delivery.');if(handle){const output=await handle.createWritable();try{await response.body.pipeTo(output);}catch(error){try{await output.abort();}catch{}throw error;}}else{const blob=await response.blob();if(blob.size!==record.bytes)throw Error('Download ended before the complete file arrived.');const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=record.name;link.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}message('Downloaded '+record.name+'.');}
  async function open(jobId,provided){const job=provided||await api('/api/jobs/'+jobId);if(job.kind!=='workbook')throw Error('Select a workbook delivery.');w.selected=job;remember();$('workbook-detail').hidden=false;$('workbook-detail-title').textContent=job.result?.title||job.request.name;$('workbook-detail-info').textContent='Definition revision '+job.request.revision+' · '+job.id;$('workbook-detail-status').textContent=job.status+(job.error?' · '+job.error:'');$('workbook-detail-complete').hidden=job.status!=='COMPLETE';const body=$('workbook-files');body.replaceChildren();if(job.status==='COMPLETE'){for(const record of job.result.files){const row=node('tr');cell(row,record.name);cell(row,record.bytes.toLocaleString());cell(row,record.sha256,'code');cell(row).append(button('Download',()=>downloadFile(job,record)));body.append(row);}$('workbook-detail-bindings').textContent=JSON.stringify({definition_sha256:job.result.definition_sha256,manifest_sha256:job.result.manifest_sha256,row_count:job.result.row_count,sheets:job.result.sheets},null,2);}progress(job);tab('workbooks');}
  function controls(){const unavailable=s.busy||!s.data;for(const name of ['workbook-new','workbook-saved','workbook-revision','workbook-name','workbook-title','workbook-notes','workbook-source-kind','workbook-source','workbook-source-refresh','workbook-save','workbook-preview','workbook-build','workbook-history-refresh','workbook-preview-sheet','workbook-detail-definition'])$(name).disabled=unavailable;$('workbook-add').disabled=unavailable||!w.sources?.items.some(item=>item.available!==false)||w.editor.sheets.length>=32;$('workbook-save').disabled||=!w.editor.sheets.length;$('workbook-preview').disabled||=!w.loaded||changed();$('workbook-build').disabled||=!w.loaded||changed()||!!s.active;$('workbook-cancel').disabled=unavailable||!w.active;$('workbook-source-prev').disabled=unavailable||!w.sourcePages.length;$('workbook-source-next').disabled=unavailable||!w.sources?.next_before;$('workbook-history-prev').disabled=unavailable||!w.pages.length;$('workbook-history-next').disabled=unavailable||!w.history?.next_before;for(const control of document.querySelectorAll('#workbook-sheets input,#workbook-sheets select'))control.disabled=unavailable;editionControls();}
  async function refreshWorkbooks(){renderSaved();await history();if(!w.ready){w.ready=true;let draft;try{draft=JSON.parse(localStorage.getItem(key()));}catch{}if(draft?.editor){setEditor(draft.editor,draft.loaded);w.base=draft.base;w.savePending=draft.savePending;w.runPending=draft.runPending;w.edition=draft.edition||null;remember();if(draft.selected)await open(draft.selected);}else setEditor({sheets:[]});await sources();}if(w.active){const job=await api('/api/jobs/'+w.active.id);progress(job);}controls();}
  for(const name of ['workbook-name','workbook-title','workbook-notes'])$(name).addEventListener('input',()=>{remember();controls();});
  $('workbook-new').addEventListener('click',()=>act(()=>{if(changed()&&!confirm('Discard the unsaved workbook changes?'))return;w.savePending=null;w.runPending=null;setEditor({sheets:[]});}));
  $('workbook-saved').addEventListener('change',()=>act(()=>load($('workbook-saved').value)));
  $('workbook-revision').addEventListener('change',()=>act(()=>load(w.loaded?.definition.name,Number($('workbook-revision').value))));
  $('workbook-source-kind').addEventListener('change',()=>act(()=>sources()));$('workbook-source').addEventListener('change',()=>{sourceInfo();controls();});
  $('workbook-source-refresh').addEventListener('click',()=>act(()=>sources()));$('workbook-source-next').addEventListener('click',()=>act(()=>sources(w.sources.next_before,[...w.sourcePages,w.sourceBefore])));$('workbook-source-prev').addEventListener('click',()=>act(()=>sources(w.sourcePages.at(-1),w.sourcePages.slice(0,-1))));
  $('workbook-add').addEventListener('click',()=>act(addSheet));$('workbook-save').addEventListener('click',()=>act(save));$('workbook-preview').addEventListener('click',()=>act(preview));$('workbook-preview-sheet').addEventListener('change',()=>act(preview));$('workbook-build').addEventListener('click',()=>act(build));
  $('workbook-cancel').addEventListener('click',()=>act(async()=>{if(!w.active)return;await api('/api/workbook-runs/'+w.active.id+'/cancel',{});progress(await api('/api/jobs/'+w.active.id));}));
  $('workbook-history-refresh').addEventListener('click',()=>act(()=>history(null,[])));$('workbook-history-next').addEventListener('click',()=>act(()=>history(w.history.next_before,[...w.pages,w.before])));$('workbook-history-prev').addEventListener('click',()=>act(()=>history(w.pages.at(-1),w.pages.slice(0,-1))));
  $('workbook-detail-definition').addEventListener('click',()=>act(()=>load(w.selected.request.name,w.selected.request.revision)));
  return {refresh:refreshWorkbooks,controls,open,progress,settled,dirty:changed};
})();
'''

HTML = HTML.replace('\n<section id="workbook-preview-panel"', _analysis_workbook_refresh_ui.HTML + '\n<section id="workbook-preview-panel"', 1)
JS = JS.replace("  for(const name of ['workbook-name','workbook-title','workbook-notes'])", _analysis_workbook_refresh_ui.JS + "\n  for(const name of ['workbook-name','workbook-title','workbook-notes'])", 1)
