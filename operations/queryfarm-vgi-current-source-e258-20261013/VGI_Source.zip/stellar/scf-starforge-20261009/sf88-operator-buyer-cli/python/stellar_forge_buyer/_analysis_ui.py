"""Packaged, dependency-free browser assets for the customer analysis workspace."""

from . import _analysis_reports_ui, _analysis_response_ui, _analysis_export_ui, _analysis_workbooks_ui, _analysis_archive_ui

HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dataset analysis · Stellar Forge</title><link rel="stylesheet" href="/style.css"><script src="/app.js" defer></script></head>
<body><header><div><p class="eyebrow">STELLAR FORGE / CUSTOMER DATA</p><h1>Dataset analysis</h1></div><div class="toolbar"><span id="connection" role="status">Connecting</span><button id="refresh">Refresh</button><button id="backup">Workspace backup</button></div></header>
<div id="message" role="status" aria-live="polite">Open the private launch link to connect.</div>
<nav aria-label="Workspace"><button data-tab="data" aria-selected="true">Data</button><button data-tab="changes" aria-selected="false">Changes</button><button data-tab="analysis" aria-selected="false">Analysis</button><button data-tab="activity" aria-selected="false">Activity</button></nav>
<main><section id="tab-data"><div class="grid"><section class="panel"><h2>Acquired sources</h2><p>Import a completed acquisition into this database. Your source selection is registered by the local operator.</p><label for="source">Source</label><select id="source"><option value="">No registered source</option></select><div id="source-info" class="facts"></div><label for="mapping">Column mapping <span class="muted">JSON object; optional</span></label><textarea id="mapping" rows="3" spellcheck="false">{}</textarea><button id="import">Import original delivery</button><p id="source-help" class="muted"></p></section>
<section class="panel"><h2>Current SQL views</h2><p>A view gives your analysis a stable name. Select its data version explicitly.</p><div class="table-scroll"><table><thead><tr><th>View</th><th>Revision</th><th>Version</th><th></th></tr></thead><tbody id="views"></tbody></table></div></section></div>
<section class="panel"><div class="section-head"><div><h2>Imported versions</h2><p>Each version retains its source manifest, selected mapping and scalar types.</p></div><div class="toolbar"><button id="versions-prev">Previous</button><button id="versions-next">Next</button></div></div><div class="table-scroll"><table><thead><tr><th>Imported</th><th>Dataset / snapshot</th><th>Rows</th><th>Version</th><th></th></tr></thead><tbody id="versions"></tbody></table></div><p id="versions-page" class="muted"></p></section>
<section id="version-detail" class="panel" hidden><div class="section-head"><h2>Selected version</h2><div class="toolbar"><button id="manifest">Download original manifest</button><button id="dictionary" hidden>Download source dictionary</button></div></div><div id="version-info" class="facts"></div><div class="table-scroll"><table><thead><tr><th>Original field</th><th>SQL column</th><th>Stored JSON types</th><th>Reviewed source definition</th></tr></thead><tbody id="columns"></tbody></table></div><div id="semantic-info"></div><div class="form-row"><label>SQL view name<input id="view-name" value="inventory" spellcheck="false" autocomplete="off"></label><button id="activate">Select for this view</button><button id="use-table">Query this immutable table</button><button id="review-version">Review changes against a current view</button></div><p id="activation-info" class="muted"></p></section></section>
<section id="tab-changes" hidden>
<section class="panel"><div class="section-head"><div><h2>Compare acquired versions</h2><p>Match every row using the selected keys. The current view stays selected until you apply a completed review.</p></div><button id="change-choose">Choose candidate in Data</button></div><div id="change-candidate" class="facts">Select an imported candidate in Data, then choose Review changes.</div><div class="form-row"><label>Current view<select id="change-view"><option value="">No current view</option></select></label><button id="change-plan-refresh">Load current view for comparison</button></div><div id="change-plan" class="facts"></div><fieldset><legend>Row keys present in both versions</legend><div id="change-keys" class="key-options"></div></fieldset><p class="hint">Choose 1–16 columns that identify each row. Missing or duplicate keys stop the comparison with the original row number.</p><button id="change-run" class="primary">Compare every row</button></section>
<section id="change-report" class="panel" hidden><div class="section-head"><div><h2>Retained comparison</h2><p id="change-report-info"></p></div><div class="toolbar"><button id="change-export-json">Prepare JSON report</button><button id="change-export-csv">Prepare CSV differences</button></div></div><div id="change-counts" class="comparison-counts"></div><p>These are differences between the exact acquired queries below. Changed filters, projections and ordering are part of the comparison.</p><div id="change-schema" class="facts"></div><details><summary>Original acquisitions and report identity</summary><pre id="change-binding"></pre><div class="toolbar"><button id="change-base-manifest">Baseline manifest</button><button id="change-candidate-manifest">Candidate manifest</button></div></details><div class="section-head"><label>Show differences<select id="change-kind"><option value="all">All changes</option><option value="added">Added rows</option><option value="removed">Removed rows</option><option value="changed">Changed fields</option><option value="moved">Order only</option></select></label><div class="toolbar"><button id="change-prev">Previous changes</button><button id="change-next">Next changes</button></div></div><p id="change-page" class="muted"></p><div id="change-rows"></div><div class="review-choice"><h2>Select the reviewed version</h2><p id="change-selection"></p><label for="change-note">Review note</label><textarea id="change-note" rows="3" maxlength="8000" placeholder="Explain the data selection for the next analysis."></textarea><div class="toolbar"><button id="change-select" class="primary">Select reviewed candidate</button><button id="change-query">Query current view</button></div></div></section>
<section class="panel"><div class="section-head"><div><h2>Comparison history</h2><p>Complete reports and selections stay in the original database backup.</p></div><div class="toolbar"><button id="change-history-prev">Newer reports</button><button id="change-history-next">Older reports</button></div></div><div class="table-scroll"><table><thead><tr><th>Started</th><th>Current view</th><th>Status</th><th>Differences</th><th></th></tr></thead><tbody id="change-history"></tbody></table></div><p id="change-history-page" class="muted"></p></section>
</section>
<section id="tab-analysis" hidden><section class="panel"><div class="section-head"><div><h2>Saved analysis</h2><p>Run read-only SQL over retained versions and current views.</p></div><button id="new-query">New analysis</button></div><div class="form-row"><label>Saved analysis<select id="saved-query"><option value="">Unsaved analysis</option></select></label><label>Revision<select id="query-revision"><option value="">—</option></select></label><label>Save as<input id="query-name" placeholder="available_inventory" spellcheck="false" autocomplete="off"></label></div><p id="editor-state" class="muted">Unsaved analysis</p><label for="sql">SQL</label><textarea id="sql" rows="8" spellcheck="false" placeholder="SELECT * FROM inventory LIMIT 100"></textarea><div class="grid"><label>Parameters <span class="muted">JSON array or named object</span><textarea id="parameters" rows="3" spellcheck="false">[]</textarea></label><label>Maximum result rows<input id="max-rows" type="number" min="1" max="100000" value="1000"><span class="hint">Results are also limited to 4 MiB of values and 20 seconds. Truncation is recorded.</span></label></div><div class="toolbar"><button id="save-query">Save analysis</button><button id="run-query" class="primary">Run analysis</button></div><details><summary>Reviewed current views</summary><pre id="query-views"></pre></details></section>
<section id="query-result" class="panel" hidden><div class="section-head"><div><h2>Retained result</h2><p id="result-info"></p></div><div class="toolbar"><button id="export-json">Download JSON</button><button id="export-csv">Download CSV</button></div></div><p id="truncation" class="notice" hidden></p><div class="table-scroll"><table id="result-table"><thead></thead><tbody></tbody></table></div><div class="section-head"><p id="result-page" class="muted"></p><div class="toolbar"><button id="result-prev">Previous rows</button><button id="result-next">Next rows</button></div></div><details><summary>Executed query and data selection</summary><pre id="result-binding"></pre></details></section></section>
<section id="tab-activity" hidden><section class="panel"><h2>Workspace activity</h2><p>Imports, query results, comparisons and backups remain available after restart. Interrupted work requires an explicit new action.</p><div class="table-scroll"><table><thead><tr><th>Started</th><th>Action</th><th>Status</th><th></th></tr></thead><tbody id="jobs"></tbody></table></div></section><section id="activity-detail" class="panel" hidden><h2 id="activity-title">Selected action</h2><pre id="activity-info"></pre><button id="backup-download" hidden>Download database</button><button id="change-download" hidden>Download comparison export</button><p id="response-resume-note" hidden>This interrupted local action keeps its original request, source revision and reviewed mapping. Continue it to recover the same preview or immutable import.</p><button id="response-resume-job" hidden>Continue original response action</button></section></section>
</main><footer><span id="database-path"></span><span>Local customer workspace</span></footer></body></html>'''

CSS = r'''
:root{font-family:Arial,Helvetica,sans-serif;color:#202020;background:#f3f3f3;font-size:14px;line-height:1.45;color-scheme:light}*{box-sizing:border-box}body{margin:0}header{background:#fff;border-bottom:1px solid #bbb;padding:20px 28px;display:flex;justify-content:space-between;gap:20px;align-items:center}.eyebrow{font-size:11px;letter-spacing:.1em;margin:0 0 4px;color:#555}h1{font-size:25px;font-weight:600;margin:0}h2{font-size:17px;font-weight:600;margin:0 0 7px}p{margin:5px 0 12px}button,input,select,textarea{font:inherit}button{border:1px solid #888;background:#fff;color:#202020;padding:8px 12px;border-radius:2px;cursor:pointer;line-height:1.25}button:hover:not(:disabled){background:#e8e8e8}button:disabled{opacity:.45;cursor:default}.primary{background:#262626;color:#fff}.primary:hover:not(:disabled){background:#494949}button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible,summary:focus-visible{outline:2px solid #111;outline-offset:2px}input,select,textarea{width:100%;min-width:0;border:1px solid #999;background:#fff;border-radius:2px;padding:8px;margin:4px 0 10px}textarea{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;resize:vertical;line-height:1.5}label{display:block;font-weight:600}label span{font-weight:400}.toolbar{display:flex;align-items:center;gap:9px;flex-wrap:wrap}#connection{font-size:12px;margin-right:6px}#message{padding:11px 28px;min-height:42px;background:#e9e9e9;border-bottom:1px solid #ccc;overflow-wrap:anywhere}#message.error{border-left:4px solid #222;background:#ddd}nav{padding:0 28px;display:flex;gap:6px;background:#fff;border-bottom:1px solid #ccc}nav button{border:0;border-radius:0;padding:13px 18px;border-bottom:3px solid transparent}nav button[aria-selected=true]{border-bottom-color:#222;font-weight:600}main{max-width:1500px;margin:0 auto;padding:22px 28px}.panel{background:#fff;border:1px solid #c4c4c4;padding:18px;margin-bottom:18px;min-width:0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.grid>.panel{height:calc(100% - 18px)}.section-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:12px}.form-row{display:flex;align-items:flex-end;gap:12px;margin:10px 0}.form-row label{flex:1;min-width:130px}.form-row button{margin-bottom:10px}.muted,.hint{color:#666;font-size:12px}.hint{display:block;font-weight:400;margin:0 0 10px}table{width:100%;border-collapse:collapse;font-size:13px;text-align:left}th{background:#eee;font-weight:600;white-space:nowrap}th,td{padding:9px 11px;border-bottom:1px solid #ddd;vertical-align:top}td button{padding:5px 9px;font-size:12px}td.code,code,pre{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.table-scroll{max-width:100%;overflow:auto}#result-table td{white-space:pre-wrap;min-width:90px;max-width:450px;overflow-wrap:anywhere}#result-table .null{color:#777;font-style:italic}#result-table .number{text-align:right;font-variant-numeric:tabular-nums}.facts{margin:8px 0 15px;overflow-wrap:anywhere;font-size:13px}.facts div{margin:4px 0}.facts b{display:inline-block;min-width:120px;margin-right:8px}.notice{border:1px solid #777;padding:9px;font-weight:600}details{margin-top:13px}summary{cursor:pointer;font-weight:600}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px;background:#f2f2f2;padding:12px;margin:10px 0;max-height:380px;overflow:auto}footer{border-top:1px solid #ccc;margin-top:10px;padding:15px 28px;display:flex;justify-content:space-between;gap:18px;font-size:11px;color:#666;overflow-wrap:anywhere}#database-path{min-width:0}tr.selected{background:#efefef}fieldset{border:1px solid #ccc;margin:12px 0;padding:12px}legend{font-weight:600}.key-options{display:flex;flex-wrap:wrap;gap:8px 18px}.key-options label{font-weight:400;display:flex;align-items:center;gap:7px}.key-options input{width:auto;margin:0}.comparison-counts{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));border:1px solid #ccc;margin:12px 0}.comparison-counts div{padding:10px;border-right:1px solid #ddd}.comparison-counts strong{display:block;font-size:22px}.change-record{border:1px solid #ccc;padding:10px;margin:8px 0}.change-record summary{overflow-wrap:anywhere}.change-record td{white-space:pre-wrap;overflow-wrap:anywhere;max-width:450px;min-width:100px}.change-type{display:block;color:#666;font-size:11px;font-family:Arial,sans-serif}.review-choice{border-top:1px solid #bbb;margin-top:20px;padding-top:17px}#change-note{max-width:900px}nav{overflow-x:auto}nav button{white-space:nowrap}[hidden]{display:none!important}@media(max-width:760px){header{padding:16px;align-items:flex-start;flex-direction:column;gap:14px}#message{padding:10px 16px}nav{padding:0 8px}main{padding:16px}.grid{grid-template-columns:1fr;gap:0}.section-head{flex-direction:column}.form-row{flex-wrap:wrap}.form-row label{flex-basis:100%}.panel{padding:14px}footer{padding:14px 16px;flex-direction:column}h1{font-size:23px}.toolbar{gap:7px}button{padding:8px 10px}}'''

JS = r'''
'use strict';
const $=id=>document.getElementById(id);
const initial=location.hash.slice(1);
if(initial){sessionStorage.setItem('sf-analysis-capability',initial);history.replaceState(null,'',location.pathname);}
const capability=sessionStorage.getItem('sf-analysis-capability')||'';
const s={data:null,busy:false,active:null,focusJob:null,pending:null,version:null,versionPage:null,versionBefore:null,versionHistory:[],result:null,backup:null,editor:null,editorBase:'',draftLoaded:false,queryLoad:0,resultLoad:0,poll:null,changeCandidate:null,changePlan:null,changePlanLoad:0,change:null,changeLoad:0,changePages:[],changeHistory:null,changeHistoryBefore:null,changeHistoryPages:[],changeDownload:null,responseRecovery:null};
const scalar=v=>v===null||v===undefined?'—':String(v);
const short=v=>typeof v==='string'&&v.length>20?v.slice(0,12)+'…':scalar(v);
const stamp=v=>v?new Date(v).toLocaleString():'—';
const quote=v=>'"'+v.replaceAll('"','""')+'"';
function message(text,error=false){$('message').textContent=text;$('message').classList.toggle('error',error);}
function node(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
function button(text,fn){const n=node('button',text);n.addEventListener('click',()=>act(fn));return n;}
function cell(row,text,cls){const n=node('td',text,cls);row.append(n);return n;}
function fact(parent,label,value){const div=node('div');div.append(node('b',label),document.createTextNode(scalar(value)));parent.append(div);}
function empty(body,count,text){const row=node('tr'),td=cell(row,text);td.colSpan=count;body.append(row);}
function tab(name){for(const n of ['data','research','responses','changes','analysis','reports','workbooks','exports','archives','worldbank','activity'])$('tab-'+n).hidden=n!==name;for(const b of document.querySelectorAll('[data-tab]'))b.setAttribute('aria-selected',String(b.dataset.tab===name));}
async function api(path,body){const response=await fetch(path,{method:body===undefined?'GET':'POST',headers:{'X-Analysis-Capability':capability,...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),cache:'no-store'});const data=await response.json();if(!response.ok){const error=Error(data.error||'Request failed');error.status=response.status;throw error;}return data;}
function controls(){const unavailable=s.busy||!s.data;for(const id of ['backup','import','activate','manifest','dictionary','use-table','save-query','run-query','new-query','saved-query','query-revision','source'])$(id).disabled=unavailable;for(const id of ['import','run-query'])$(id).disabled||=Boolean(s.active);$('refresh').disabled=s.busy;$('import').disabled||=!s.data?.can_import||!$('source').value;$('activate').disabled||=!s.version;$('manifest').disabled||=!s.version;$('dictionary').disabled||=!s.version?.semantics;$('use-table').disabled||=!s.version;$('versions-prev').disabled=unavailable||!s.versionHistory.length;$('versions-next').disabled=unavailable||!s.versionPage?.next_before;for(const id of ['result-prev','result-next','export-json','export-csv'])$(id).disabled=unavailable||!s.result;$('result-prev').disabled||=!s.result?.result?.offset;$('result-next').disabled||=s.result?.result?.next_offset==null;$('backup-download').disabled=unavailable;$('response-resume-job').disabled=unavailable||!!s.active||s.responseRecovery?.status!=='INTERRUPTED';for(const id of ['query-name','sql','parameters','max-rows','mapping','view-name'])$(id).disabled=s.busy;changeControls();window.customerReports?.controls();window.responseTables?.controls();window.customerExports?.controls();window.customerWorkbooks?.controls();window.workspaceArchives?.controls();window.researchIntake?.controls();window.worldbankProgrammes?.controls();}
async function act(fn){if(s.busy)return;s.busy=true;controls();try{await fn();}catch(e){message(e.message,true);}finally{s.busy=false;controls();}}
function editorValue(){return {name:$('query-name').value.trim(),sql:$('sql').value,parameters_text:$('parameters').value,max_rows:Number($('max-rows').value)};}
function editorKey(){return JSON.stringify(editorValue());}
function dirty(){return editorKey()!==s.editorBase;}
function storeDraft(){if(!s.data)return;try{localStorage.setItem('sf-analysis-draft:'+s.data.workspace_id,JSON.stringify({value:editorValue(),editor:s.editor,base:s.editorBase}));}catch{}editorLabel();}
function editorLabel(){const name=$('query-name').value.trim(),same=s.editor&&name===s.editor.name;const detail=same?'Loaded revision '+s.editor.revision+'; next save uses current revision '+s.editor.head_revision+'.':'New saved analysis.';$('editor-state').textContent=detail+(dirty()?' Unsaved changes.':'');}
function setEditor(value,record=null){$('query-name').value=value.name||'';$('sql').value=value.sql||'';$('parameters').value=value.parameters_text||'[]';$('max-rows').value=value.max_rows||1000;s.editor=record;s.editorBase=editorKey();$('saved-query').value=record?.name||'';const select=$('query-revision');select.replaceChildren();if(record){for(const h of record.history||[{revision:record.revision}]){const o=node('option','Revision '+h.revision);o.value=h.revision;select.append(o);}select.value=String(record.revision);}else select.append(node('option','—'));storeDraft();}
function confirmEditor(){return !dirty()||confirm('Discard the unsaved analysis changes?');}
function renderSources(){const old=$('source').value,select=$('source');select.replaceChildren();for(const source of s.data.sources.filter(v=>v.kind!=='response')){const option=node('option',source.name+' · '+source.native_status);option.value=source.name;select.append(option);}if(!s.data.sources.some(v=>v.kind!=='response')){const option=node('option','No registered source');option.value='';select.append(option);}if(s.data.sources.some(v=>v.kind!=='response'&&v.name===old))select.value=old;sourceInfo();}
function sourceInfo(){const source=s.data?.sources.find(v=>v.name===$('source').value),box=$('source-info');box.replaceChildren();if(source){fact(box,'Native status',source.native_status);fact(box,'Acquired rows',source.rows);fact(box,'Snapshot',source.snapshot);fact(box,'Source revision',source.revision);}$('source-help').textContent=s.data?.can_import?'Imports use the original local acquisition and data-room files.':'Start with --checkout to enable original data-room imports. Retained analysis works without it.';controls();}
function renderViews(){const body=$('views');body.replaceChildren();for(const view of s.data.views){const row=node('tr');cell(row,view.name,'code');cell(row,view.revision);const identity=cell(row,short(view.version_id),'code');identity.title=view.version_id;cell(row).append(button('Query',()=>useSql('SELECT * FROM '+quote(view.name)+' LIMIT 100')));body.append(row);}if(!s.data.views.length)empty(body,4,'Select an imported version below to create a current view.');$('query-views').textContent=JSON.stringify(s.data.views,null,2);activationInfo();}
function activationInfo(){const name=$('view-name').value.trim();const view=s.data?.views.find(v=>v.name.toLowerCase()===name.toLowerCase());$('activation-info').textContent=view?'Current revision '+view.revision+' selects '+short(view.version_id)+'. This action will use that reviewed revision.':'This name will create a new SQL view at revision 1.';}
function renderQueries(){const select=$('saved-query'),old=select.value;select.replaceChildren();const blank=node('option','Unsaved analysis');blank.value='';select.append(blank);for(const query of s.data.queries){const option=node('option',query.name+' · revision '+query.revision);option.value=query.name;select.append(option);}if(s.data.queries.some(v=>v.name===s.editor?.name))select.value=s.editor.name;else if(s.data.queries.some(v=>v.name===old))select.value=old;}
function renderJobs(){const body=$('jobs');body.replaceChildren();for(const job of s.data.jobs){const row=node('tr');cell(row,stamp(job.created_at));cell(row,job.kind);cell(row,job.status+(job.error?' · '+job.error:''));cell(row).append(button('Open',()=>openJob(job.id)));body.append(row);}if(!s.data.jobs.length)empty(body,4,'No workspace activity yet.');}
async function loadVersions(before=s.versionBefore){const data=await api('/api/versions'+(before?'?before='+before:''));s.versionPage=data;s.versionBefore=before;renderVersions();}
function renderVersions(){const body=$('versions');body.replaceChildren();for(const version of s.versionPage?.versions||[]){const row=node('tr');row.classList.toggle('selected',version.version_id===s.version?.version_id);cell(row,stamp(version.created_at));cell(row,(version.dataset.name||version.dataset.datasetId||version.dataset.id||'Dataset')+' / '+short(version.dataset.snapshot||version.dataset.response?.original?.sourceSha256));cell(row,version.row_count);const identity=cell(row,short(version.version_id),'code');identity.title=version.version_id;cell(row).append(button('Select',()=>selectVersion(version.version_id)));body.append(row);}if(!s.versionPage?.versions.length)empty(body,5,'Import a completed delivery to start using its rows.');$('versions-page').textContent='History page '+(s.versionHistory.length+1)+' · newest first';controls();}
async function selectVersion(id){const version=await api('/api/version/'+encodeURIComponent(id));s.version=version;const box=$('version-info');box.replaceChildren();fact(box,'Version',version.version_id);fact(box,'Rows',version.row_count);fact(box,'SQL table',version.table);fact(box,'Snapshot',version.dataset.snapshot);if(version.dataset.kind==='retained-response'){fact(box,'Source kind',version.dataset.response.original.nativeKind);fact(box,'Original response SHA-256',version.dataset.response.original.sourceSha256);fact(box,'Response complete',version.dataset.completion.transportComplete);fact(box,'Provider declared truncation',version.dataset.completion.providerDeclaredTruncated);fact(box,'Incomplete scope acknowledged',version.dataset.completion.incompleteAcknowledged);}fact(box,'Manifest SHA-256',version.manifestSha256);fact(box,'Native payment status',version.originalPaymentStatus);const body=$('columns');body.replaceChildren();const meanings=new Map((version.semantic_dictionary?.columns||[]).map(c=>[c.name,c]));for(const column of version.column_types){const row=node('tr');cell(row,column.source,'code');cell(row,column.column,'code');cell(row,column.json_types.join(', '));const definition=meanings.get(column.source)?.projectedDefinition;const meaning=cell(row);if(definition)meaning.append(node('pre',JSON.stringify(definition,null,2),'semantic-definition'));else meaning.textContent='—';body.append(row);}renderSemantics(version);$('version-detail').hidden=false;renderVersions();activationInfo();}
function renderSemantics(version){
 const box=$('semantic-info'),dictionary=version.semantic_dictionary,metadata=version.semantics;box.replaceChildren();$('dictionary').hidden=!dictionary;
 if(!dictionary){box.append(node('p','This imported edition has no reviewed source dictionary.','muted'));return;}
 box.append(node('h3','Source meaning'));const facts=node('div',undefined,'facts');box.append(facts);
 fact(facts,'Meaning SHA-256',metadata.semantic_sha256);fact(facts,'Definition SHA-256',metadata.definition_sha256);fact(facts,'Capture SHA-256',metadata.capture_manifest_sha256);
 fact(facts,'Original dictionary SHA-256',metadata.file.sha256);fact(facts,'Source',dictionary.source.title||dictionary.source.resourceId);fact(facts,'Catalog',dictionary.source.catalogOrigin);
 const detail=node('details'),summary=node('summary','Identity, units, code lists and source attribution');detail.append(summary,node('pre',JSON.stringify({source:dictionary.source,primaryKey:dictionary.primaryKey,aboutUrl:dictionary.aboutUrl,virtualColumns:dictionary.virtualColumns,issues:dictionary.issues},null,2)));box.append(detail);
 box.append(node('p','The definitions describe the imported source fields. The table above retains their reviewed SQL aliases. Query and report source context carries this dictionary; calculated result columns use the SQL expression chosen by the analyst.','muted'));
}
async function refresh(){const data=await api('/api/state');s.data=data;$('connection').textContent='Connected';$('database-path').textContent=data.database;renderSources();renderViews();renderQueries();renderJobs();await loadVersions();await refreshChanges();await window.customerReports?.refresh();await window.responseTables?.refresh();await window.customerExports?.refresh();await window.customerWorkbooks?.refresh();await window.workspaceArchives?.refresh();await window.researchIntake?.refresh();await window.worldbankProgrammes?.refresh();if(!s.draftLoaded){s.draftLoaded=true;let draft;try{draft=JSON.parse(localStorage.getItem('sf-analysis-draft:'+data.workspace_id));}catch{}if(draft?.value){setEditor(draft.value,draft.editor);s.editorBase=draft.base;storeDraft();}else setEditor({sql:'SELECT * FROM inventory LIMIT 100',parameters_text:'[]',max_rows:1000});}const running=data.jobs.find(j=>j.status==='RUNNING');if(running&&!s.active){s.active=running.id;schedulePoll();}if(!running&&s.active){const job=await api('/api/jobs/'+s.active);await completed(job,false);}controls();}
async function useSql(sql){if(!confirmEditor())return;setEditor({sql,parameters_text:'[]',max_rows:1000});tab('analysis');$('sql').focus();}
async function loadQuery(name,revision){if(!name)return;if(!confirmEditor()){$('saved-query').value=s.editor?.name||'';$('query-revision').value=s.editor?.revision||'';return;}const sequence=++s.queryLoad;const value=await api('/api/queries/'+encodeURIComponent(name)+(revision?'?revision='+revision:''));if(sequence!==s.queryLoad)return;setEditor(value,value);message('Loaded '+name+' revision '+value.revision+'.');}
function id(){return crypto.randomUUID().replaceAll('-','');}
async function start(kind,spec){const key=JSON.stringify({kind,spec});if(s.pending?.key!==key)s.pending={key,request:{id:id(),...spec}};const job=await api('/api/start/'+kind,s.pending.request);s.pending=null;s.focusJob=job.id;s.active=job.status==='RUNNING'?job.id:null;message(({query:'Running analysis on the reviewed data selection.',import:'Importing the original completed delivery.','response-preview':'Checking every mapped response record.','response-import':'Importing the reviewed response projection.',compare:'Comparing every acquired row and retaining complete differences.','change-export':'Writing the complete retained comparison export.',report:'Running all report sections on the reviewed data snapshot.','report-export':'Writing the complete reviewed customer report.',workbook:'Writing the complete saved workbook and source handoff.','query-export':'Writing every row returned by the reviewed query.',backup:'Creating a consistent database backup.','workspace-export':'Saving the complete workspace and its original outputs.'})[kind]);window.customerExports?.progress(job);window.customerWorkbooks?.progress(job);window.workspaceArchives?.progress(job);window.researchIntake?.progress(job);if(job.status==='RUNNING')schedulePoll();else await completed(job);controls();}
function schedulePoll(){clearTimeout(s.poll);s.poll=setTimeout(async()=>{const active=s.active;if(!active)return;try{const job=await api('/api/jobs/'+active);if(active!==s.active)return;if(job.status==='RUNNING'){window.customerExports?.progress(job);window.customerWorkbooks?.progress(job);window.workspaceArchives?.progress(job);window.researchIntake?.progress(job);schedulePoll();return;}await completed(job);}catch(e){message(e.message+' Refresh to reconnect to the retained action.',true);}},700);}
async function completed(job,refreshAfter=true){if(job.status==='RUNNING')return;if(s.active===job.id)s.active=null;clearTimeout(s.poll);window.customerExports?.settled(job);window.customerWorkbooks?.settled(job);window.workspaceArchives?.settled(job);window.researchIntake?.settled(job);if(job.status==='CANCELLED'&&job.kind==='query-export'){message('Export cancelled. Reopen its retained query review to start another export.');}else if(job.status!=='COMPLETE'){message(job.status+': '+(job.error||'The action did not finish.')+' Previous imported versions and query results remain available.',true);}else if(s.focusJob===job.id){if(job.kind==='query'){s.result=job;renderResult();tab('analysis');message('Analysis completed and retained.');await window.customerExports?.queryReady(job);}else if(job.kind==='response-preview'){await window.responseTables.open(job);message('Every selected response record was checked. Review the projection and its source scope.');}else if(job.kind==='import'||job.kind==='response-import'){s.versionBefore=null;s.versionHistory=[];await selectVersion(job.result.version.version_id);tab('data');message(job.result.version.import_status+': '+job.result.version.row_count+' original rows. Select the version for a current SQL view when ready.');}else if(job.kind==='compare'){await openComparison(job.id);message('Complete comparison retained. Review its acquisition scope and changes before selecting.');}else if(job.kind==='report'){await window.customerReports.open(job.id);message('Complete report retained. Review its sections and publish an edition when ready.');}else if(job.kind==='report-export'){await window.customerReports.exportReady(job);}else if(job.kind==='workbook'){await window.customerWorkbooks.open(job.id,job);}else if(job.kind==='query-export'){await window.customerExports.open(job.id,job);message('Complete query export retained. Open its manifest or download the selected files.');}else if(job.kind==='research-capture'){await window.researchIntake.open(job);message('Original Research edition retained as an Analysis source.');}else if(job.kind==='workspace-export'){await window.workspaceArchives.open(job.id,job);message('Complete workspace backup is ready. Download its ZIP and manifest.');}else{showActivity(job);tab('activity');message(job.kind==='change-export'?'Complete comparison export retained. Download it below.':'Database backup created.');}}if(refreshAfter)await refresh();controls();}
function renderResult(){const job=s.result,result=job?.result;if(!result)return;$('query-result').hidden=false;$('result-info').textContent=stamp(job.finished_at)+' · '+result.total_rows+' retained rows · '+job.id;$('truncation').hidden=!result.truncated;$('truncation').textContent='This result reached its configured row or byte limit. The saved export contains the retained prefix.';const table=$('result-table');table.tHead.replaceChildren();table.tBodies[0].replaceChildren();const head=node('tr');for(const column of result.columns)head.append(node('th',column));table.tHead.append(head);for(const values of result.rows){const row=node('tr');for(const value of values){const td=cell(row,value.type==='null'?'NULL':value.text);td.classList.toggle('null',value.type==='null');td.classList.toggle('number',['integer','number'].includes(value.type));td.title=value.type;}table.tBodies[0].append(row);}if(!result.rows.length)empty(table.tBodies[0],Math.max(result.columns.length,1),'No rows in this result.');$('result-page').textContent=result.total_rows?'Rows '+(result.offset+1)+'–'+(result.offset+result.rows.length)+' of '+result.total_rows:'0 rows';$('result-binding').textContent=JSON.stringify({sql:job.request.sql,parameters_text:job.request.parameters_text,views:result.views,read_tables:result.read_tables,source_versions:result.source_versions,result_sha256:result.result_sha256},null,2);controls();}
async function resultPage(offset){if(!s.result)return;const current=s.result.id,sequence=++s.resultLoad;const next=await api('/api/jobs/'+current+'?offset='+offset);if(sequence!==s.resultLoad||s.result?.id!==current)return;s.result=next;renderResult();}
function showActivity(job){$('activity-detail').hidden=false;$('activity-title').textContent=job.kind+' · '+job.status;$('activity-info').textContent=JSON.stringify(job,null,2);s.backup=job.kind==='backup'&&job.status==='COMPLETE'?job:null;$('backup-download').hidden=!s.backup?.result.downloadable;s.changeDownload=job.kind==='change-export'&&job.status==='COMPLETE'?job:null;$('change-download').hidden=!s.changeDownload;s.responseRecovery=['response-preview','response-import'].includes(job.kind)?job:null;const resumable=s.responseRecovery?.status==='INTERRUPTED';$('response-resume-job').hidden=!resumable;$('response-resume-note').hidden=!resumable;controls();}
async function openJob(jobId){s.focusJob=jobId;++s.resultLoad;const job=await api('/api/jobs/'+jobId);if(['response-preview','response-import'].includes(job.kind)&&job.status!=='RUNNING'&&s.active===job.id){s.active=null;clearTimeout(s.poll);}if(job.kind==='query'&&job.status==='COMPLETE'){s.result=job;renderResult();tab('analysis');}else if(job.kind==='response-preview'&&job.status==='COMPLETE'){await window.responseTables.open(job);}else if(job.kind==='compare'&&job.status==='COMPLETE'){await openComparison(job.id);}else if(job.kind==='report'&&job.status==='COMPLETE'){await window.customerReports.open(job.id);}else if(job.kind==='report-export'&&job.status==='COMPLETE'){await window.customerReports.exportReady(job);}else if(job.kind==='workbook'){await window.customerWorkbooks.open(job.id,job);}else if(job.kind==='query-export'){await window.customerExports.open(job.id,job);}else if(job.kind==='research-capture'){await window.researchIntake.open(job);}else if(job.kind==='workspace-export'){await window.workspaceArchives.open(job.id,job);}else{showActivity(job);tab('activity');}if(job.status==='RUNNING'){s.active=job.id;schedulePoll();}}
async function download(path,fallback){const response=await fetch(path,{headers:{'X-Analysis-Capability':capability},cache:'no-store'});if(!response.ok){const error=await response.json();throw Error(error.error||'Download failed');}const blob=await response.blob(),url=URL.createObjectURL(blob);const anchor=node('a');anchor.href=url;anchor.download=response.headers.get('content-disposition')?.match(/filename="([^"]+)"/)?.[1]||fallback;document.body.append(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}

function changeControls(){
 const unavailable=s.busy||!s.data,plan=s.changePlan,report=s.change?.report,current=report&&s.data?.views.find(v=>v.name.toLowerCase()===report.reviewed_view.name.toLowerCase());
 for(const name of ['review-version','change-view','change-plan-refresh','change-run','change-kind','change-prev','change-next','change-history-prev','change-history-next','change-select','change-query','change-export-json','change-export-csv','change-base-manifest','change-candidate-manifest','change-download'])$(name).disabled=unavailable;
 $('review-version').disabled||=!s.version||!s.data?.views.length;
 $('change-view').disabled||=!s.changeCandidate;
 $('change-plan-refresh').disabled||=!s.changeCandidate||!$('change-view').value;
 const planned=plan&&s.data?.views.some(v=>v.name.toLowerCase()===plan.view.name.toLowerCase()&&v.revision===plan.view.revision&&v.version_id===plan.view.version_id);
 $('change-run').disabled||=!!s.active||!planned||!document.querySelector('#change-keys input:checked');
 for(const input of document.querySelectorAll('#change-keys input'))input.disabled=unavailable;
 for(const name of ['change-kind','change-query','change-export-json','change-export-csv','change-base-manifest','change-candidate-manifest'])$(name).disabled||=!report;
 for(const name of ['change-export-json','change-export-csv'])$(name).disabled||=!!s.active;
 $('change-prev').disabled||=!s.changePages.length;
 $('change-next').disabled||=s.change?.next_after==null;
 $('change-history-prev').disabled||=!s.changeHistoryPages.length;
 $('change-history-next').disabled||=!s.changeHistory?.next_before;
 $('change-select').disabled||=!!s.active||!report||!!s.change?.selection||current?.revision!==report?.reviewed_view.revision||current?.version_id!==report?.reviewed_view.version_id;
 $('change-query').disabled||=!current;
 $('change-note').disabled=unavailable||!report||!!s.change?.selection;
 $('change-download').disabled||=!s.changeDownload;
 if(report)selectionInfo();
}
function versionFacts(box,label,version){fact(box,label+' dataset',version.dataset.name||version.dataset.datasetId||version.dataset.id||'Dataset');fact(box,label+' version',version.version_id);fact(box,label+' rows',version.row_count);fact(box,label+' snapshot',version.dataset.snapshot);if(version.semantics){fact(box,label+' meaning',version.semantics.semantic_sha256);fact(box,label+' definitions',version.semantics.definition_sha256);}}
async function refreshChanges(){
 const select=$('change-view'),old=select.value;select.replaceChildren();
 for(const view of s.data.views){const option=node('option',view.name+' · revision '+view.revision);option.value=view.name;select.append(option);}
 if(!s.data.views.length){const option=node('option','No current view');option.value='';select.append(option);}
 if(s.data.views.some(v=>v.name===old))select.value=old;
 await loadChangeHistory(s.changeHistoryBefore);renderChangePlan();
}
async function beginComparison(){
 if(!s.version)throw Error('Select an imported candidate in Data.');
 s.changeCandidate=s.version;s.changePlan=null;++s.changePlanLoad;
 const box=$('change-candidate');box.replaceChildren();versionFacts(box,'Candidate',s.changeCandidate);
 tab('changes');await loadChangePlan();
}
async function loadChangePlan(){
 const candidate=s.changeCandidate,view=s.data.views.find(v=>v.name===$('change-view').value),sequence=++s.changePlanLoad;
 if(!candidate||!view){s.changePlan=null;renderChangePlan();return;}
 const baseline=await api('/api/version/'+view.version_id);
 if(sequence!==s.changePlanLoad||candidate.version_id!==s.changeCandidate?.version_id)return;
 const before=new Set(baseline.column_types.map(c=>c.column)),columns=candidate.column_types.map(c=>c.column).filter(c=>before.has(c));
 s.changePlan={view:{...view},baseline,candidate,columns};
 const options=$('change-keys');options.replaceChildren();
 const preferred=columns.find(c=>['id','sku','record_id'].includes(c.toLowerCase()));
 for(const name of columns){const label=node('label'),input=document.createElement('input');input.type='checkbox';input.value=name;input.checked=name===preferred;input.addEventListener('change',changeControls);label.append(input,document.createTextNode(name));options.append(label);}
 renderChangePlan();changeControls();
}
function renderChangePlan(){
 const box=$('change-plan');box.replaceChildren();const plan=s.changePlan;
 if(!plan){box.textContent='Load a current view after choosing an imported candidate.';return;}
 fact(box,'Reviewed view',plan.view.name+' · revision '+plan.view.revision);versionFacts(box,'Baseline',plan.baseline);
 const first=plan.baseline.semantics,second=plan.candidate.semantics;
 if(first||second){
  fact(box,'Source definitions',first?.definition_sha256===second?.definition_sha256?'Same reviewed meaning':'Review the changed source dictionary');
  fact(box,'Capture identity',first?.capture_manifest_sha256===second?.capture_manifest_sha256?'Same retained capture':'Different retained captures');
  fact(box,'SQL mapping',JSON.stringify(plan.baseline.columns)===JSON.stringify(plan.candidate.columns)?'Same field mapping':'Changed field mapping');
  box.append(button('Download meaning comparison',()=>download('/api/semantic-compare?before='+encodeURIComponent(plan.baseline.version_id)+'&after='+encodeURIComponent(plan.candidate.version_id),'source-meaning-comparison.json')));
 }
 const current=s.data?.views.find(v=>v.name.toLowerCase()===plan.view.name.toLowerCase());
 if(current?.revision!==plan.view.revision||current?.version_id!==plan.view.version_id)box.append(node('p','The current view changed. Load its current selection before starting another comparison.','notice'));
}
async function loadChangeHistory(before=null){
 const result=await api('/api/changes'+(before?'?before='+before:''));s.changeHistory=result;s.changeHistoryBefore=before;
 const body=$('change-history');body.replaceChildren();
 for(const report of result.comparisons){const row=node('tr');cell(row,stamp(report.created_at));cell(row,report.view||'—');cell(row,report.status+(report.error?' · '+report.error:''));cell(row,report.counts?Object.entries(report.counts).filter(([key])=>key!=='unchanged').map(([key,value])=>key+': '+value).join(' · '):'—');cell(row).append(button('Open',()=>report.status==='COMPLETE'?openComparison(report.id):openJob(report.id)));body.append(row);}
 if(!result.comparisons.length)empty(body,5,'No retained comparisons yet.');
 $('change-history-page').textContent='History page '+(s.changeHistoryPages.length+1)+' · newest first';
}
async function changePage(comparisonId,kind='all',after=0,pages=[]){
 const sequence=++s.changeLoad;
 try{
  const result=await api('/api/changes/'+comparisonId+'?kind='+encodeURIComponent(kind)+'&after='+after);
  if(sequence!==s.changeLoad)return;
  const changed=s.change?.report.id!==comparisonId;s.change=result;s.changePages=pages;
  if(changed){let note='';try{note=localStorage.getItem('sf-change-note:'+s.data.workspace_id+':'+comparisonId)||'';}catch{}$('change-note').value=note;}
  if(result.selection)$('change-note').value=result.selection.note;
  renderComparison();
 }catch(error){if(sequence===s.changeLoad&&s.change)$('change-kind').value=s.change.kind;throw error;}
}
async function openComparison(comparisonId){await changePage(comparisonId);tab('changes');}
function selectionInfo(){
 const value=s.change,report=value?.report;if(!report)return;
 const current=s.data?.views.find(v=>v.name.toLowerCase()===report.reviewed_view.name.toLowerCase());
 const now=current?'Current view '+current.name+' selects '+short(current.version_id)+' at revision '+current.revision+'.':'The reviewed view no longer exists.';
 $('change-selection').textContent=(value.selection?'This comparison was selected at '+stamp(value.selection.selected_at)+' as revision '+value.selection.activation.revision+'. ':current?.revision===report.reviewed_view.revision&&current?.version_id===report.reviewed_view.version_id?'Selecting applies the candidate to '+report.reviewed_view.name+' using reviewed revision '+report.reviewed_view.revision+'. ':'The current view has changed since this comparison. Start a new comparison to review its current selection. ')+now;
}
function renderComparison(){
 const value=s.change,report=value.report;$('change-report').hidden=false;$('change-kind').value=value.kind;
 $('change-report-info').textContent=stamp(report.completed_at)+' · '+report.id+' · complete';
 const counts=$('change-counts');counts.replaceChildren();
 for(const [key,count]of Object.entries(report.counts)){const item=node('div');item.append(node('strong',String(count)),node('span',key));counts.append(item);}
 const schema=$('change-schema');schema.replaceChildren();fact(schema,'Matching keys',report.keys.join(', '));fact(schema,'Columns added',report.schema_changes.added.join(', ')||'None');fact(schema,'Columns removed',report.schema_changes.removed.join(', ')||'None');fact(schema,'Rows reordered',report.positions_changed);
 for(const changed of report.schema_changes.original_json_types)fact(schema,'JSON type · '+changed.column,changed.before.join(', ')+' → '+changed.after.join(', '));
 $('change-binding').textContent=JSON.stringify({reviewed_view:report.reviewed_view,baseline:{version_id:report.baseline.version_id,dataset:report.baseline.dataset,manifest_sha256:report.baseline.manifestSha256,rows:report.baseline.row_count},candidate:{version_id:report.candidate.version_id,dataset:report.candidate.dataset,manifest_sha256:report.candidate.manifestSha256,rows:report.candidate.row_count},value_basis:report.value_basis,result_sha256:report.result_sha256,rows_sha256:report.rows_sha256},null,2);
 const box=$('change-rows');box.replaceChildren();
 for(const record of value.rows){
  const detail=node('details',undefined,'change-record'),summary=node('summary',record.kind.toUpperCase()+' · '+record.key.map((c,i)=>report.keys[i]+'='+c.text+' ('+c.type+')').join(', ')+' · row '+scalar(record.before_row_number)+' → '+scalar(record.after_row_number));detail.append(summary);
  const wrap=node('div',undefined,'table-scroll'),table=node('table'),head=node('thead'),tr=node('tr');for(const label of ['Column','Baseline','Candidate'])tr.append(node('th',label));head.append(tr);table.append(head);const body=node('tbody');
  for(let i=0;i<report.columns.length;i++){const row=node('tr');cell(row,report.columns[i],'code');for(const values of [record.before,record.after]){const value=values?.[i]||{type:'missing',text:''},td=cell(row,value.type==='missing'?'Absent':value.type==='null'?'NULL':value.text,'code');td.append(node('span',value.type,'change-type'));}body.append(row);}
  table.append(body);wrap.append(table);detail.append(wrap);box.append(detail);
 }
 if(!value.rows.length)box.append(node('p',report.changed_rows?'No changes in this category.':'No acquired row values or positions differ. Review schema and acquisition differences above.'));
 $('change-page').textContent='Page '+(s.changePages.length+1)+' · '+value.rows.length+' shown · '+report.changed_rows+' complete retained differences'+(value.kind==='all'?'':' · '+value.kind);
 selectionInfo();controls();
}
async function selectComparison(){
 const value=s.change,report=value.report,note=$('change-note').value,key='sf-change-request:'+s.data.workspace_id+':'+report.id;
 let pending;try{pending=JSON.parse(localStorage.getItem(key));}catch{}
 if(!pending||pending.result_sha256!==report.result_sha256||pending.note!==note)pending={id:id(),result_sha256:report.result_sha256,note};
 try{localStorage.setItem(key,JSON.stringify(pending));}catch{}
 const selected=await api('/api/changes/'+report.id+'/select',pending);
 try{localStorage.removeItem(key);}catch{}
 await refresh();await changePage(report.id,value.kind,value.after,s.changePages);
 message('Reviewed candidate selected for '+selected.activation.name+' at revision '+selected.activation.revision+'. Continue with the current view in Analysis.');
}
async function downloadComparison(){
 const job=s.changeDownload;if(!job)return;const result=job.result;
 let handle=null;if(window.showSaveFilePicker){try{handle=await window.showSaveFilePicker({suggestedName:result.filename});}catch(error){if(error.name==='AbortError')return;throw error;}}
 const response=await fetch('/api/change-export/'+job.id,{headers:{'X-Analysis-Capability':capability},cache:'no-store'});
 if(!response.ok){const error=await response.json();throw Error(error.error||'Download failed');}
 if(handle){const writable=await handle.createWritable();try{await response.body.pipeTo(writable);}catch(error){await writable.abort().catch(()=>{});throw error;}}
 else{
  if(Number(response.headers.get('Content-Length'))>64*1024*1024){await response.body.cancel();throw Error('This browser cannot stream a report this size to a file. The complete export is retained at '+result.path+'. Use a browser with the file-save API or copy that retained file.');}
  const blob=await response.blob(),url=URL.createObjectURL(blob),anchor=node('a');anchor.href=url;anchor.download=result.filename;document.body.append(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 message('Comparison export saved · '+result.bytes+' bytes · SHA-256 '+result.sha256);
}
$('review-version').addEventListener('click',()=>act(beginComparison));
$('change-choose').addEventListener('click',()=>tab('data'));
$('change-plan-refresh').addEventListener('click',()=>act(async()=>{await refresh();await loadChangePlan();}));
$('change-view').addEventListener('change',()=>act(loadChangePlan));
$('change-run').addEventListener('click',()=>act(()=>{const plan=s.changePlan;return start('compare',{view:plan.view.name,expected_revision:plan.view.revision,base_version_id:plan.baseline.version_id,candidate_version_id:plan.candidate.version_id,keys:[...document.querySelectorAll('#change-keys input:checked')].map(n=>n.value)});}));
$('change-kind').addEventListener('change',()=>act(()=>changePage(s.change.report.id,$('change-kind').value)));
$('change-next').addEventListener('click',()=>act(()=>changePage(s.change.report.id,s.change.kind,s.change.next_after,[...s.changePages,s.change.after])));
$('change-prev').addEventListener('click',()=>act(()=>changePage(s.change.report.id,s.change.kind,s.changePages.at(-1),s.changePages.slice(0,-1))));
$('change-history-next').addEventListener('click',()=>act(async()=>{const before=s.changeHistoryBefore;await loadChangeHistory(s.changeHistory.next_before);s.changeHistoryPages.push(before);$('change-history-page').textContent='History page '+(s.changeHistoryPages.length+1)+' · newest first';}));
$('change-history-prev').addEventListener('click',()=>act(async()=>{await loadChangeHistory(s.changeHistoryPages.at(-1));s.changeHistoryPages.pop();$('change-history-page').textContent='History page '+(s.changeHistoryPages.length+1)+' · newest first';}));
$('change-select').addEventListener('click',()=>act(selectComparison));
$('change-query').addEventListener('click',()=>act(()=>useSql('SELECT * FROM '+quote(s.change.report.reviewed_view.name)+' ORDER BY "_sf_row_number" LIMIT 100')));
for(const format of ['json','csv'])$('change-export-'+format).addEventListener('click',()=>act(()=>start('change-export',{comparison_id:s.change.report.id,result_sha256:s.change.report.result_sha256,selection_sha256:s.change.selection_sha256,format})));
$('change-base-manifest').addEventListener('click',()=>act(()=>download('/api/manifest/'+s.change.report.baseline.version_id,'baseline-manifest.json')));
$('change-candidate-manifest').addEventListener('click',()=>act(()=>download('/api/manifest/'+s.change.report.candidate.version_id,'candidate-manifest.json')));
$('change-note').addEventListener('input',()=>{if(s.change)try{localStorage.setItem('sf-change-note:'+s.data.workspace_id+':'+s.change.report.id,$('change-note').value);}catch{}});
$('change-download').addEventListener('click',()=>act(downloadComparison));

for(const button of document.querySelectorAll('[data-tab]'))button.addEventListener('click',()=>tab(button.dataset.tab));
$('refresh').addEventListener('click',()=>act(async()=>{await refresh();message('Workspace refreshed.');}));
$('source').addEventListener('change',sourceInfo);
$('view-name').addEventListener('input',activationInfo);
$('import').addEventListener('click',()=>act(async()=>{const source=s.data.sources.find(v=>v.name===$('source').value);if(source)await start('import',{source:source.name,source_revision:source.revision,columns_text:$('mapping').value});}));
$('backup').addEventListener('click',()=>act(()=>window.workspaceArchives.show()));
$('versions-next').addEventListener('click',()=>act(async()=>{const before=s.versionBefore;await loadVersions(s.versionPage.next_before);s.versionHistory.push(before);renderVersions();}));
$('versions-prev').addEventListener('click',()=>act(async()=>{const before=s.versionHistory.at(-1);await loadVersions(before);s.versionHistory.pop();renderVersions();}));
$('activate').addEventListener('click',()=>act(async()=>{const name=$('view-name').value.trim(),view=s.data.views.find(v=>v.name.toLowerCase()===name.toLowerCase());const result=await api('/api/activate',{name,version_id:s.version.version_id,expected_revision:view?.revision||0});await refresh();message(result.activation_status+': '+name+' revision '+result.revision+'.');}));
$('manifest').addEventListener('click',()=>act(()=>download('/api/manifest/'+s.version.version_id,'delivery-manifest.json')));
$('dictionary').addEventListener('click',()=>act(()=>download('/api/semantics-file/'+s.version.version_id,'source-semantics.json')));
$('use-table').addEventListener('click',()=>act(()=>useSql('SELECT * FROM '+quote(s.version.table)+' ORDER BY "_sf_row_number" LIMIT 100')));
$('new-query').addEventListener('click',()=>act(async()=>{if(confirmEditor())setEditor({parameters_text:'[]',max_rows:1000});}));
$('saved-query').addEventListener('change',()=>act(()=>loadQuery($('saved-query').value)));
$('query-revision').addEventListener('change',()=>act(()=>loadQuery(s.editor?.name,$('query-revision').value)));
for(const field of ['query-name','sql','parameters','max-rows'])$(field).addEventListener('input',storeDraft);
$('save-query').addEventListener('click',()=>act(async()=>{const value=editorValue(),revision=s.editor?.name===value.name?s.editor.head_revision:0;const result=await api('/api/queries/'+encodeURIComponent(value.name),{...value,expected_revision:revision});const saved=await api('/api/queries/'+encodeURIComponent(result.name));setEditor(saved,saved);await refresh();message('Saved '+saved.name+' revision '+saved.revision+'.');}));
$('run-query').addEventListener('click',()=>act(()=>start('query',{...editorValue(),expected_views:s.data.views})));
$('result-prev').addEventListener('click',()=>act(()=>resultPage(Math.max(0,s.result.result.offset-100))));
$('result-next').addEventListener('click',()=>act(()=>resultPage(s.result.result.next_offset)));
$('export-json').addEventListener('click',()=>act(()=>download('/api/result/'+s.result.id+'?format=json','analysis.json')));
$('export-csv').addEventListener('click',()=>act(()=>download('/api/result/'+s.result.id+'?format=csv','analysis.csv')));
$('backup-download').addEventListener('click',()=>act(()=>download('/api/backup/'+s.backup.id,'datasets.sqlite3')));
$('response-resume-job').addEventListener('click',()=>act(async()=>{
 const selected=s.responseRecovery;
 if(!selected||selected.status!=='INTERRUPTED'||s.active)return;
 const job=await api('/api/jobs/'+selected.id);
 if(s.responseRecovery?.id!==selected.id)return;
 if(job.id!==selected.id||job.kind!==selected.kind||JSON.stringify(job.request)!==JSON.stringify(selected.request))throw Error('The original response action changed.');
 if(job.status==='INTERRUPTED')await start(job.kind,job.request);
 await openJob(job.id);
}));
window.addEventListener('beforeunload',event=>{if(dirty()||window.customerReports?.dirty()||window.customerWorkbooks?.dirty()||window.worldbankProgrammes?.dirty()){event.preventDefault();event.returnValue='';}});
act(async()=>{await refresh();message('Workspace ready. Import a delivery or open a retained analysis.');});
'''


HTML = HTML.replace('<button data-tab="activity"', '<button data-tab="reports" aria-selected="false">Reports</button><button data-tab="activity"', 1)
HTML = HTML.replace('<section id="tab-activity"', _analysis_reports_ui.HTML + '<section id="tab-activity"', 1)
CSS += _analysis_reports_ui.CSS
JS += _analysis_reports_ui.JS


HTML = HTML.replace('<button data-tab="changes"', '<button data-tab="responses" aria-selected="false">API responses</button><button data-tab="changes"', 1)
HTML = HTML.replace('<section id="tab-changes"', _analysis_response_ui.HTML + '<section id="tab-changes"', 1)
CSS += _analysis_response_ui.CSS
JS += _analysis_response_ui.JS


HTML = HTML.replace('<button data-tab="activity"', '<button data-tab="exports" aria-selected="false">Exports</button><button data-tab="activity"', 1)
HTML = HTML.replace('<section id="tab-activity"', _analysis_export_ui.HTML + '<section id="tab-activity"', 1)
HTML = HTML.replace('<button id="run-query" class="primary">Run analysis</button>', '<button id="run-query" class="primary">Run analysis</button><button id="full-export-review-editor">Review for full export</button>', 1)
HTML = HTML.replace('<button id="export-csv">Download CSV</button>', '<button id="export-csv">Download CSV</button><button id="full-export-from-result">Export every query row</button>', 1)
CSS += _analysis_export_ui.CSS
JS += _analysis_export_ui.JS


HTML = HTML.replace('<button data-tab="activity"', '<button data-tab="workbooks" aria-selected="false">Workbooks</button><button data-tab="activity"', 1)
HTML = HTML.replace('<section id="tab-activity"', _analysis_workbooks_ui.HTML + '<section id="tab-activity"', 1)
CSS += _analysis_workbooks_ui.CSS
JS += _analysis_workbooks_ui.JS


HTML = HTML.replace('<button data-tab="activity"', '<button data-tab="archives" aria-selected="false">Backups</button><button data-tab="activity"', 1)
HTML = HTML.replace('<section id="tab-activity"', _analysis_archive_ui.HTML + '<section id="tab-activity"', 1)
CSS += _analysis_archive_ui.CSS
JS += _analysis_archive_ui.JS


# The profile view shares this server, capability and original dataset database.
HTML = HTML.replace('<nav aria-label="Workspace">', '<nav aria-label="Workspace"><a id="profiles-link" href="/profiles">Data profiles</a>', 1)
JS += "\ndocument.getElementById('profiles-link').href='/profiles#'+capability;\n"

CSS += "\n.semantic-definition{max-width:36rem;white-space:pre-wrap;overflow-wrap:anywhere}#semantic-info pre{white-space:pre-wrap;overflow-wrap:anywhere}\n"


# Direct receiving joins the same source mapping and original Analysis jobs.
from . import _analysis_research_ui
HTML = HTML.replace('<button data-tab="responses"', '<button data-tab="research" aria-selected="false">Research</button><button data-tab="responses"', 1)
HTML = HTML.replace('<section id="tab-responses"', _analysis_research_ui.HTML + '<section id="tab-responses"', 1)
CSS += _analysis_research_ui.CSS
JS += _analysis_research_ui.JS


# Evidence synthesis uses this exact Analysis capability and database.
HTML = HTML.replace('<nav aria-label="Workspace">', '<nav aria-label="Workspace"><a id="synthesis-link" href="/synthesis">Evidence synthesis</a>', 1)
JS += "\ndocument.getElementById('synthesis-link').href='/synthesis#'+capability;\n"


# This publication view uses the same local capability and original job database.
HTML = HTML.replace('<nav aria-label="Workspace">', '<nav aria-label="Workspace"><a id="lineage-link" href="/lineage">Lineage</a>', 1)
JS += "\ndocument.getElementById('lineage-link').href='/lineage#'+capability;\n"

# World Bank source review composes the original customer workspace.
from . import _analysis_worldbank_ui
HTML = HTML.replace('<button data-tab="activity"', '<button data-tab="worldbank" aria-selected="false">World Bank</button><button data-tab="activity"', 1)
HTML = HTML.replace('<section id="tab-activity"', _analysis_worldbank_ui.HTML + '<section id="tab-activity"', 1)
CSS += _analysis_worldbank_ui.CSS
JS += _analysis_worldbank_ui.JS


# Event receiving shares this private capability and original Analysis owner.
HTML = HTML.replace('<nav aria-label="Workspace">', '<nav aria-label="Workspace"><a id="event-programmes-link" href="/event-programmes">Event programmes</a>', 1)
JS += "\ndocument.getElementById('event-programmes-link').href='/event-programmes#'+capability;\n"


# Complete report editorial returns use the same original Analysis capability.
HTML = HTML.replace('<nav aria-label="Workspace">', '<nav aria-label="Workspace"><a id="report-reviews-link" href="/report-reviews">Editorial reviews</a>', 1)
JS += "\ndocument.getElementById('report-reviews-link').href='/report-reviews#'+capability;\n"
