// Local dependency adapter: XML code-point escaping only. Structural export uses the original IATI/D-Portal functions below.
const entities={encodeXML:function(value){return Array.from(String(value)).map(c=>({'"':'&quot;',"'":'&apos;','&':'&amp;','<':'&lt;','>':'&gt;'}[c]||(c.codePointAt(0)>=128?'&#x'+c.codePointAt(0).toString(16)+';':c))).join('')}};
// Copyright (c) 2019 International Aid Transparency Initiative (IATI)
// Licensed under the MIT license whose full text can be found at http://opensource.org/licenses/MIT

const jml={}







// sort jml
jml.cmp=function(a,b)
{
	if(a.key=="0" || b.key=="1") { return -1 }
	if(b.key=="0" || a.key=="1") { return  1 }
	return a.key > b.key ? 1 : -1;
}



//
// Refry an XML string into json ( JML ) via sax.
// Returns a json dumpable object.
// Each object is either a literal string or an object comprised of an
// entities supplied attributes plus two special attributes
// [0] is the name of the entity
// [1] is an array of child entities if any exist.
//
// This gives a rather compact xml representation in json format.
//
jml.from_xml=function(data)
{
	var json=[];
	var stack=[];
	var top={};stack.push(top);
	var cdata=false;

	var parser = sax.parser(true)

	parser.onopentag=(node)=>{
		var parent=top
		top={};stack.push(top)
		for(let n in node.attributes) { top[n]=node.attributes[n] }
		top[0]=node.name
		if(!parent[1]){ parent[1]=[]; }
		parent[1].push(top)
	}

	parser.onclosetag=(name)=>{
		stack.pop()
		top=stack[stack.length-1]
	}

	parser.ontext=(text)=>{
		text=text.trim()
		if(text!="") // ignore white space
		{
			if(!top[1]) {	top[1]=[]	}
			if(cdata)	{ 	top[1].push( (text) )	}
			else		{	top[1].push( (text) )	}
		}
	}
	parser.oncdata=parser.ontext // oncdata is same function as ontext

// maintain cdata text flag
	parser.onopencdata=()=>{ cdata=true; }
	parser.onclosecdata=()=>{ cdata=false; }

//throw any errors
	parser.onerror=(e)=>{ throw new Error(e) }

	parser.write(data);

	if(stack.length>1)
	{
		throw new Error("premature ending in xml data")
	}


	return stack[0] && stack[0][1] && stack[0][1][0];
	
}

// turn json back into xml
jml.to_xml=function(tree)
{
	if("string"==typeof tree)
	{
		tree=JSON.parse(tree);
	}
	
	var ss=[];

	if(!tree){ return; }
	var f; f=function(it,space)
	{
		if("string" == typeof it) // this is probably never used
		{
			ss.push(space);
			ss.push(entities.encodeXML(it));
			ss.push("\n");
		}
		else
		if("object" == typeof it)
		{
			ss.push(space);
			ss.push("<"+it[0]);
			for(const n of Object.keys(it).sort() ) // force order
			{
				if(n!=0 && n!=1)
				{
					ss.push(" "+n+"="+"\""+entities.encodeXML( String(it[n]) )+"\"");
				}
			}
			if(it[1].length>0) // child entities
			{
				if( (it[1].length==1) && ("string" == typeof it[1][0]) ) // smart wrap if just a single string
				{
					ss.push(">");
					ss.push(entities.encodeXML(it[1][0]));
					ss.push("</"+it[0]+">\n");
				}
				else
				{
					ss.push(">\n");
					it[1].forEach(function(it){return f(it,space+" ")});
					ss.push(space);
					ss.push("</"+it[0]+">\n");
				}
			}
			else // nothing inside so just close
			{
				ss.push("></"+it[0]+">\n");
			}
		}
	};
	if(tree.forEach) { tree.forEach(function(it){return f(it,"")}); }
	else { f(tree,""); }
	
	return ss.join("");
}

// call back is called with (element,xpath) for each jml element in the tree
// return true to prevent further recursion on this element
// if cruftless is true then ignore the namespace:xml cruft
jml.walk_xpath=function(tree,cb,cruftless)
{
	if(!tree){ return }

	var walk
	walk=function(it,root)
	{
		if( typeof it != "object" ) { return } // ignore string
		var name=it[0]
		if(cruftless) // remove cruft
		{
			var aa=name.split(":")
			name=aa[1] || aa[0]
		}
		var children=it[1]
		var path=root+"/"+name
		if( cb(it,path) ) { return } // callback can disable recursion by returning true
		if(Array.isArray(children))
		{
			for(var i=0;i<children.length;i++)
			{
				walk(children[i],root+"/"+name)
			}
		}
	}
	walk(tree,"")
}


jml.find_xpath=function(tree,findpath,cruftless)
{
	var ret=[]
	jml.walk_xpath(tree,(it,path)=>{
		if(path==findpath)
		{
			ret.push(it)
			return true
		}
		if(!findpath.startsWith(path)) { return true } // go no further down this path
	},cruftless)
	return ret
}

jml.find_child=function(tree,name)
{
	for(let i=0;i<tree[1].length;i++) // find
	{
		if(name==tree[1][i][0])
		{
			return tree[1][i]
		}
	}
}


jml.manifest_xpath=function(tree,path)
{
	if(path=="") { return tree }
	
	let aa=path.split("/") // path must begin with a / and not contain any @
	let ret=tree
	for( let i=1 ; i<aa.length ; i++) // find or create
	{
		let name=aa[i]
		let it=jml.find_child(ret,name)
		if(!it) // or create
		{
			it={0:name,1:[]}
			ret[1].push(it)
		}
		ret=it
	}
	return ret
}


// Copyright (c) 2019 International Aid Transparency Initiative (IATI)
// Licensed under the MIT license whose full text can be found at http://opensource.org/licenses/MIT

const xson={}





// convert back into xml structure
xson.to_jml=function(data,sortfunction)
{
	var walk
	walk=function(it,out,root)
	{
		let ks=Object.keys(it)
		if(sortfunction)
		{
			sortfunction(root,ks)
		}
		else
		{
			ks.sort()
		}
		for(const n of ks ) // force order
		{
			let v=it[n]
			if( Array.isArray(v) )
			{
				if(v.length==1 && ( ("string" == typeof v[0]) || ("number" == typeof v[0]) ) )
				{
					let o=jml.manifest_xpath(out,n)
					o[1].push(v[0]+"")
				}
				else
				{
					let aa=n.split("/")
					let ln=aa.pop()
					let an=aa.join("/")
					let o=jml.manifest_xpath(out,an)
					for( let i=0 ; i<v.length ; i++ )
					{
						let it={0:ln,1:[]}
						o[1].push(it)
						walk( v[i] , it , root+an+"/"+ln)
					}
				}
			}
			else
			if( "object" == typeof v )
			{
				let o=jml.manifest_xpath(out,n)
				walk( v , o , root+n)
			}
			else
			{
				let aa=n.split("@")
				if(aa.length==2)
				{
					let o=jml.manifest_xpath(out,aa[0])
					o[ aa[1] ]=v
				}
				else
				{
					let o=jml.manifest_xpath(out,n)
					o[1].push(v+"")
				}
			}
		}
	}
	let out={0:"",1:[]}
	if( Array.isArray(data) )
	{
		walk({"":data},out,"")
	}
	else
	{
		walk(data,out,"")
	}
	return out[1][0]
}

// parse the xml string into a jml structure
// it is assumed every element can be multiple so is put in an array
xson.from_xml=function(data)
{
	if(typeof data=="string")
	{
		data=jml.from_xml(data)
	}
// else assume it is already parsed jml
	
	var flat={}

	var pretrim=function(s,b)
	{
		if( b && s.startsWith(b) )
		{
			s=s.substr(b.length)
		}
		return s
	}

	var store=function(op,n,v)
	{
//		console.log(n+" = "+v)
		var tn=pretrim(n,op.trim)
		op.store[tn]=v
	}
	
	var dump
	var dump_attr=function(it,op)
	{
		for(var name in it)
		{
			if( (name!="0") && (name!="1") )
			{
				store(op,op.name+"@"+name,it[name])
			}
		}
		if( Array.isArray(it[1]) && (it[1].length==1) && (typeof it[1][0] == "string") )
		{
			store(op,op.name,it[1][0])
		}
	}

	dump=function(it,op)
	{
		if(typeof it === 'string')
		{
			return
		}

		if(Array.isArray(it))
		{
			for(var i=0;i<it.length;i++)
			{
				dump(it[i],op)
			}
			return
		}
		
		var np=Object.assign({},op)
		np.name=op.root+"/"+it[0]
		np.root=np.name
		
		var n=pretrim( np.name , np.trim ) // trim

		op.store[ n ]=op.store[ n ] || []
		np.store={}
		np.trim=np.name
		op.store[ n ].push(np.store)
		
		dump_attr(it,np)
		if(it[1]) { dump(it[1],np) }

	}
	dump(data,{root:"",store:flat})

	return flat
}



xson.walk=function(it,cb)
{
	if(!it){ return }

	var walk
	walk=function(it,nn,idx)
	{
		if( cb(it,nn,idx) ) { return }
		for(var n of Object.keys(it).sort() ) // force order
		{
			var v=it[n]
			if(Array.isArray(v))
			{
				for(var i=0;i<v.length;i++)
				{
					if( typeof v[i] === 'object' ) // may be string but never an array
					{
						walk( v[i] , nn.concat([n]) , i )
					}
				}
			}
		}
	}
	if( Array.isArray(it) ) // hack for possible top level array
	{
		walk({"":it},[],0)
	}
	else
	{
		walk(it,[],0)
	}
}

xson.all=function(it,cb)
{
	xson.walk(it,function(it,nn){
		for(var n of Object.keys(it).sort() ) // force order
		{
			var v=it[n]
			var aa=nn.concat([n])
			if(!Array.isArray(v))
			{
				if( cb( v , aa ) ) { return }
			}
			else
			{
				if( typeof v[0] !== 'object' )
				{
					for(var i=0;i<v.length;i++)
					{
						if( cb( v , aa ) ) { return }
					}
				}
			}
		}
	})
}

xson.compact=function(it)
{
	var walk
	walk=function(it)
	{
		let done=false
		while( !done ) // flaten arrays
		{
			let del_it={}
			let add_it={}
			for( let n in it )
			{
				let v=it[n]
				if( Array.isArray(v) )
				{
					if( v.length==1)
					{
						del_it[ n ]=true
						for( let nn in v[0] )
						{
							let vv=v[0][nn]
							add_it[ n+nn ]=vv
						}
					}
				}
			}
			done=true
			for( let n in del_it )
			{
				done=false
				delete it[n]
			}
			for( let n in add_it )
			{
				done=false
				it[n] = add_it[n]
			}
		}

		for( let n in it ) // recurse
		{
			let v=it[n]
			if( Array.isArray(v) )
			{
				for( let i=0 ; i<v.length ; i++ )
				{
					walk( v[i] )
				}
			}
			else
			if( "object" == typeof v )
			{
				walk( v )
			}
		}
		
	}
	if( Array.isArray(it) ) // hack for possible top level array
	{
		walk({"":it})
	}
	else
	{
		walk(it)
	}
	
	return it
}


// build full xpath value frequency stats for this xson
xson.xpath_stats=function(it)
{
	stats={}

	xson.all(it,function(value,path){
		let xpath=path.join("")
		if( ! stats[ xpath ] ) { stats[ xpath ]={} }
		stats[ xpath ][ value ] =  ( stats[ xpath ][ value ] || 0 ) + 1
	})

	return stats
}

const dflat={};
dflat.xson_to_xml=function(json)
{
	// try and yank highest version number we can find out of the activities
	if( json["/iati-activities/iati-activity"] )
	{
		let v=parseFloat(json["/iati-activities@version"]||0)
		for(let it of json["/iati-activities/iati-activity"] )
		{
			let t=parseFloat(it["@iati-activities:version"])
			if(t && t>v) { v=t }
		}
		if(v)
		{
			json["/iati-activities@version"]=v
		}
	}

	// try and yank highest version number we can find out of the organisation
	if( json["/iati-organisations/iati-organisation"] )
	{
		let v=parseFloat(json["/iati-organisations@version"]||0)
		for(let it of json["/iati-organisations/iati-organisation"] )
		{
			let t=parseFloat(it["@iati-organisations:version"])
			if(t && t>v) { v=t }
		}
		if(v)
		{
			json["/iati-organisations@version"]=v
		}
	}


	let j=xson.to_jml(json,function(root,tab){


		tab.sort(function(a,b){
			

			let pa=database.paths[root+a]
			let pb=database.paths[root+b]
			
			let ia=pa && pa.orderby || 999999
			let ib=pb && pb.orderby || 999999
			
			if( ia == ib )
			{
				if( a<b ) { return -1 } // alpha sort
				if( a>b ) { return  1 }
				return 0
			}
			else
			{
				return ia-ib
			}

		})

/*
console.log("==="+root)
for(let n in tab) {
	let pn=root+tab[n]
	let pd=database.paths[pn]
	console.log("+++"+pn+" "+( pd && pd.orderby || 999999 ))
}
*/

	})
// copy or fake a version into the header and sort elements

	return '<?xml version="1.0" encoding="UTF-8"?>\n'+jml.to_xml( j )
}

// convert json to a string
const fs=require("node:fs");const response=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));const database=JSON.parse(fs.readFileSync(process.argv[3],"utf8"));process.stdout.write(dflat.xson_to_xml(response.xson[0]));
