# SNV SP2194 — real published D-Portal activity export

This package contains the complete published D-Portal XSON response for `NL-KVK-41152786-SP2194` and an XML rendering of that response. The reporting organisation is SNV Netherlands Development Organisation (`NL-KVK-41152786`), dataset `snv-world`; the activity is Biodiverse Landscapes Fund Lower Mekong.

## Representation and provenance

The complete public JSON source was retrieved from `https://d-portal.org/q.json?aid=NL-KVK-41152786-SP2194`. Its published download route is `https://d-portal.org/q.xml?aid=NL-KVK-41152786-SP2194`. The direct XML request timed out in this execution environment. The included XML therefore uses the actual D-Portal structural exporter, pinned in source-provenance.json, with a local XML code-point escaping dependency adapter. It is a D-Portal activity-export representation. No byte identity with the publisher's whole XML or with the live XML download is asserted. The complete source data, original source pins, local adapter and reproducible ordering projection are included.

Reproduce with Node: `node dportal-export.cjs snv-sp2194-dportal-original-response.json dportal-schema-ordering.json > reproduced.xml`.

## Actual results coverage

The original record contains four results, twelve indicators and six periods. Twelve actual value records include explicit Gender=Female and Gender=Male dimensions as well as undimensioned totals. Keep these distinct; a total and its component dimensions are not independent observations to sum. Baseline values of zero are published for nine quantitative indicators; one qualitative indicator has a baseline year without a value, and two indicators have no baseline record. Some indicators have no period. There are no target values, so a target ratio cannot be computed from this source.

For example, output1/indicator1 reports Female 882.00, Male 1466.00 and undimensioned 2348.00 for 2025-04-01 through 2026-02-01. Output1/indicator2 ends 2026-01-01, a different period, with Female 230.00, Male 710.00 and total 940.00. Output2/indicator1 reports Female 2640.00, Male 2192.00 and total 4832.00 for 2025-04-01 through 2026-02-01. Original decimal strings, dates, measures, ascending flags, titles and missing fields are preserved. These are published reported figures, not new programme measurements.

Use the complete XML as a selected source in the existing IATI Results workspace. Retain its XML SHA and this package's source-provenance record; compare later sources through their original stable identity and explicit period/dimension selections. The original publisher XML acquisition remains with its existing owner.
