# Laboratory legacy Excel — complete source and native receiving

This package opens original Excel 97–2003 BIFF8 workbooks in the existing
Laboratory EDD application, preserves their complete source/cell/formula
identity, and prepares a separately named XLSX after recorded literal choices.
It includes the entire source graph used by the completed original CLI
operation, its operator guide, the full native output, and both source licenses.

Source repository: https://github.com/woahwhattheheck/tjlabs-stellar-merchant-workspace
Source commit: `eb484198d4913c302d87ac040006d6d1f47a6dad`
Source change: https://github.com/woahwhattheheck/tjlabs-stellar-merchant-workspace/pull/300
Operation: `GEOTECH-DTS8D-LEGACY-XLS-9F77-20261012`

## Open the delivered result

Extract `native/DTS8D_Legacy_Excel_Complete_Receiving.zip` into a new directory.
It is the exact 557,344-byte output retained from the completed native process,
SHA-256 `6338443198202eb58c7461d91e4907e6d6e66ba06df33bd22af1cb147dfd8d91`.

Open `cli/reviewed-report.html` to inspect the complete original profile review,
physical source rows, calculated/error cell observations and field decisions.
The same directory supplies the full editable CSV/TSV and the direct
`explicit-formula-values.xls.xlsx` native receiving workbook. The complete
`cli/reviewed-result.zip` is portable: its original input, source tables,
decisions, review, native workbook, offline editor and full manifest travel
together.

`native/members.json` lists every one of the 39 unchanged output members.
`native/result.json` combines the actual native format and CLI outcomes.
`native/source-graph.json` lists the 61 exact executable/runtime files and their
source identities. The main package manifest covers every supplied file.

## Run the same complete workflow

Use an existing Linux installation with Node 24 and Python 3.10 or later.
The completed operation used Python 3.12.14 and the original installed Node
executable at
`/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node`.

From this extracted package directory:

```sh
python3 \
  source/stellar/scf-starforge-20261009/sf30-seller-sdk/lab-edd/workbook-legacy-receiving.py \
  --out /absolute/private/new-legacy-receiving \
  --node /absolute/existing/node
```

The supplied source contains all relative imports for this original native
format and direct CLI workflow. Python's BIFF8 dependency is the exact included
xlrd package; the CLI uses the existing Node runtime. The source graph has
923,312 original bytes plus the top-level MIT license. The receiver leaves
complete original and reviewed outputs in the selected private directory.

The command performs the full original 150-field format exercise and 11
Laboratory CLI commands: inspection, full editable table, initial receive and
result reopen, source-bound preview, complete CSV and TSV export/import,
reviewed receive, and independent reviewed-result reopen. Omitting `--node`
selects only the native workbook-format portion.

To reopen the delivered reviewed result with the same original reader:

```sh
node source/stellar/scf-starforge-20261009/sf30-seller-sdk/lab-edd/cli.mjs result \
  --file /absolute/extracted-native/cli/reviewed-result.zip \
  --out /absolute/private/reopened-result.json
```

For a customer's original complete workbook, use the same `inspect`, `table`,
`preview`, `receive` and `result` commands with `--profile geotech-dts8d`.
[The complete operator guide](OPERATOR.md) describes the source-bound choices,
date/number semantics, complete result and original paid file function.

## Actual retained outcomes

| Part | Outcome |
| --- | --- |
| Original upstream workbook | Exact 16,896 bytes; 3 worksheets and 6 physical formula cells |
| Generated complete DTS format | All 150 headers; two physical rows; blank/hidden row and 1904 epoch retained |
| Whole original CLI | 11 successful commands; all 300 editable fields; complete CSV and TSV decisions reopen identically |
| First native preparation | REVIEW_REQUIRED with the original error cell N4 retained in the complete report |
| Explicit literal decisions | Exact description `reviewed\\rline\\n_x000D_` and exact text value `001.2300` |
| Final native preparation | PREPARED; full original XLS retained; separately named XLSX source binding verified |
| Native workbook | 4,989 bytes; SHA-256 `c54d87609998c31820b355c69b93dcf51e3ad6dc29eec6e56a535be5fa9c8436` |
| Independent reopen | Original input, every original/selected field and the complete native conversion declaration matched |

The generated sources are explicitly labelled software-format fixtures. Their
purpose is to exercise physical Excel representations and original workflow
behavior. The intentionally incomplete reference/required fields remain visible
as 48 profile errors and `CORRECTION_REQUIRED`; native literal preparation is
a separate recorded `PREPARED` state.

The original upstream workbook retains its published source identity. A real
laboratory's workbook keeps its own acquisition record, complete values and
qualifiers, exact limit types, source dates, receiver lookup environment and
review decisions.

## Install the full Laboratory application

The same source change is part of the existing `laboratory-edd` selected
application in Merchant Workspace. Its maintained installation guide is:

https://github.com/woahwhattheheck/tjlabs-stellar-merchant-workspace/blob/eb484198d4913c302d87ac040006d6d1f47a6dad/stellar/scf-starforge-20261009/distribution/selections/LABORATORY_EDD.md

The full installation includes Applications, the original `laboratoryReview`
paid function, all five sealed input slots, customer approval/checkout,
worker/task ownership and the 42-operation Laboratory MCP desk. The XLS decoder,
full vendor license and source inventory are registered with that original
selection. The complete direct CLI graph in this delivery is also usable on its
own for local source review and native preparation.

Use the existing worker/browser receiving configuration for an actual supplied
XLS family. Its original source/job identities, complete result replay and
process lifetime remain with that saved operation.

## Primary format and source

- Geotech Enviro Data DTS8D, May 2026, pp. 12–15:
  https://geotech.com/documents/EnviroDataDTS8.pdf
- Geotech's original import FAQ and installed receiving templates:
  https://www.geotech.com/support/faq/joomfaq-using-enviro-data/faq-importing
- Complete unchanged xlrd 2.0.2 source:
  https://github.com/python-excel/xlrd/tree/d8302dc39b16c03d643ef1eee89605c2e007ed2b

The official receiving format accepts XLS or XLSX with the declared first and
only worksheet. The new XLSX retains every original or reviewed literal,
type/number format, worksheet name and epoch, hidden rows/columns and physical
blank rows; the complete original binary retains all other workbook details.

See `source/LICENSE` for the application license and
`source/stellar/scf-starforge-20261009/sf30-seller-sdk/lab-edd/vendor/xlrd/LICENSE`
for the full original parser license. The latter directory's SOURCE.json binds
each of the ten unmodified upstream modules.

This product includes software developed by David Giffin <david@giffin.org>.
