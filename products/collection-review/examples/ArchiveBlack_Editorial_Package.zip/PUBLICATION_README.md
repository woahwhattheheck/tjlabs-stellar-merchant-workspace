# ArchiveBlack editorial publication package

This is a TJLabs internal editorial proposal, not an institutional publication or an issuer requirement. All44 rights observations remain unknown. No linked collection media is included.

The complete editable workspace is collection-review/workspace.json. It contains the credential-redacted derivative admitted by operation COLLECTION-REVIEW-PUBLIC-MAPS-KEY-REDACTION-20261013-2D58; its embedded HTML is not a byte-identical copy of either originally captured public page. Only the four recorded browser-key strings were replaced in the prior publication repair. All44 occurrence labels, target URLs, ordering, raw anchors and byte ranges were independently checked against the original retained catalogue projection and are unchanged.

provenance/PUBLICATION_REDACTION.json contains exact original-to-derivative source hashes and IDs. provenance/ArchiveBlack_Editorial_Derivation.json records the mapped request. The original authored request and mapped publication request are retained separately; the UUID was not reused with a changed body. Original authored request a2197f07-ae64-4d8d-851a-a7d05eaeb332 recorded 2026-10-13T08:21:54.000Z; mapped request 61b1cd91-6cdb-4a45-b4d4-97777be39c25 recorded 2026-10-13T08:40:39.000Z.

The selected edition has28 internal metadata inclusions,16 concrete clarification questions,14 story links and19 qualified relationships. The two earlier unreviewed derivative revisions remain available. No replacement titles or rights grants were introduced.

Open the workspace JSON in the existing Collection review component, or Receive it into the same derivative workspace to preserve the colleague's current selection. The original unredacted workspace has a different identity and must not be treated as the same receiving destination.

The collection-review/ files and original Source Tables/native files are unchanged output of the maintained createCollectionExport(...,{native:true}) path. This wrapper adds only this explanation, provenance sidecars and publication-files.json, using the existing zipWorkspace writer. The separately supplied ArchiveBlack_Editorial_Native.zip is the byte-exact unaugmented native export.

The original functions were operated in V8 with controlled platform adapters; no native browser, customer installation, deployment, payment or RFI submission is claimed.
