# ArchiveBlack · Institution source review · credential-redacted publication: source-table operation

This directory contains the original source editions, explicit mappings, reviewed complete outputs and editable project. The merchant uses the original seller.json and workspace.json in the parent directory.

## Reopen and update

Open source-tables.html in the maintained Stellar Forge front door and choose Open project JSON, then select source-tables/project.json. Select a table, add the next source edition, inspect the declared header and mapping, and retain its review. The prior source and output remain available. Record keys identify changed rows; with no keys, comparisons report whole-row additions and removals including duplicates. Unit and time-basis fields document meaning and do not convert values.

Export the complete native workspace after reviewing every current mapping. The parent README.md contains the original installation and merchant commands. Keep the original source version and receiving application with the commissioned installation. The current dataset resource is a startup snapshot; follow the native release/change operation when replacing a serving source.

## Document tables

Document-derived resources retain complete extracted text under documents/, original document identity and extraction metadata in source.json, and each explicit table selection plus projected row and cell origins under projections/. The selected CSV is an ordinary source edition in the same mapping and review workflow. Saving and reopening preserves unselected original rows for later remapping. Selecting a new projection creates a new edition even when its CSV text matches an earlier projection.

## Receiving and commissioning

Receive the entire directory. materials.json lists every original source and reviewed output with its exact identity. Each output has fields, keyFields, source and rows. Integers of arbitrary size and exact decimals use their explicitly selected text types. An empty string, null and an omitted value retain distinct policies. The same project reopens in the browser or original source-table CLI.

For an existing SF49 commissioning case, retain this complete directory as the source material attached through its existing source-bundle operation. Use that case owner’s original source handoff, terms, operation ID and source-bundle writer. The original case/bundle keeps the selected customer workorder and native receiving result alongside these files.

## Terminal use from the maintained source

node stellar-forge/developer-site/dist/source-table-cli.mjs show --project /absolute/path/to/source-tables/project.json
node stellar-forge/developer-site/dist/source-table-cli.mjs export --project /absolute/path/to/source-tables/project.json --out /absolute/new-workspace.zip

Choose a new output path for every CLI save. A project can be downloaded while its mapping is unfinished; a native workspace exports the complete currently reviewed outputs.
