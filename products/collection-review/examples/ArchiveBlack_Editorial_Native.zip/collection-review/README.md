# ArchiveBlack · Institution source review · credential-redacted publication

Proposed collection-review capability. This is an editorial preparation, not an institutional publication, rights clearance or issuer-specific DAM implementation.

Open workspace.json in Collection review to validate and continue every source and revision. Receiving into the same workspace retains the current local selection and all incoming branches. Select an earlier/received revision explicitly as the basis of a new draft.

review.html is a printable complete institutional review plus separately ordered story proposal. Source titles combine any date exactly as published. Repeated links remain distinct occurrences. Rights observations require an operator-provided basis and citation; they do not independently establish permission. No linked media is included or fetched.

occurrences.csv and relationships.csv are quoted UTF-8 metadata for explicit import to an existing CMS/catalogue. Source titles may contain spreadsheet formula characters; import all fields as text. review.json and story.json carry complete structured fields.
