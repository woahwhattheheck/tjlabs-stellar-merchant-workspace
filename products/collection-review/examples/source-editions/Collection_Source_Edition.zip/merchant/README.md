# merchant: Stellar Forge merchant workspace

This workspace runs through the original Starforge merchant toolkit. It contains 1 JSON resources and the selected source data. Data files retain their original UTF-8 bytes.

## Install the toolkit

Use Node.js 22.16 or later. Obtain or build the source archive using the maintained [distribution guide](https://github.com/woahwhattheheck/public-commons-sprint-2026/blob/main/stellar/scf-starforge-20261009/distribution/README.md). This is an npm-compatible local archive. Keep its source commit, version and SHA-256 receipt with the archive you install.

From the application directory that contains this extracted merchant directory, replace /absolute/path/to/the-package.tgz with the actual archive path:

```sh
npm install --ignore-scripts --offline --omit=optional --no-audit --no-fund '/absolute/path/to/the-package.tgz'
npx --no-install starforge doctor
```

The workspace is already initialized:

```sh
npx --no-install starforge run --workspace './merchant' -- --port 0
```

The original launcher prints the seller URL and the operations dashboard URL. Open that dashboard, or the seller URL followed by /_seller/docs. Its /_seller/openapi.json comes from these exact routes. Ctrl-C shuts down the original processes.

## Resources

| ID | Request | Payment choices | Data file | Bytes |
| --- | --- | --- | --- | --- |
| collection-occurrences | GET /collection-occurrences | 1 | data/collection-occurrences.json | 56450 |

## Complete ordered payment choices

Each resource keeps its own network, asset, recipient, exact atomic amount, timeout and optional extra object. Prices remain decimal strings. Choice order is preserved; it does not authorize a buyer, select an exchange rate or combine values across different assets.

### GET /collection-occurrences

The 1 choice below remain in merchant order. The original declaration uses payment.

```json
[
  {
    "scheme": "exact",
    "network": "stellar:testnet",
    "asset": "UNVERIFIED_DEMO_ASSET",
    "payTo": "UNVERIFIED_DEMO_RECIPIENT",
    "amount": "10000",
    "maxTimeoutSeconds": 60
  }
]
```

The original SF30 compiler accepts 1–16 complete exact choices per route. Network, asset and recipient identify a distinct choice; changing only price or timeout cannot distinguish another choice. Its native offer/header limits and payment SDK checks continue to apply. See the [original payment-options guide](https://github.com/woahwhattheheck/public-commons-sprint-2026/blob/main/stellar/scf-starforge-20261009/sf30-seller-sdk/PAYMENT_OPTIONS.md).

The startup command serves native HTTP 402 challenges. The default UNVERIFIED_DEMO_ASSET and UNVERIFIED_DEMO_RECIPIENT are local example markers. Replace them with the merchant's public payment identifiers before configuring the native facilitator. Challenge-only mode does not release the data. Data is loaded once at startup; restart after editing a data file to load a new snapshot.

Copy the actual seller URL from startup:

```sh
STARFORGE_SELLER_URL='PASTE_SELLER_URL_FROM_STARTUP'
curl -i "$STARFORGE_SELLER_URL/_seller/health"
curl -i "$STARFORGE_SELLER_URL/_seller/offers"
curl -i "$STARFORGE_SELLER_URL/collection-occurrences"
```

Inspect the complete accepts array on each route's original PAYMENT-REQUIRED offer. The original buyer's explicit network/asset/payee policy selects a compatible choice. This workspace supplies no automatic choice ranking or payment execution.

## Configure native operation

Use the merchant's original payment terms and configured facilitator. Install the documented optional dependencies in the consuming application:

```sh
npm install --ignore-scripts --no-audit --no-fund @x402/core@2.28.0 @x402/stellar@2.28.0 @x402/extensions@2.28.0 '@stellar/stellar-sdk@^16.3.0'
npx --no-install starforge doctor --native
```

Replace the facilitator URL with the configured endpoint:

```sh
npx --no-install starforge run --workspace './merchant' -- --port 0 --facilitator 'https://your-facilitator.example/facilitator'
```

The original SDK and facilitator perform verification and settlement. The browser that prepared these files does not connect to either. Doctor checks local runtime and dependency availability.

## Continue development

- seller.json: the original seller-service.v1 configuration.
- workspace.json: the original merchant-workspace.v1 dataset descriptor.
- data/: complete selected JSON source files named by resource ID.
- starter-input.json: reopen the same resources, ordered choices and editable extra JSON.
- .private/: local operator material, excluded from Git by .gitignore.

Imported route metadata and explicit output examples remain attached when a resource is renamed. Imported routes initially own their terms, independently of workspace defaults. Choosing workspace defaults temporarily retains the route's edited choices in the draft; choose route-specific terms to restore them. A copied payment list changes only the destination's terms. Drafts can retain incomplete extra JSON for later editing; workspace export requires complete native terms.

Selected data is never added to advertised examples. Other native resource types continue in the original developer workspace.

[Seller guide](https://github.com/woahwhattheheck/public-commons-sprint-2026/blob/main/stellar/scf-starforge-20261009/sf30-seller-sdk/README.md) · [Developer workspace](https://github.com/woahwhattheheck/public-commons-sprint-2026/blob/main/stellar/scf-starforge-20261009/sf30-seller-sdk/DEVELOPER.md) · [Payment choices](https://github.com/woahwhattheheck/public-commons-sprint-2026/blob/main/stellar/scf-starforge-20261009/sf30-seller-sdk/PAYMENT_OPTIONS.md) · [Portable release operations](https://github.com/woahwhattheheck/public-commons-sprint-2026/blob/main/stellar/scf-starforge-20261009/sf46-release/DISTRIBUTION.md)

To produce an immutable toolkit archive from a committed checkout, run the original packager from its repository root with a new output directory:

```sh
node stellar/scf-starforge-20261009/distribution/build.mjs --out /absolute/new-release-directory --ref HEAD
```

Inspect the installed package's source manifest:

```sh
npx --no-install starforge source
```
